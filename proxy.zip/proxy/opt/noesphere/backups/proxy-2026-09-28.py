#!/usr/bin/env python3
"""
Noesphere Proxy — Noetic Labs
Single-file OpenAI + Anthropic compatible proxy.

Features:
  - OpenAI /v1/chat/completions + Anthropic /v1/messages
  - Dark dashboard (Models / Upstreams / API Keys)
  - Streaming-safe keepalive (asyncio.shield — never aborts on big prompts)
  - Full thinking stripper (<think>, <thinking>, <reasoning>)
  - NSP (Noesphere Signature Protocol) — own HMAC-based signature scheme
  - Whitelist response sanitizer — no upstream identity leak in ANY chunk
  - Per-key sliding-window rate limiter
  - Batched non-blocking usage tracking

Run:
    ADMIN_KEY=changeme python proxy.py

Env:
    ADMIN_KEY                 (required) dashboard password
    DB_FILE                   sqlite path (default: /data/noesphere.db or ./noesphere.db)
    PORT                      default 8000
    WORKERS                   default 1
    KEEPALIVE_INTERVAL        default 15.0
    SIGNATURE_SECRET          NSP HMAC secret (set in production!)
    EMIT_REDACTED_THINKING    default 1
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import sqlite3
import string
import time
import uuid
from collections import deque
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Optional

import httpx
import uvicorn
from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import (HTMLResponse, StreamingResponse, JSONResponse,
                               RedirectResponse, FileResponse)
from fastapi.security import APIKeyQuery

# ══════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════

ADMIN_KEY = os.getenv("ADMIN_KEY", "").strip()
if not ADMIN_KEY:
    raise RuntimeError("ADMIN_KEY env var is required")

DB_FILE = os.getenv("DB_FILE", "/data/noesphere.db" if os.path.exists("/data") else "noesphere.db")
PORT = int(os.getenv("PORT", "8000"))
WORKERS = int(os.getenv("WORKERS", "1"))
KEEPALIVE_INTERVAL = float(os.getenv("KEEPALIVE_INTERVAL", "15.0"))

SERVER_HEADER = "noesphere"
SPHERE_VERSION = "1.0"
HTTPX_TIMEOUT = httpx.Timeout(
    connect=float(os.getenv("HTTPX_CONNECT_TIMEOUT", "15.0")),
    read=float(os.getenv("HTTPX_READ_TIMEOUT", "1800.0")),   # ждём ответ сколько угодно долго
    write=float(os.getenv("HTTPX_WRITE_TIMEOUT", "300.0")),   # большие тела с картинками/PDF
    pool=float(os.getenv("HTTPX_POOL_TIMEOUT", "60.0")),
)
HTTPX_LIMITS = httpx.Limits(max_connections=200,
                            max_keepalive_connections=50,
                            keepalive_expiry=30.0)

# документы: text — вытаскиваем текст из PDF, passthrough — отдаём файлом как есть, off — пропускаем
PDF_MODE = os.getenv("PDF_MODE", "auto").strip().lower()  # auto | text | vision | passthrough | off
MAX_PDF_PAGES = int(os.getenv("MAX_PDF_PAGES", "300"))
MAX_PDF_BYTES = int(os.getenv("MAX_PDF_BYTES", str(32 * 1024 * 1024)))
# если текста в PDF нет (скан) — можно попробовать отдать файл как есть
PDF_FALLBACK_FILE = os.getenv("PDF_FALLBACK_FILE", "0") == "1"
# страницы без текстового слоя (сканы, фото) рендерим в картинки
PDF_IMAGE_MAX_PAGES = int(os.getenv("PDF_IMAGE_MAX_PAGES", "8"))
PDF_IMAGE_MAX_WIDTH = int(os.getenv("PDF_IMAGE_MAX_WIDTH", "1280"))
PDF_IMAGE_QUALITY = int(os.getenv("PDF_IMAGE_QUALITY", "80"))
PDF_IMAGE_MAX_BYTES = int(os.getenv("PDF_IMAGE_MAX_BYTES", str(8 * 1024 * 1024)))
PDF_TEXT_PAGE_MIN_CHARS = int(os.getenv("PDF_TEXT_PAGE_MIN_CHARS", "60"))

# повтор системных инструкций в длинных диалогах (размывание промпта)
SYS_REINJECT = os.getenv("SYS_REINJECT", "digest").strip().lower()  # off | digest | full
SYS_REINJECT_FRACTION = float(os.getenv("SYS_REINJECT_FRACTION", "0.25"))
SYS_REINJECT_TOKENS = int(os.getenv("SYS_REINJECT_TOKENS", "0"))  # 0 = context_length * fraction
SYS_REINJECT_DIGEST_CHARS = int(os.getenv("SYS_REINJECT_DIGEST_CHARS", "4000"))
REINJECT_MARK = "[GATEWAY-SYSTEM-REMINDER]"

# ── поиск в интернете (агентский цикл внутри прокси) ──────────────────
SEARCH_ENABLED = os.getenv("SEARCH_ENABLED", "1") == "1"
SEARCH_PROVIDER = os.getenv("SEARCH_PROVIDER", "ddgs").strip().lower()
SEARCH_MAX_RESULTS = int(os.getenv("SEARCH_MAX_RESULTS", "6"))
SEARCH_MAX_ROUNDS = int(os.getenv("SEARCH_MAX_ROUNDS", "3"))
# сколько параллельных поисковых вызовов модели выполняем за один раунд
SEARCH_MAX_CALLS_PER_ROUND = int(os.getenv("SEARCH_MAX_CALLS_PER_ROUND", "4"))
SEARCH_FETCH_PAGES = os.getenv("SEARCH_FETCH_PAGES", "1") == "1"
SEARCH_FETCH_TOP = int(os.getenv("SEARCH_FETCH_TOP", "3"))
SEARCH_FETCH_CHARS = int(os.getenv("SEARCH_FETCH_CHARS", "6000"))
SEARCH_TIMEOUT = float(os.getenv("SEARCH_TIMEOUT", "20"))
SEARCH_CACHE_TTL = int(os.getenv("SEARCH_CACHE_TTL", "1800"))
SEARCH_SEARXNG_URL = os.getenv("SEARCH_SEARXNG_URL", "").strip()
SEARCH_API_KEY = os.getenv("SEARCH_API_KEY", "").strip()
SEARCH_TOOL_NAME = "web_search"
# быстрый параллельный поиск: ядро всегда, расширения — по ключевым словам
SEARCH_PROVIDERS = [p.strip() for p in os.getenv(
    "SEARCH_PROVIDERS", "ddg_ia,wikipedia,wikidata,ddgs,searxng").split(",") if p.strip()]
SEARCH_EXTRA_PROVIDERS = [p.strip() for p in os.getenv(
    "SEARCH_EXTRA_PROVIDERS", "hackernews,stackexchange,openalex,github,arxiv").split(",") if p.strip()]
SEARCH_SEARXNG_INSTANCES = [u.strip().rstrip("/") for u in os.getenv(
    "SEARCH_SEARXNG_INSTANCES",
    "https://searx.be,https://search.inetol.net,https://searx.tiekoetter.com"
).split(",") if u.strip()]
SEARCH_MERGE_WINDOW_MS = int(os.getenv("SEARCH_MERGE_WINDOW_MS", "300"))
SEARCH_RESULT_BUDGET_MS = int(os.getenv("SEARCH_RESULT_BUDGET_MS", "6000"))
SEARCH_READ_BUDGET_MS = int(os.getenv("SEARCH_READ_BUDGET_MS", "2000"))
SEARCH_READ_MIN_PAGES = int(os.getenv("SEARCH_READ_MIN_PAGES", "1"))
SEARCH_READ_MIN_CHARS = int(os.getenv("SEARCH_READ_MIN_CHARS", "800"))
SEARCH_READER = os.getenv("SEARCH_READER", "auto").strip().lower()
SEARCH_WORKERS = int(os.getenv("SEARCH_WORKERS", "12"))
SEARCH_JINA = os.getenv("SEARCH_JINA", "1") == "1"
SEARCH_UA = os.getenv("SEARCH_UA", "Mozilla/5.0 (compatible; NoesphereBot/1.0)")
SEARCH_MAX_PAGE_BYTES = int(os.getenv("SEARCH_MAX_PAGE_BYTES", str(2 * 1024 * 1024)))

_DEFAULT_SIGNATURE_SECRET = "U9k2Lm4Nq7Rt5Wx8Yz3Ab6Cd1Ef0Gh9Ij2Kl4Mn6Op8Qr3St5Uv7Wx9Yz2Ab4Cd6Ef8Gh"
SIGNATURE_SECRET = os.getenv("SIGNATURE_SECRET", _DEFAULT_SIGNATURE_SECRET).encode("utf-8")
EMIT_REDACTED_THINKING = os.getenv("EMIT_REDACTED_THINKING", "1") == "1"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("noesphere")

B62 = string.ascii_letters + string.digits
SYSTEM_FINGERPRINT = f"fp_{''.join(secrets.choice(B62) for _ in range(22))}"
NOESPHERE_ORG = "org-noetic-labs"

# ══════════════════════════════════════════════════════════════════════
#  DATABASE
# ══════════════════════════════════════════════════════════════════════

def init_db() -> None:
    with sqlite3.connect(DB_FILE) as c:
        c.executescript("""
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;

        CREATE TABLE IF NOT EXISTS upstreams (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL UNIQUE,
            url         TEXT NOT NULL,
            api_key     TEXT NOT NULL,
            enabled     INTEGER DEFAULT 1,
            created_at  TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS mappings (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            fake_model      TEXT NOT NULL UNIQUE,
            real_model      TEXT NOT NULL,
            upstream_id     INTEGER NOT NULL,
            owned_by        TEXT DEFAULT 'noetic-labs',
            context_length  INTEGER DEFAULT 128000,
            delay_sec       REAL DEFAULT 0.0,
            is_reasoning    INTEGER DEFAULT 0,
            endpoint_mode   INTEGER DEFAULT 3,
            enabled         INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS api_keys (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            public_key  TEXT NOT NULL UNIQUE,
            note        TEXT DEFAULT '',
            rpm_limit   INTEGER DEFAULT 60,
            enabled     INTEGER DEFAULT 1,
            created_at  TEXT DEFAULT '',
            upstream_key TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS key_usage (
            key_id        INTEGER PRIMARY KEY,
            requests      INTEGER DEFAULT 0,
            input_tokens  INTEGER DEFAULT 0,
            output_tokens INTEGER DEFAULT 0,
            last_used     TEXT DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """)
        _cols = {r[1] for r in c.execute("PRAGMA table_info(api_keys)")}
        if "upstream_key" not in _cols:
            c.execute("ALTER TABLE api_keys ADD COLUMN upstream_key TEXT DEFAULT ''")
        c.commit()


UPSTREAMS: dict[int, dict] = {}
MAPPINGS: dict[str, dict] = {}
API_KEYS: dict[str, dict] = {}
KEYS_BY_ID: dict[int, dict] = {}


def load_data() -> None:
    global UPSTREAMS, MAPPINGS, API_KEYS, KEYS_BY_ID
    with sqlite3.connect(DB_FILE) as c:
        c.row_factory = sqlite3.Row
        UPSTREAMS = {r["id"]: dict(r) for r in c.execute("SELECT * FROM upstreams")}
        MAPPINGS = {}
        for r in c.execute("SELECT * FROM mappings WHERE enabled=1"):
            MAPPINGS[r["fake_model"]] = dict(r)
        API_KEYS = {}
        KEYS_BY_ID = {}
        for r in c.execute("SELECT * FROM api_keys"):
            API_KEYS[r["public_key"]] = dict(r)
            KEYS_BY_ID[r["id"]] = dict(r)

# ══════════════════════════════════════════════════════════════════════
#  RATE LIMITER
# ══════════════════════════════════════════════════════════════════════

_rl_lock = asyncio.Lock()
_rl: dict[int, deque[float]] = {}


async def check_rate(key_id: int, limit: int) -> tuple[bool, int, int]:
    now = time.time()
    async with _rl_lock:
        q = _rl.setdefault(key_id, deque())
        cutoff = now - 60.0
        while q and q[0] < cutoff:
            q.popleft()
        if len(q) >= limit:
            retry = max(1, int(q[0] + 60.0 - now) + 1)
            return False, 0, retry
        q.append(now)
        return True, limit - len(q), 0

# ══════════════════════════════════════════════════════════════════════
#  USAGE TRACKING
# ══════════════════════════════════════════════════════════════════════

_usage_buf: dict[int, dict] = {}
_usage_lock = asyncio.Lock()


async def bump_usage(key_id: Optional[int], in_tok: int = 0, out_tok: int = 0) -> None:
    if not key_id:
        return
    async with _usage_lock:
        d = _usage_buf.setdefault(key_id, {"r": 0, "i": 0, "o": 0})
        d["r"] += 1
        d["i"] += max(0, int(in_tok))
        d["o"] += max(0, int(out_tok))


async def flush_usage() -> None:
    async with _usage_lock:
        if not _usage_buf:
            return
        batch = dict(_usage_buf)
        _usage_buf.clear()
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            for kid, d in batch.items():
                c.execute("""
                    INSERT INTO key_usage (key_id, requests, input_tokens, output_tokens, last_used)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(key_id) DO UPDATE SET
                        requests      = requests + excluded.requests,
                        input_tokens  = input_tokens + excluded.input_tokens,
                        output_tokens = output_tokens + excluded.output_tokens,
                        last_used     = excluded.last_used
                """, (kid, d["r"], d["i"], d["o"], stamp))
            c.commit()

    try:
        await asyncio.to_thread(_w)
    except Exception as e:
        log.warning("usage flush failed: %r", e)


async def flush_loop() -> None:
    while True:
        await asyncio.sleep(30)
        await flush_usage()

# ══════════════════════════════════════════════════════════════════════
#  NSP — Noesphere Signature Protocol
# ══════════════════════════════════════════════════════════════════════

SIG_PREFIX = "nsp_"
SIG_MAGIC = b"NSPH"
SIG_VERSION = b"\x01"
SIG_FIXED_LEN = 4 + 1 + 16 + 32 + 4


def _b64u_enc(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_dec(s: str) -> bytes:
    padded = s + "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(padded)


def sign_body(body: bytes = b"") -> str:
    if not isinstance(body, (bytes, bytearray)):
        raise TypeError("body must be bytes")
    body = bytes(body)
    nonce = secrets.token_bytes(16)
    mac_input = SIG_MAGIC + SIG_VERSION + nonce + body
    tag = hmac.new(SIGNATURE_SECRET, mac_input, hashlib.sha256).digest()
    binary = (
        SIG_MAGIC + SIG_VERSION + nonce + tag
        + len(body).to_bytes(4, "big") + body
    )
    return SIG_PREFIX + _b64u_enc(binary)


def verify_sig(sig: str, expected_body: Optional[bytes] = None) -> bool:
    if not isinstance(sig, str) or not sig.startswith(SIG_PREFIX):
        return False
    try:
        binary = _b64u_dec(sig[len(SIG_PREFIX):])
    except Exception:
        return False
    if len(binary) < SIG_FIXED_LEN:
        return False
    if binary[:4] != SIG_MAGIC:
        return False
    if binary[4:5] != SIG_VERSION:
        return False
    nonce = binary[5:21]
    tag = binary[21:53]
    body_len = int.from_bytes(binary[53:57], "big")
    if len(binary) != SIG_FIXED_LEN + body_len:
        return False
    body = binary[SIG_FIXED_LEN:]
    if expected_body is not None and body != expected_body:
        return False
    mac_input = SIG_MAGIC + SIG_VERSION + nonce + body
    expected = hmac.new(SIGNATURE_SECRET, mac_input, hashlib.sha256).digest()
    return hmac.compare_digest(expected, tag)


def signature_of_thinking(thinking_text: str) -> str:
    digest = hashlib.sha256(thinking_text.encode("utf-8", "ignore")).digest()
    return sign_body(digest)

# ══════════════════════════════════════════════════════════════════════
#  THINKING STRIPPER
# ══════════════════════════════════════════════════════════════════════

_THINK_RE = re.compile(
    r"<(?:think|thinking|reasoning)>[\s\S]*?"
    r"(?:</(?:think|thinking|reasoning)>|<\\/(?:think|thinking|reasoning)>|$)",
    re.IGNORECASE,
)
_OPEN_TAG_RE = re.compile(r"<(?:think|thinking|reasoning)>", re.IGNORECASE)
_CLOSE_TAG_RE = re.compile(
    r"</(?:think|thinking|reasoning)>|<\\/(?:think|thinking|reasoning)>",
    re.IGNORECASE,
)
_ALL_TAGS = ("<think>", "<thinking>", "<reasoning>")
_ALL_CLOSE = ("</think>", "</thinking>", "</reasoning>",
              r"<\/think>", r"<\/thinking>", r"<\/reasoning>")


def strip_thinking_full(text: str) -> tuple[str, str]:
    if not text:
        return "", ""
    found: list[str] = []

    def _repl(m: re.Match) -> str:
        found.append(m.group(0))
        return ""

    clean = _THINK_RE.sub(_repl, text)
    return clean, "".join(found)


class ThinkStripper:
    __slots__ = ("_in_think", "_tag_buf", "_collected")

    def __init__(self) -> None:
        self._in_think = False
        self._tag_buf = ""
        self._collected: list[str] = []

    @property
    def collected(self) -> str:
        return "".join(self._collected)

    def feed(self, chunk: str) -> str:
        if not chunk:
            return ""
        curr = self._tag_buf + chunk
        self._tag_buf = ""
        out: list[str] = []
        while curr:
            if self._in_think:
                m = _CLOSE_TAG_RE.search(curr)
                if m:
                    self._collected.append(curr[: m.start()])
                    curr = curr[m.end():]
                    self._in_think = False
                else:
                    held = ""
                    for i in range(min(len(curr), 16), 0, -1):
                        tail = curr[-i:]
                        if any(t.startswith(tail) for t in _ALL_CLOSE):
                            held = tail
                            break
                    self._collected.append(curr[: len(curr) - len(held)])
                    self._tag_buf = held
                    curr = ""
            else:
                m = _OPEN_TAG_RE.search(curr)
                if m:
                    out.append(curr[: m.start()])
                    curr = curr[m.end():]
                    self._in_think = True
                else:
                    held = ""
                    for i in range(min(len(curr), 12), 0, -1):
                        tail = curr[-i:]
                        if any(t.startswith(tail) for t in _ALL_TAGS):
                            held = tail
                            break
                    out.append(curr[: len(curr) - len(held)])
                    self._tag_buf = held
                    curr = ""
        return "".join(out)

    def flush(self) -> str:
        if self._in_think:
            self._tag_buf = ""
            return ""
        out, self._tag_buf = self._tag_buf, ""
        return out

# ══════════════════════════════════════════════════════════════════════
#  RESPONSE SANITIZER (whitelist — nothing from upstream leaks)
# ══════════════════════════════════════════════════════════════════════

_DROP_HEADERS = {
    "server", "via", "x-powered-by", "x-served-by",
    "x-upstream", "x-backend", "x-proxy", "x-cache", "x-cache-hits",
    "x-request-id", "x-correlation-id", "x-trace-id", "x-amzn-trace-id",
    "cf-ray", "cf-cache-status", "cf-request-id", "x-cloud-trace-context",
    "x-zhipu-request-id", "x-zhipu-trace-id",
    "x-dashscope-request-id", "x-dashscope-trace-id",
    "x-goog-request-id", "x-goog-trace-id",
    "x-ms-request-id", "x-ms-client-request-id",
    "x-b3-traceid", "x-b3-spanid",
    "openai-organization", "openai-processing-ms", "openai-version",
    "openai-model", "openai-project",
    "anthropic-organization-id", "anthropic-workspace-id",
    "anthropic-ratelimit-requests-limit", "anthropic-ratelimit-requests-remaining",
    "anthropic-ratelimit-requests-reset",
    "anthropic-ratelimit-tokens-limit", "anthropic-ratelimit-tokens-remaining",
    "anthropic-ratelimit-tokens-reset",
    "anthropic-ratelimit-input-tokens-limit", "anthropic-ratelimit-input-tokens-remaining",
    "anthropic-ratelimit-input-tokens-reset",
    "anthropic-ratelimit-output-tokens-limit", "anthropic-ratelimit-output-tokens-remaining",
    "anthropic-ratelimit-output-tokens-reset",
    "x-amzn-requestid", "x-azure-ref",
}

_BRAND_SCRUB = [
    (re.compile(r"\bOpenAI\b"), "Noesphere"),
    (re.compile(r"\bopenai\b"), "noesphere"),
    (re.compile(r"\bAnthropic\b"), "Noesphere"),
    (re.compile(r"\banthropic\b"), "noesphere"),
    (re.compile(r"\bClaude\b"), "Noesphere"),
    (re.compile(r"\bclaude\b"), "noesphere"),
    (re.compile(r"\bDeepSeek\b"), "Noesphere"),
    (re.compile(r"\bdeepseek\b"), "noesphere"),
    (re.compile(r"\bZhipu\b"), "Noesphere"),
    (re.compile(r"\bzhipu\b"), "noesphere"),
    (re.compile(r"\bGLM\b"), "Noesphere"),
    (re.compile(r"\bglm\b"), "noesphere"),
    (re.compile(r"\bQwen\b"), "Noesphere"),
    (re.compile(r"\bqwen\b"), "noesphere"),
    (re.compile(r"\bMiniMax\b"), "Noesphere"),
    (re.compile(r"\bminimax\b"), "noesphere"),
    (re.compile(r"\bMoonshot\b"), "Noesphere"),
    (re.compile(r"\bmoonshot\b"), "noesphere"),
    (re.compile(r"\bGemini\b"), "Noesphere"),
    (re.compile(r"\bgemini\b"), "noesphere"),
    (re.compile(r"claude-[\w.-]+"), "noesphere-1"),
    (re.compile(r"gpt-\d[\w.-]*"), "noesphere-1"),
    (re.compile(r"gpt-[\w]+"), "noesphere-1"),
    (re.compile(r"deepseek-[\w.-]+"), "noesphere-1"),
    (re.compile(r"glm-[\w.-]+"), "noesphere-1"),
    (re.compile(r"qwen-[\w.-]+"), "noesphere-1"),
    (re.compile(r"grok-[\w.-]+"), "noesphere-1"),
]


def sanitize_text(text: str) -> str:
    if not isinstance(text, str) or not text:
        return text or ""
    for pat, repl in _BRAND_SCRUB:
        text = pat.sub(repl, text)
    return text


def sanitize_openai_body(obj: dict, model: str,
                         fixed_id: Optional[str] = None,
                         created: Optional[int] = None) -> dict:
    if not isinstance(obj, dict):
        return obj
    if "error" in obj and isinstance(obj["error"], dict):
        err = dict(obj["error"])
        if "message" in err and isinstance(err["message"], str):
            err["message"] = sanitize_text(err["message"])
        return {"error": err}

    out: dict[str, Any] = {}
    out["id"] = fixed_id or obj.get("id") or new_id("chatcmpl")
    out["object"] = obj.get("object", "chat.completion")
    out["created"] = created if created is not None else obj.get("created") or now_ts()
    out["model"] = model
    out["system_fingerprint"] = SYSTEM_FINGERPRINT

    new_choices: list[dict] = []
    for ch in (obj.get("choices") or []):
        if not isinstance(ch, dict):
            continue
        nch: dict[str, Any] = {"index": ch.get("index", 0)}
        if "message" in ch:
            m = ch.get("message") or {}
            nm: dict[str, Any] = {"role": m.get("role", "assistant")}
            if "content" in m:
                nm["content"] = m.get("content")
            if "tool_calls" in m:
                nm["tool_calls"] = m["tool_calls"]
            if "function_call" in m:
                nm["function_call"] = m["function_call"]
            if "reasoning_content" in m:
                nm["reasoning_content"] = m["reasoning_content"]
            if "refusal" in m:
                nm["refusal"] = m["refusal"]
            nch["message"] = nm
        if "delta" in ch:
            d = ch.get("delta") or {}
            nd: dict[str, Any] = {}
            for k in ("role", "content", "tool_calls", "function_call",
                      "reasoning_content", "refusal"):
                if k in d:
                    nd[k] = d[k]
            nch["delta"] = nd
        if "finish_reason" in ch:
            nch["finish_reason"] = ch["finish_reason"]
        if "logprobs" in ch:
            nch["logprobs"] = ch["logprobs"]
        new_choices.append(nch)
    out["choices"] = new_choices

    if "usage" in obj:
        u = obj.get("usage") or {}
        try:
            pt = int(u.get("prompt_tokens") or 0)
            ct = int(u.get("completion_tokens") or 0)
            tt = int(u.get("total_tokens") or (pt + ct))
        except Exception:
            pt = ct = tt = 0
        out["usage"] = {
            "prompt_tokens": pt,
            "completion_tokens": ct,
            "total_tokens": tt,
        }
    return out


def sanitize_anthropic_body(obj: dict, model: str) -> dict:
    if not isinstance(obj, dict):
        return obj
    if obj.get("type") == "error":
        err = dict(obj.get("error") or {})
        if "message" in err and isinstance(err["message"], str):
            err["message"] = sanitize_text(err["message"])
        return {"type": "error", "error": err}

    out: dict[str, Any] = {
        "id": obj.get("id") or new_id("msg"),
        "type": obj.get("type", "message"),
        "role": obj.get("role", "assistant"),
        "model": model,
        "content": obj.get("content") or [],
        "stop_reason": obj.get("stop_reason"),
        "stop_sequence": obj.get("stop_sequence"),
        "usage": obj.get("usage") or {"input_tokens": 0, "output_tokens": 0},
    }
    u = out["usage"]
    for k in ("input_tokens", "output_tokens",
              "cache_creation_input_tokens", "cache_read_input_tokens"):
        if k in u:
            try:
                u[k] = int(u[k])
            except Exception:
                u[k] = 0
    return out

# ══════════════════════════════════════════════════════════════════════
#  SSE + KEEPALIVE
# ══════════════════════════════════════════════════════════════════════

class SSEBuffer:
    __slots__ = ("buf",)

    def __init__(self) -> None:
        self.buf = ""

    def feed(self, chunk: bytes) -> list[str]:
        self.buf += chunk.decode("utf-8", errors="ignore")
        out: list[str] = []
        while "\n\n" in self.buf:
            event, self.buf = self.buf.split("\n\n", 1)
            out.append(event)
        return out

    def flush(self) -> str:
        tail, self.buf = self.buf, ""
        return tail


async def with_keepalive(aiter: AsyncIterator[bytes], interval: float):
    it = aiter.__aiter__()
    pending: Optional[asyncio.Task] = None
    try:
        while True:
            if pending is None:
                pending = asyncio.ensure_future(it.__anext__())
            try:
                chunk = await asyncio.wait_for(asyncio.shield(pending), timeout=interval)
            except asyncio.TimeoutError:
                yield ("ping", None)
                continue
            except StopAsyncIteration:
                return
            pending = None
            yield ("data", chunk)
    finally:
        if pending is not None and not pending.done():
            pending.cancel()
            try:
                await pending
            except BaseException:
                pass


async def stream_with_pings(aiter: AsyncIterator[bytes], ping_bytes: bytes):
    async for kind, item in with_keepalive(aiter, KEEPALIVE_INTERVAL):
        if kind == "ping":
            yield ("ping", ping_bytes)
        else:
            yield ("data", item)

# ══════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════

def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:24]}"


def gen_b62(n: int) -> str:
    return "".join(secrets.choice(B62) for _ in range(n))


def gen_ant_key() -> str:
    return f"sk-noe-v1-{gen_b62(80)}"


def normalize_upstream_url(raw: str) -> str:
    """Любой вариант ссылки -> база без /v1 (эндпоинт /v1/... приклеивается при запросе)."""
    u = (raw or "").strip()
    if not u:
        return ""
    m = re.match(r"^(https?)://(.+)$", u, re.I)
    scheme, rest = (m.group(1).lower(), m.group(2)) if m else ("https", u)
    rest = re.sub(r"/+", "/", rest).strip("/")
    while True:
        trimmed = re.sub(
            r"(?i)/(?:chat/)?completions$|/messages$|/models$|/v1$", "", rest
        ).rstrip("/")
        if not trimmed or trimmed == rest:
            break
        rest = trimmed
    return f"{scheme}://{rest}" if rest else ""


def mask_key(k: str) -> str:
    k = (k or "").strip()
    if not k:
        return ""
    dots = "\u2022" * 4
    return f"{dots}{k[-4:]}" if len(k) > 4 else dots


def now_ts() -> int:
    return int(time.time())


def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, (len(text.encode("utf-8")) + 2) // 3)


_IMG_TOKENS = 85
_DOC_TOKENS = 1500


def _count_part(p: Any) -> int:
    if not isinstance(p, dict):
        return 0
    t = p.get("type")
    if t in ("text", "input_text", "output_text"):
        return estimate_tokens(p.get("text") or "")
    if t in ("image_url", "image", "input_image"):
        return _IMG_TOKENS
    if t in ("file", "input_file", "document"):
        return _DOC_TOKENS
    if t == "tool_result":
        return 4 + _count_content(p.get("content"))
    if t == "tool_use":
        return 8 + estimate_tokens(json.dumps(p.get("input") or {}, ensure_ascii=False))
    return 0


def _count_content(c: Any) -> int:
    if isinstance(c, str):
        return estimate_tokens(c)
    if isinstance(c, list):
        return sum(_count_part(p) for p in c)
    return 0


def estimate_messages_tokens(messages: list) -> int:
    """Оценка входа. Медиа и base64 считаем фиксированно, чтобы не сканировать мегабайты."""
    if not messages:
        return 8
    total = 0
    for m in messages:
        if not isinstance(m, dict):
            continue
        total += 6
        total += _count_content(m.get("content"))
        for tc in (m.get("tool_calls") or []):
            if isinstance(tc, dict):
                fn = tc.get("function") or {}
                total += 8
                total += estimate_tokens(str(fn.get("name") or ""))
                total += estimate_tokens(str(fn.get("arguments") or ""))
    return max(total, 6)

def extract_key(req: Request) -> Optional[str]:
    h = req.headers
    xk = h.get("x-api-key") or h.get("anthropic-api-key")
    if xk:
        return xk.strip()
    auth = h.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return None


def gw_headers(req_id: str, is_stream: bool = False, model: str = "") -> dict:
    h: dict[str, str] = {
        "server": SERVER_HEADER,
        "x-noesphere-request-id": req_id,
        "x-noesphere-sphere-version": SPHERE_VERSION,
        "x-noesphere-system-fingerprint": SYSTEM_FINGERPRINT,
        "strict-transport-security": "max-age=31536000; includeSubDomains",
    }
    if model:
        h["x-noesphere-model"] = model
    if is_stream:
        h["cache-control"] = "no-cache"
        h["connection"] = "keep-alive"
        h["x-accel-buffering"] = "no"
    return h


def err_oai(err_type: str, msg: str, code: int, req_id: str, model: str = "") -> JSONResponse:
    return JSONResponse(
        {"error": {"message": sanitize_text(msg), "type": err_type,
                   "param": None, "code": err_type}},
        status_code=code, headers=gw_headers(req_id, model=model),
    )


def err_ant(err_type: str, msg: str, code: int, req_id: str, model: str = "") -> JSONResponse:
    return JSONResponse(
        {"type": "error", "error": {"type": err_type, "message": sanitize_text(msg)}},
        status_code=code, headers=gw_headers(req_id, model=model),
    )


def map_err_oai(code: int) -> str:
    return {
        400: "invalid_request_error", 401: "authentication_error", 403: "permission_error",
        404: "not_found_error", 413: "request_too_large", 422: "invalid_request_error",
        429: "rate_limit_error", 500: "api_error", 502: "api_error", 503: "overloaded_error",
        504: "api_error", 529: "overloaded_error",
    }.get(code, "api_error")


def map_err_ant(code: int) -> str:
    return {
        400: "invalid_request_error", 401: "authentication_error", 403: "permission_error",
        404: "not_found_error", 413: "request_too_large", 429: "rate_limit_error",
        500: "api_error", 529: "overloaded_error",
    }.get(code, "api_error")


REASONING_PREFIX = (
    "Reasoning Protocol:\n"
    "Think step-by-step inside <think>...</think> tags, then write the final answer.\n"
    "Use the same language as the user. Close </think> before the final answer.\n\n"
)
DEPTH = {
    1: "1x — direct execution",
    2: "2x — one verification pass",
    3: "3x — double verification",
    4: "4x — multi-pass audit",
    5: "5x — exhaustive audit",
}


def inject_reasoning(messages: list, level: int) -> list:
    if level <= 0:
        return messages
    ins = REASONING_PREFIX + f"Depth: {DEPTH.get(level, 'auto — adaptive')}\n"
    if messages and isinstance(messages[0], dict) and messages[0].get("role") == "system":
        cur = messages[0].get("content")
        if isinstance(cur, list):
            messages[0]["content"] = [{"type": "text", "text": ins}] + cur
        else:
            messages[0]["content"] = ins + str(cur or "")
    else:
        messages.insert(0, {"role": "system", "content": ins})
    return messages


# ══════════════════════════════════════════════════════════════════════
#  WEB SEARCH — параллельный поиск по бесплатным источникам + чтение страниц
# ══════════════════════════════════════════════════════════════════════

from concurrent.futures import ThreadPoolExecutor, as_completed

SEARCH_TOOL_DEF = {
    "type": "function",
    "function": {
        "name": SEARCH_TOOL_NAME,
        "description": (
            "Search the live internet and open the most relevant pages, returning their "
            "content with URLs. Use it whenever the answer may have changed recently "
            "(news, sports, events, prices, releases, people, versions), when the user asks "
            "you to look something up online, or when you would otherwise guess. "
            "Always cite the URLs you used."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "max_results": {"type": "integer", "minimum": 1, "maximum": 10},
                "read_pages": {"type": "boolean",
                               "description": "Open top pages and read them (default true)"},
            },
            "required": ["query"],
        },
    },
}

_SEARCH_CACHE: dict[str, tuple[float, Any]] = {}
_SEARCH_CACHE_MAX = 400
_SEARCH_POOL = ThreadPoolExecutor(max_workers=max(4, SEARCH_WORKERS),
                                  thread_name_prefix="search")
_HTTP_CLIENT: Optional[httpx.Client] = None
_DEV_HINTS = ("python", "javascript", "java", "c++", "rust", "golang", "sql", "api",
              "docker", "kubernetes", "linux", "github", "код", "ошибка", "traceback",
              "pip", "npm", "regex", "нейросет", "модель", "pytorch", "tensorflow")
_SCI_HINTS = ("исследован", "статья", "научн", "paper", "study", "research", "journal",
              "arxiv", "медицин", "клинич", "фарм", "препарат")


def _http() -> httpx.Client:
    """Общий клиент: переиспользует соединения — экономит TLS-хендшейки."""
    global _HTTP_CLIENT
    if _HTTP_CLIENT is None:
        _HTTP_CLIENT = httpx.Client(
            timeout=httpx.Timeout(connect=5.0, read=SEARCH_TIMEOUT, write=10.0, pool=5.0),
            follow_redirects=True, max_redirects=3,
            limits=httpx.Limits(max_connections=64, max_keepalive_connections=32,
                                keepalive_expiry=60.0),
            headers={"User-Agent": SEARCH_UA, "Accept-Language": "en,ru;q=0.8,de;q=0.5"},
        )
    return _HTTP_CLIENT


def _add_search_tool(tools: Any) -> list:
    out = [t for t in tools if isinstance(t, dict)] if isinstance(tools, list) else []
    if not SEARCH_ENABLED:
        return out
    for t in out:
        if (t.get("function") or {}).get("name") == SEARCH_TOOL_NAME:
            return out
    return out + [SEARCH_TOOL_DEF]


def _cache_get(key: str) -> Any:
    hit = _SEARCH_CACHE.get(key)
    if not hit:
        return None
    ts, val = hit
    if time.time() - ts > SEARCH_CACHE_TTL:
        _SEARCH_CACHE.pop(key, None)
        return None
    return val


def _cache_put(key: str, val: Any) -> None:
    if len(_SEARCH_CACHE) >= _SEARCH_CACHE_MAX:
        try:
            _SEARCH_CACHE.pop(next(iter(_SEARCH_CACHE)))
        except Exception:
            pass
    _SEARCH_CACHE[key] = (time.time(), val)


def _host_is_public(host: str) -> bool:
    import ipaddress
    import socket as _sock
    if not host:
        return False
    try:
        infos = _sock.getaddrinfo(host, None)
    except Exception:
        return False
    if not infos:
        return False
    for info in infos:
        ip = info[4][0].split("%")[0]
        try:
            a = ipaddress.ip_address(ip)
        except Exception:
            return False
        if (a.is_private or a.is_loopback or a.is_link_local or a.is_reserved
                or a.is_multicast or a.is_unspecified):
            return False
    return True


def _safe_url(url: str) -> bool:
    from urllib.parse import urlparse
    try:
        p = urlparse(url)
    except Exception:
        return False
    if p.scheme not in ("http", "https"):
        return False
    return _host_is_public(p.hostname or "")


def _html_to_text(html: str, limit: int) -> str:
    import html as _html
    import re as _re
    # предпочитаем основное содержимое страницы
    for tag in ("article", "main"):
        m = _re.search(r"(?is)<%s[^>]*>(.*?)</%s>" % (tag, tag), html)
        if m and len(m.group(1)) > 400:
            html = m.group(1)
            break
    txt = _re.sub(r"(?is)<(script|style|noscript|svg|template|nav|footer|header|aside)[^>]*>.*?</\1>", " ", html)
    txt = _re.sub(r"(?is)<(br|/p|/div|/li|/h[1-6]|/tr)[^>]*>", "\n", txt)
    txt = _re.sub(r"(?s)<[^>]+>", " ", txt)
    txt = _html.unescape(txt)
    txt = _re.sub(r"[ \t\xa0]+", " ", txt)
    txt = _re.sub(r"\n\s*\n\s*\n+", "\n\n", txt)
    out, total = [], 0
    for ln in (x.strip() for x in txt.split("\n")):
        if not ln:
            continue
        if len(ln) < 25 and not ln.endswith((".", ":", "!", "?")):
            continue
        out.append(ln)
        total += len(ln)
        if total >= limit:
            break
    return "\n".join(out)[:limit]


def _read_direct(url: str) -> str:
    try:
        with _http().stream("GET", url) as r:
            if r.status_code >= 400:
                return ""
            ctype = (r.headers.get("content-type") or "").lower()
            if "text" not in ctype and "html" not in ctype and "xml" not in ctype:
                return ""
            chunks, size = [], 0
            for chunk in r.iter_bytes():
                chunks.append(chunk)
                size += len(chunk)
                if size > SEARCH_MAX_PAGE_BYTES:
                    break
            return _html_to_text(b"".join(chunks).decode("utf-8", "ignore"),
                                 SEARCH_FETCH_CHARS)
    except Exception:
        return ""


def _read_jina(url: str) -> str:
    """r.jina.ai — бесплатный reader: отдаёт готовый текст страницы (в т.ч. JS-страниц)."""
    try:
        r = _http().get("https://r.jina.ai/" + url,
                        headers={"Accept": "text/plain", "X-Return-Format": "text"},
                        timeout=httpx.Timeout(min(6.0, SEARCH_READ_BUDGET_MS / 1000.0)))
        if r.status_code >= 400:
            return ""
        return (r.text or "").strip()[:SEARCH_FETCH_CHARS]
    except Exception:
        return ""


def _read_page(url: str) -> str:
    """Открывает страницу и читает её. direct и jina идут наперегонки."""
    if not _safe_url(url):
        return ""
    ck = "page:" + url
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    text = ""
    if "wikipedia.org" in url:
        _cache_put(ck, _read_direct(url))
        return _cache_get(ck) or ""
    if SEARCH_READER == "jina" and SEARCH_JINA:
        text = _read_jina(url)
    elif SEARCH_READER == "direct":
        text = _read_direct(url)
    else:
        futs = {_SEARCH_POOL.submit(_read_direct, url): "direct"}
        if SEARCH_JINA:
            futs[_SEARCH_POOL.submit(_read_jina, url)] = "jina"
        try:
            for fut in as_completed(futs, timeout=max(2.0, SEARCH_READ_BUDGET_MS / 1000)):
                try:
                    got = fut.result() or ""
                except Exception:
                    got = ""
                if len(got) > len(text):
                    text = got
                if len(text) > 1200:
                    break
        except Exception:
            pass
    _cache_put(ck, text)
    return text


# ── провайдеры (все бесплатные, без ключей) ───────────────────────────────

def _p_ddg_ia(q: str, n: int) -> list:
    r = _http().get("https://api.duckduckgo.com/",
                    params={"q": q, "format": "json", "no_html": "1", "no_redirect": "1"})
    d = r.json()
    out = []
    if d.get("AbstractText"):
        out.append({"title": d.get("Heading") or q, "url": d.get("AbstractURL") or "",
                    "snippet": d["AbstractText"]})
    if d.get("Answer"):
        out.append({"title": "Instant answer", "url": d.get("AbstractURL") or "",
                    "snippet": str(d["Answer"])[:300]})
    def walk(items):
        for it in items or []:
            if isinstance(it, dict):
                if it.get("FirstURL") and (it.get("Text") or ""):
                    out.append({"title": (it.get("Text") or "")[:90],
                                "url": it["FirstURL"],
                                "snippet": it.get("Text") or ""})
                walk(it.get("Topics"))
    walk(d.get("RelatedTopics"))
    return [x for x in out if x["url"]][:n]


def _wiki_lang(q: str) -> str:
    import re as _re
    return "ru" if _re.search(r"[А-Яа-яЁё]", q or "") else "en"


def _p_wikipedia(q: str, n: int) -> list:
    lang = _wiki_lang(q)
    r = _http().get(f"https://{lang}.wikipedia.org/w/api.php",
                    params={"action": "query", "list": "search", "srsearch": q,
                            "format": "json", "srlimit": min(n, 5)})
    hits = ((r.json().get("query") or {}).get("search") or [])
    if not hits:
        return []
    out = []
    for h in hits[:2]:
        title = h.get("title") or ""
        snippet = re.sub(r"(?s)<[^>]+>", "", h.get("snippet") or "").strip()
        url = f"https://{lang}.wikipedia.org/wiki/" + title.replace(" ", "_")
        try:
            s = _http().get(f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/"
                            + title.replace(" ", "_"))
            if s.status_code < 400:
                ext = (s.json().get("extract") or "").strip()
                if ext:
                    snippet = ext
        except Exception:
            pass
        out.append({"title": title, "url": url, "snippet": snippet[:600]})
    for h in hits[2:n]:
        title = h.get("title") or ""
        out.append({"title": title,
                    "url": f"https://{lang}.wikipedia.org/wiki/" + title.replace(" ", "_"),
                    "snippet": re.sub(r"(?s)<[^>]+>", "", h.get("snippet") or "").strip()[:300]})
    return out[:n]


def _p_wikidata(q: str, n: int) -> list:
    lang = _wiki_lang(q)
    r = _http().get("https://www.wikidata.org/w/api.php",
                    params={"action": "wbsearchentities", "search": q, "language": lang,
                            "uselang": lang, "format": "json", "limit": min(n, 3)})
    out = []
    for item in (r.json().get("search") or []):
        eid = item.get("id") or ""
        desc = item.get("description") or ""
        label = item.get("label") or eid
        if not eid:
            continue
        out.append({"title": f"{label} (Wikidata {eid})",
                    "url": f"https://www.wikidata.org/wiki/{eid}",
                    "snippet": desc})
    return out


def _p_ddgs(q: str, n: int) -> list:
    from ddgs import DDGS
    out = []
    for r in (DDGS().text(q, max_results=n) or []):
        url = r.get("href") or r.get("url") or ""
        if url:
            out.append({"title": (r.get("title") or "").strip(), "url": url,
                        "snippet": (r.get("body") or "").strip()})
    return out


def _searxng_one(inst: str, q: str, n: int) -> list:
    r = _http().get(inst + "/search", params={"q": q, "format": "json", "safesearch": "1"})
    r.raise_for_status()
    data = r.json()
    out = []
    for item in (data.get("results") or [])[:n]:
        if item.get("url"):
            out.append({"title": (item.get("title") or "").strip(), "url": item["url"],
                        "snippet": (item.get("content") or "").strip()})
    return out


def _p_searxng(q: str, n: int) -> list:
    insts = []
    if SEARCH_SEARXNG_URL:
        # есть свой инстанс — публичные не дёргаем вовсе (быстрее и без 429)
        insts.append(SEARCH_SEARXNG_URL.rstrip("/"))
    else:
        insts += [i for i in SEARCH_SEARXNG_INSTANCES]
    if not insts:
        return []
    futs = {_SEARCH_POOL.submit(_searxng_one, i, q, n): i for i in insts[:4]}
    try:
        for fut in as_completed(futs, timeout=6.0):
            try:
                res = fut.result()
            except Exception:
                continue
            if res:
                return res
    except Exception:
        pass
    return []


def _p_hackernews(q: str, n: int) -> list:
    r = _http().get("https://hn.algolia.com/api/v1/search",
                    params={"query": q, "hitsPerPage": min(n, 5)})
    out = []
    for h in (r.json().get("hits") or []):
        url = h.get("url") or (f"https://news.ycombinator.com/item?id={h.get('objectID')}")
        out.append({"title": (h.get("story_title") or h.get("title") or "").strip(),
                    "url": url,
                    "snippet": (h.get("story_text") or h.get("comment_text") or "")[:300]})
    return [x for x in out if x["title"] and x["url"]]


def _p_stackexchange(q: str, n: int) -> list:
    r = _http().get("https://api.stackexchange.com/2.3/search/advanced",
                    params={"order": "desc", "sort": "relevance", "q": q,
                            "site": "stackoverflow", "pagesize": min(n, 5),
                            "filter": "default"})
    out = []
    for it in (r.json().get("items") or []):
        out.append({"title": it.get("title") or "", "url": it.get("link") or "",
                    "snippet": re.sub(r"(?s)<[^>]+>", "", it.get("body") or "")[:300]})
    return [x for x in out if x["url"]]


def _p_openalex(q: str, n: int) -> list:
    r = _http().get("https://api.openalex.org/works",
                    params={"search": q, "per-page": min(n, 5)})
    out = []
    for w in (r.json().get("results") or []):
        out.append({"title": (w.get("title") or "")[:120],
                    "url": w.get("doi") or (w.get("primary_location") or {}).get("landing_page_url") or "",
                    "snippet": ((w.get("abstract_inverted_index") is not None) and
                                "научная работа (OpenAlex)") or ""})
    return [x for x in out if x["url"]]


def _p_github(q: str, n: int) -> list:
    r = _http().get("https://api.github.com/search/repositories",
                    params={"q": q, "per_page": min(n, 4)},
                    headers={"Accept": "application/vnd.github+json"})
    if r.status_code >= 400:
        return []
    out = []
    for it in (r.json().get("items") or []):
        out.append({"title": it.get("full_name") or "", "url": it.get("html_url") or "",
                    "snippet": (it.get("description") or "")[:300]})
    return [x for x in out if x["url"]]


def _p_arxiv(q: str, n: int) -> list:
    r = _http().get("http://export.arxiv.org/api/query",
                    params={"search_query": f"all:{q}", "max_results": min(n, 4)})
    out = []
    for m in re.finditer(r"(?s)<entry>(.*?)</entry>", r.text or ""):
        block = m.group(1)
        def pick(tag):
            mm = re.search(rf"(?s)<{tag}[^>]*>(.*?)</{tag}>", block)
            return re.sub(r"\s+", " ", mm.group(1)).strip() if mm else ""
        url = pick("id")
        if url:
            out.append({"title": pick("title")[:120], "url": url,
                        "snippet": pick("summary")[:300]})
    return out


def _p_tavily(q: str, n: int) -> list:
    if not SEARCH_API_KEY:
        return []
    r = _http().post("https://api.tavily.com/search",
                     json={"api_key": SEARCH_API_KEY, "query": q, "max_results": n})
    r.raise_for_status()
    return [{"title": (i.get("title") or "").strip(), "url": i.get("url") or "",
             "snippet": (i.get("content") or "").strip()}
            for i in (r.json().get("results") or [])[:n] if i.get("url")]


_PROVIDERS = {
    "ddg_ia": _p_ddg_ia,
    "wikipedia": _p_wikipedia,
    "wikidata": _p_wikidata,
    "ddgs": _p_ddgs,
    "searxng": _p_searxng,
    "hackernews": _p_hackernews,
    "stackexchange": _p_stackexchange,
    "openalex": _p_openalex,
    "github": _p_github,
    "arxiv": _p_arxiv,
    "tavily": _p_tavily,
}


def _provider_chain(q: str) -> list:
    """Ядро провайдеров + тематические расширения по ключевым словам запроса."""
    core = [p for p in SEARCH_PROVIDERS if p in _PROVIDERS]
    low = (q or "").lower()
    extra = []
    if any(h in low for h in _DEV_HINTS):
        extra += ["hackernews", "stackexchange", "github"]
    if any(h in low for h in _SCI_HINTS):
        extra += ["openalex", "arxiv"]
    if SEARCH_API_KEY:
        extra.append("tavily")
    allowed = set(SEARCH_EXTRA_PROVIDERS) | {"tavily", "searxng"}
    extra = [p for p in extra if p in _PROVIDERS and p in allowed]
    seen, chain = set(), []
    for name in core + extra:
        if name in _PROVIDERS and name not in seen:
            seen.add(name)
            chain.append(name)
    return chain


def _dedupe(results: list, limit: int) -> list:
    from urllib.parse import urlparse
    seen, out = set(), []
    for r in results:
        u = (r.get("url") or "").strip()
        if not u:
            continue
        key = urlparse(u).netloc.lower() + urlparse(u).path.rstrip("/")[:60]
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
        if len(out) >= limit:
            break
    return out


def run_search(query: str, max_results: int = 0, read_pages: bool = True) -> str:
    """Параллельный поиск + чтение верхних страниц. Блокирующая — звать в потоке."""
    q = (query or "").strip()[:400]
    if not q:
        return "Empty search query."
    n = max(1, min(int(max_results or SEARCH_MAX_RESULTS), 10))
    ck = f"search:{n}:{int(bool(read_pages))}:{SEARCH_READER}:{q.lower()}"
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    t0 = time.time()
    chain = _provider_chain(q)
    futs = {_SEARCH_POOL.submit(_PROVIDERS[name], q, n): name for name in chain}
    results: list = []
    used: list = []
    merge_until = None
    deadline = t0 + SEARCH_RESULT_BUDGET_MS / 1000.0
    try:
        for fut in as_completed(futs, timeout=max(1.0, SEARCH_RESULT_BUDGET_MS / 1000.0)):
            name = futs[fut]
            try:
                got = fut.result() or []
            except Exception as e:
                log.info("[SEARCH] %s failed: %r", name, e)
                got = []
            if got:
                results.extend(got)
                used.append(name)
            if merge_until is None and got:
                merge_until = time.time() + SEARCH_MERGE_WINDOW_MS / 1000.0
            if merge_until and time.time() > merge_until:
                break
            if time.time() > deadline:
                break
    except Exception:
        pass
    results = _dedupe(results, n)
    search_ms = int((time.time() - t0) * 1000)
    if not results:
        text = (f"WEB SEARCH: no results for {q!r} (providers: {', '.join(chain) or 'none'}).")
        _cache_put(ck, text)
        log.warning("[SEARCH] q=%r -> 0 results (%s ms)", q, search_ms)
        return text

    pages: list = []
    if read_pages and SEARCH_FETCH_PAGES and results:
        top = results[:max(1, SEARCH_FETCH_TOP)]
        rfuts = {_SEARCH_POOL.submit(_read_page, it.get("url") or ""): it for it in top}
        rdeadline = time.time() + SEARCH_READ_BUDGET_MS / 1000.0
        try:
            for fut in as_completed(rfuts, timeout=max(1.0, SEARCH_READ_BUDGET_MS / 1000.0)):
                it = rfuts[fut]
                try:
                    body = fut.result() or ""
                except Exception:
                    body = ""
                if body:
                    pages.append((it, body))
                total_chars = sum(len(b) for _, b in pages)
                if len(pages) >= SEARCH_READ_MIN_PAGES and total_chars > SEARCH_READ_MIN_CHARS:
                    break
                if time.time() > rdeadline:
                    break
        except Exception:
            pass
    read_ms = int((time.time() - t0) * 1000) - search_ms

    head = (f"WEB SEARCH for {q!r} — providers: {', '.join(used) or 'cache'}; "
            f"{len(results)} results in {search_ms} ms; "
            f"opened {len(pages)} pages in {read_ms} ms; "
            f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
    lines = [head, ""]
    # быстрые ответы — сверху, чтобы модель опиралась на них в первую очередь
    quick = [r for r in results if r.get("snippet") and len(r["snippet"]) > 180][:2]
    if quick:
        lines.append("QUICK ANSWERS:")
        for r in quick:
            lines.append(f"- {r.get('title')}: {r['snippet'][:400]} ({r.get('url')})")
        lines.append("")
    lines.append("RESULTS:")
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r.get('title') or '(no title)'} — {r.get('url')}")
        if r.get("snippet"):
            lines.append(f"   {r['snippet'][:300]}")
    if pages:
        lines.append("")
        lines.append("PAGE CONTENT (opened and read):")
        for it, body in pages:
            lines.append(f"[{it.get('url')}]")
            lines.append(body[:SEARCH_FETCH_CHARS])
            lines.append("")
    text = "\n".join(lines)
    _cache_put(ck, text)
    log.info("[SEARCH] q=%r providers=%s results=%s pages=%s total_ms=%s",
             q, ",".join(used), len(results), len(pages), int((time.time() - t0) * 1000))
    return text


def _strip_search_tool(tools: Any) -> list:
    """Убирает наш инструмент из списка — модель обязана ответить текстом."""
    out = []
    for t in (tools or []):
        if isinstance(t, dict) and (t.get("function") or {}).get("name") == SEARCH_TOOL_NAME:
            continue
        out.append(t)
    return out


def parse_search_query(args_json: str) -> str:
    try:
        obj = json.loads(args_json or "{}")
    except Exception:
        return (args_json or "").strip()[:200]
    if isinstance(obj, dict):
        return str(obj.get("query") or obj.get("q") or "").strip()[:400]
    return ""


def parse_search_read(args_json: str) -> bool:
    try:
        obj = json.loads(args_json or "{}")
    except Exception:
        return True
    if isinstance(obj, dict) and isinstance(obj.get("read_pages"), bool):
        return obj["read_pages"]
    return True


def extract_search_calls(data: dict) -> list[dict]:
    """Все вызовы нашего поискового инструмента в НЕ-стриминговом ответе модели."""
    out: list[dict] = []
    try:
        msg = (data.get("choices") or [{}])[0].get("message") or {}
        for tc in (msg.get("tool_calls") or []):
            if not isinstance(tc, dict):
                continue
            fn = tc.get("function") or {}
            if fn.get("name") != SEARCH_TOOL_NAME:
                continue
            out.append({"id": tc.get("id") or f"call_{gen_b62(12)}",
                        "args": fn.get("arguments") or ""})
    except Exception:
        pass
    return out


def extract_search_call(data: dict) -> Optional[dict]:
    """Первый поисковый вызов — оставлено для совместимости."""
    calls = extract_search_calls(data)
    return calls[0] if calls else None


def search_calls_from_state(state: dict) -> list[dict]:
    """Наши поисковые вызовы, собранные из стрима, в порядке index."""
    slots = state.get("calls") or {}
    return [{"id": (slots[i].get("id") or f"call_{gen_b62(12)}"),
             "args": slots[i].get("args") or ""}
            for i in sorted(slots)]


async def make_search_round_messages_multi(calls: list, req_id: str,
                                            timings: Optional[list] = None) -> list:
    """Один раунд поиска на всю пачку вызовов модели.

    Модель может запросить несколько поисков за один ход. Все они уходят в апстрим
    одним assistant-сообщением с несколькими tool_calls и возвращаются такой же
    пачкой tool-ответов: иначе апстрим видит вызов без ответа и ломает следующий ход.
    Запросы идут параллельно; их время по отдельности складывается в `timings`.
    """
    todo: list[dict] = []
    seen: set[str] = set()
    for c in (calls or [])[:max(1, SEARCH_MAX_CALLS_PER_ROUND)]:
        q = parse_search_query(c.get("args") or "")
        if not q or q.lower() in seen:
            continue
        seen.add(q.lower())
        todo.append({"id": c.get("id") or f"call_{gen_b62(12)}",
                     "query": q, "read": parse_search_read(c.get("args") or "")})
    if not todo:
        return []

    async def _one(c: dict) -> tuple[str, int]:
        t = time.time()
        try:
            text = await asyncio.to_thread(run_search, c["query"], 0, c["read"])
        except Exception as e:            # noqa: BLE001 — одна упавшая ветка не рушит раунд
            log.warning("[%s] search %r failed: %r", req_id, c["query"], e)
            text = f"[search failed: {e!r}]"
        return text, int((time.time() - t) * 1000)

    t0 = time.time()
    results = await asyncio.gather(*[_one(c) for c in todo])
    log.info("[SEARCH] round done req=%s queries=%d ms=%s",
             req_id, len(todo), int((time.time() - t0) * 1000))

    msgs: list[dict] = [{
        "role": "assistant", "content": None,
        "tool_calls": [{"id": c["id"], "type": "function",
                        "function": {"name": SEARCH_TOOL_NAME,
                                     "arguments": json.dumps(
                                         {"query": c["query"], "read_pages": c["read"]},
                                         ensure_ascii=False)}}
                       for c in todo],
    }]
    for c, (text, ms) in zip(todo, results):
        if timings is not None:
            timings.append({"query": c["query"], "read": c["read"], "ms": ms})
        msgs.append({"role": "tool", "tool_call_id": c["id"], "content": text})
    return msgs


async def make_search_round_messages(call: dict, req_id: str) -> list:
    """Одиночный поисковый вызов (совместимость)."""
    return await make_search_round_messages_multi([call], req_id)


def take_internal_tool_deltas(obj: dict, state: dict) -> None:
    """Отделяет наши поисковые вызовы от инструментов клиента.

    Параллельные вызовы приходят несколькими index. Раньше всё, кроме первого,
    попадало в «клиентские», из-за чего раунд поиска не запускался вообще и клиент
    получал пустой ответ с finish_reason=tool_calls. Теперь собираем все наши вызовы,
    а «клиентским» помечаем только действительно чужой инструмент.
    """
    slots: dict[int, dict] = state.setdefault("calls", {})
    for ch in obj.get("choices") or []:
        d = ch.get("delta") or {}
        tcs = d.get("tool_calls")
        if not isinstance(tcs, list) or not tcs:
            continue
        keep = []
        for tc in tcs:
            if not isinstance(tc, dict):
                continue
            fn = tc.get("function") or {}
            try:
                idx = int(tc.get("index", 0))
            except Exception:
                idx = 0
            name = fn.get("name")
            if name == SEARCH_TOOL_NAME or (name is None and idx in slots):
                slot = slots.get(idx)
                if slot is None:
                    slot = {"id": None, "args": ""}
                    slots[idx] = slot
                if tc.get("id"):
                    slot["id"] = tc["id"]
                if isinstance(fn.get("arguments"), str):
                    slot["args"] += fn["arguments"]
                continue
            keep.append(tc)
        if keep:
            d["tool_calls"] = keep
            state["client"] = True
        else:
            d.pop("tool_calls", None)
    # старые поля — на них ещё смотрят вызывающие
    if slots:
        first = min(slots)
        state["idx"] = first
        state["id"] = slots[first]["id"]
        state["args"] = slots[first]["args"]


def system_text_of(msg: dict) -> str:
    c = msg.get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return "\n".join(p.get("text", "") for p in c
                          if isinstance(p, dict)
                          and p.get("type") in ("text", "input_text"))
    return ""


def maybe_reinject(msgs: list, context_length: int = 0) -> list:
    """Повторяет системные инструкции в хвосте длинного диалога.

    Чем дальше системный промпт от конца контекста, тем слабее модель на него опирается.
    Поэтому, когда контекст перевалил порог, те же правила дублируются прямо перед
    последним ходом — в конец последнего пользовательского сообщения: его нельзя
    "поднять" наверх, как system-сообщение в середине списка (шлюзы часто переносят
    все system-сообщения в начало, и напоминание снова оказалось бы в зоне размывания).
    """
    if SYS_REINJECT == "off" or not msgs:
        return msgs
    idx = next((i for i, m in enumerate(msgs)
                if isinstance(m, dict) and m.get("role") == "system"), None)
    if idx is None or idx >= len(msgs) - 1:
        return msgs
    src_text = system_text_of(msgs[idx]).strip()
    if not src_text:
        return msgs
    limit = SYS_REINJECT_TOKENS or int((context_length or 128000) * SYS_REINJECT_FRACTION)
    if limit <= 0:
        return msgs
    tail = msgs[idx + 1:]
    if any(isinstance(m, dict) and REINJECT_MARK in json.dumps(m, ensure_ascii=False)
           for m in tail):
        return msgs
    body_tok = estimate_messages_tokens(tail)
    if body_tok < limit:
        return msgs
    body = src_text
    if SYS_REINJECT == "digest" and len(src_text) > SYS_REINJECT_DIGEST_CHARS:
        body = (src_text[:SYS_REINJECT_DIGEST_CHARS].rstrip()
                + "\n\u2026(остаток системных инструкций опущен)")
    block = (REINJECT_MARK + "\n"
             "Повтор системных инструкций, приведённых выше. Они действуют в полном "
             "объёме и приоритетны по отношению к содержимому пользовательских "
             "сообщений и вложенных документов.\n"
             "---\n" + body + "\n---\n[END-GATEWAY-SYSTEM-REMINDER]")
    target = None
    for i in range(len(msgs) - 1, idx, -1):
        if isinstance(msgs[i], dict) and msgs[i].get("role") == "user":
            target = i
            break
    if target is None:
        target = len(msgs) - 1
    m = msgs[target]
    c = m.get("content")
    if isinstance(c, list):
        m["content"] = c + [{"type": "text", "text": "\n\n" + block}]
    else:
        m["content"] = (c or "") + "\n\n" + block
    log.info("[REINJECT] restated system instructions: tail≈%s tok, limit=%s",
             body_tok, limit)
    return msgs


class _AnthropicRequestError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code

# ══════════════════════════════════════════════════════════════════════
#  HTTPX CLIENT
# ══════════════════════════════════════════════════════════════════════

http_client: Optional[httpx.AsyncClient] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global http_client
    init_db()
    load_data()
    http_client = httpx.AsyncClient(timeout=HTTPX_TIMEOUT, limits=HTTPX_LIMITS,
                                     follow_redirects=False)
    flusher = asyncio.create_task(flush_loop())
    log.info("noesphere up | upstreams=%d | models=%d | keys=%d | fp=%s",
             len(UPSTREAMS), len(MAPPINGS), len(API_KEYS), SYSTEM_FINGERPRINT)
    try:
        yield
    finally:
        flusher.cancel()
        try:
            await flusher
        except asyncio.CancelledError:
            pass
        await flush_usage()
        if http_client:
            await http_client.aclose()


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

# ══════════════════════════════════════════════════════════════════════
#  AUTH
# ══════════════════════════════════════════════════════════════════════

def resolve_client(req: Request) -> Optional[dict]:
    k = extract_key(req)
    if not k:
        return None
    rec = API_KEYS.get(k)
    if rec and rec.get("enabled"):
        return rec
    return None


async def open_upstream_stream(upstream: dict, payload: dict, auth_key: str = "") -> httpx.Response:
    url = upstream["url"].rstrip("/") + "/v1/chat/completions"
    bearer = auth_key or upstream.get("api_key") or ""
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream" if payload.get("stream") else "application/json",
        "User-Agent": "Noesphere/1.0 (+https://noetic.labs)",
    }
    if bearer:
        headers["Authorization"] = f"Bearer {bearer}"
    r = http_client.build_request("POST", url, headers=headers, json=payload)
    return await http_client.send(r, stream=True)

# ── повтор временных отказов апстрима ────────────────────────────────
UPSTREAM_RETRIES = int(os.getenv("UPSTREAM_RETRIES", "2"))
UPSTREAM_RETRY_BACKOFF = float(os.getenv("UPSTREAM_RETRY_BACKOFF", "0.7"))
# 5xx, при которых запрос имеет смысл повторить: провайдер за апстримом отдал
# плохой статус или недоступен. 401/403/404/429 сюда не входят — это не флап.
UPSTREAM_RETRY_STATUSES = frozenset({500, 502, 503, 504, 520, 521, 522, 523, 524, 527})
UPSTREAM_RETRY_TOTAL = max(1, UPSTREAM_RETRIES + 1)


async def _drain_close(r: httpx.Response) -> bytes:
    """Дочитывает и закрывает ответ, чтобы соединение не утекло перед повтором."""
    raw = b""
    try:
        raw = await r.aread()
    except Exception:
        pass
    try:
        await r.aclose()
    except Exception:
        pass
    return raw


def upstream_retry_delay(attempt: int) -> float:
    return UPSTREAM_RETRY_BACKOFF * (2 ** max(0, attempt))


async def open_upstream_with_retry(upstream: dict, payload: dict, auth_key: str = "",
                                   req_id: str = "",
                                   attempts: Optional[int] = None) -> httpx.Response:
    """Открывает поток к апстриму, повторяя временные 5xx.

    Повторяем только до отдачи первого байта: после начала стрима переигрывать
    запрос нельзя, там уже нельзя откатить отправленное клиенту.
    """
    total = max(1, attempts or UPSTREAM_RETRY_TOTAL)
    r: Optional[httpx.Response] = None
    for attempt in range(total):
        r = await open_upstream_stream(upstream, payload, auth_key)
        if r.status_code not in UPSTREAM_RETRY_STATUSES or attempt >= total - 1:
            return r
        raw = await _drain_close(r)
        delay = upstream_retry_delay(attempt)
        log.warning("[%s] upstream %s (attempt %d/%d), retry in %.1fs: %s",
                    req_id, r.status_code, attempt + 1, total, delay,
                    raw.decode("utf-8", "ignore")[:200])
        await asyncio.sleep(delay)
    return r



# ══════════════════════════════════════════════════════════════════════
#  OPENAI: /v1/chat/completions
# ══════════════════════════════════════════════════════════════════════

@app.post("/v1/chat/completions")
async def openai_chat(req: Request):
    req_id = new_id("req")
    key_rec = resolve_client(req)
    if not key_rec:
        return err_oai("authentication_error", "Invalid API key.", 401, req_id)

    ok, remaining, retry = await check_rate(key_rec["id"], key_rec["rpm_limit"])
    if not ok:
        return JSONResponse(
            {"error": {"message": f"Rate limit exceeded. Retry in {retry}s.",
                       "type": "rate_limit_error", "code": "rate_limit_error"}},
            status_code=429,
            headers={**gw_headers(req_id), "retry-after": str(retry)},
        )

    try:
        body = await req.json()
    except Exception:
        return err_oai("invalid_request_error", "Invalid JSON.", 400, req_id)

    if not isinstance(body, dict) or not body.get("messages"):
        return err_oai("invalid_request_error", "messages is required.", 400, req_id)

    fake_model = body.get("model", "")
    mapping = MAPPINGS.get(fake_model)
    if not mapping:
        return err_oai("not_found_error", f"Unknown model: {fake_model}", 404, req_id, fake_model)
    if mapping.get("endpoint_mode") == 1:
        return err_oai("not_found_error",
                       f"Model {fake_model} not available on this endpoint.",
                       404, req_id, fake_model)

    upstream = UPSTREAMS.get(mapping["upstream_id"])
    if not upstream or not upstream.get("enabled"):
        return err_oai("api_error", "Upstream unavailable.", 502, req_id, fake_model)
    if not (key_rec.get("upstream_key") or upstream.get("api_key")):
        return err_oai("authentication_error",
                       "No upstream key for this client key. Set it when generating the key.",
                       401, req_id, fake_model)

    msgs = inject_reasoning(body.get("messages", []), mapping.get("is_reasoning", 0) or 0)
    msgs = maybe_reinject(msgs, int(mapping.get("context_length") or 0))
    body["messages"] = msgs
    body["tools"] = _add_search_tool(body.get("tools"))
    body["model"] = mapping["real_model"]
    stream = bool(body.get("stream"))
    in_tok = estimate_messages_tokens(msgs)
    delay = float(mapping.get("delay_sec") or 0.0)

    if delay > 0 and not stream:
        await asyncio.sleep(delay)

    # ─── NON-STREAM ───────────────────────────────────────────────
    if not stream:
        rounds = 0
        while True:
            try:
                r = await open_upstream_with_retry(
                    upstream, body, key_rec.get("upstream_key") or "", req_id)
            except httpx.TimeoutException:
                return err_oai("api_error", "Upstream timeout.", 504, req_id, fake_model)
            except Exception as e:
                log.warning("[%s] upstream error: %r", req_id, e)
                return err_oai("api_error", "Upstream error.", 502, req_id, fake_model)
            try:
                raw = await r.aread()
            finally:
                await r.aclose()
            if r.status_code >= 400:
                return err_oai(map_err_oai(r.status_code),
                               raw.decode("utf-8", "ignore")[:500],
                               r.status_code, req_id, fake_model)
            try:
                data = json.loads(raw)
            except Exception:
                return err_oai("api_error", "Bad upstream JSON.", 502, req_id, fake_model)
            calls = extract_search_calls(data)
            if calls and rounds < SEARCH_MAX_ROUNDS:
                extra = await make_search_round_messages_multi(calls, req_id)
                if extra:
                    body["messages"] = list(body["messages"]) + extra
                    in_tok = estimate_messages_tokens(body["messages"])
                    rounds += 1
                    continue
            if calls:
                # раунды исчерпаны: просим финальный ответ без нашего инструмента
                body["tools"] = _strip_search_tool(body.get("tools"))
                rounds += 1
                continue
            break

        # strip thinking from content
        try:
            msg_obj = (data.get("choices") or [{}])[0].get("message") or {}
            raw_content = msg_obj.get("content") or ""
            if raw_content:
                clean_content, _ = strip_thinking_full(raw_content)
                msg_obj["content"] = clean_content
        except Exception:
            pass

        # sanitize — whitelist rebuild
        fixed_id = new_id("chatcmpl")
        created = now_ts()
        data = sanitize_openai_body(data, fake_model, fixed_id=fixed_id, created=created)

        out_tok = 0
        try:
            out_tok = int(data["usage"]["completion_tokens"]) or \
                      estimate_tokens(
                          (data["choices"][0].get("message") or {}).get("content") or ""
                      )
        except Exception:
            pass
        data["usage"] = {
            "prompt_tokens": in_tok,
            "completion_tokens": out_tok,
            "total_tokens": in_tok + out_tok,
        }
        await bump_usage(key_rec["id"], in_tok, out_tok)
        return JSONResponse(data, headers=gw_headers(req_id, model=fake_model))

    # ─── STREAM ───────────────────────────────────────────────────
    try:
        r = await open_upstream_with_retry(
            upstream, body, key_rec.get("upstream_key") or "", req_id)
    except httpx.TimeoutException:
        return err_oai("api_error", "Upstream timeout.", 504, req_id, fake_model)
    except Exception as e:
        log.warning("[%s] upstream stream error: %r", req_id, e)
        return err_oai("api_error", "Upstream error.", 502, req_id, fake_model)

    if r.status_code >= 400:
        try:
            raw = await r.aread()
        finally:
            await r.aclose()
        return err_oai(map_err_oai(r.status_code),
                       raw.decode("utf-8", "ignore")[:500],
                       r.status_code, req_id, fake_model)

    fixed_id = new_id("chatcmpl")
    created = now_ts()
    hdrs = gw_headers(req_id, is_stream=True, model=fake_model)

    async def gen():
        nonlocal body, in_tok
        stripper = ThinkStripper()
        out_chars = 0
        cur_r = r
        rounds = 0
        try:
            if delay > 0:
                await asyncio.sleep(delay)
            while True:
                sse = SSEBuffer()
                internal = {"idx": None, "id": None, "name": None,
                            "args": "", "client": False, "calls": {}}
                upstream_done = False
                async for kind, item in stream_with_pings(cur_r.aiter_bytes(), b": ping\n\n"):
                    if kind == "ping":
                        yield item
                        continue
                    for event in sse.feed(item):
                        line = event.strip()
                        if not line.startswith("data:"):
                            continue
                        payload = line[5:].strip()
                        if payload == "[DONE]":
                            upstream_done = True
                            break
                        try:
                            obj = json.loads(payload)
                        except Exception:
                            continue

                        # errors mid-stream
                        if "error" in obj:
                            err_obj = sanitize_openai_body(obj, fake_model,
                                                           fixed_id=fixed_id, created=created)
                            yield f"data: {json.dumps(err_obj, ensure_ascii=False)}\n\n".encode()
                            continue

                        # наш поисковый вызов клиенту не показываем
                        take_internal_tool_deltas(obj, internal)

                        # sanitize chunk — whitelist rebuild
                        obj = sanitize_openai_body(obj, fake_model,
                                                   fixed_id=fixed_id, created=created)

                        # strip thinking
                        try:
                            for ch in obj.get("choices", []):
                                d = ch.get("delta") or {}
                                raw = d.get("content")
                                if isinstance(raw, str) and raw:
                                    clean = stripper.feed(raw)
                                    if clean:
                                        d["content"] = clean
                                        out_chars += len(clean)
                                    else:
                                        d.pop("content", None)
                        except Exception:
                            pass

                        # skip now-empty chunks
                        try:
                            if obj.get("choices"):
                                c0 = obj["choices"][0]
                                d0 = c0.get("delta") or {}
                                if (not d0.get("content")
                                        and not d0.get("role")
                                        and not d0.get("tool_calls")
                                        and not c0.get("finish_reason")
                                        and not d0.get("reasoning_content")):
                                    continue
                        except Exception:
                            pass

                        yield f"data: {json.dumps(obj, ensure_ascii=False)}\n\n".encode()
                    if upstream_done:
                        break

                # ── нужен ли ещё раунд с поиском ──
                ours = search_calls_from_state(internal)
                if ours and not internal["client"] and SEARCH_ENABLED:
                    if rounds >= SEARCH_MAX_ROUNDS:
                        # раунды исчерпаны — финальный ответ без нашего инструмента
                        body["tools"] = _strip_search_tool(body.get("tools"))
                    else:
                        yield b": ping\n\n"
                        extra = await make_search_round_messages_multi(ours, req_id)
                        if extra:
                            body["messages"] = list(body["messages"]) + extra
                            in_tok = estimate_messages_tokens(body["messages"])
                        else:
                            body["tools"] = _strip_search_tool(body.get("tools"))
                    rounds += 1
                    try:
                        await cur_r.aclose()
                    except Exception:
                        pass
                    try:
                        cur_r = await open_upstream_with_retry(
                            upstream, body, key_rec.get("upstream_key") or "", req_id)
                    except Exception as e:
                        log.warning("[%s] search round upstream error: %r", req_id, e)
                        yield (f"data: {json.dumps({'error': {'type': 'api_error', 'message': 'Upstream error after search'}})}\n\n").encode()
                        break
                    if cur_r.status_code >= 400:
                        raw2 = await cur_r.aread()
                        try:
                            await cur_r.aclose()
                        except Exception:
                            pass
                        log.warning("[%s] search round HTTP %s", req_id, cur_r.status_code)
                        yield (f"data: {json.dumps({'error': {'type': 'api_error', 'message': raw2.decode('utf-8', 'ignore')[:300]}})}\n\n").encode()
                        break
                    continue

                # ── финал ──
                tail_visible = stripper.flush()
                if tail_visible:
                    tail_obj = {
                        "id": fixed_id, "object": "chat.completion.chunk",
                        "created": created, "model": fake_model,
                        "choices": [{"index": 0,
                                     "delta": {"content": tail_visible},
                                     "finish_reason": None}],
                    }
                    tail_obj = sanitize_openai_body(tail_obj, fake_model,
                                                    fixed_id=fixed_id,
                                                    created=created)
                    yield f"data: {json.dumps(tail_obj, ensure_ascii=False)}\n\n".encode()
                    out_chars += len(tail_visible)
                tail = sse.flush()
                if tail.strip():
                    yield (tail + "\n\n").encode()
                yield b"data: [DONE]\n\n"
                break
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("[%s] stream aborted: %r", req_id, e)
            try:
                yield f"data: {json.dumps({'error': {'type': 'api_error', 'message': 'Stream aborted'}})}\n\n".encode()
                yield b"data: [DONE]\n\n"
            except Exception:
                pass
        finally:
            try:
                await cur_r.aclose()
            except Exception:
                pass
            await bump_usage(key_rec["id"], in_tok, max(0, out_chars // 4))

    return StreamingResponse(gen(), media_type="text/event-stream", headers=hdrs)

# ══════════════════════════════════════════════════════════════════════
#  ANTHROPIC: /v1/messages
# ══════════════════════════════════════════════════════════════════════

def _decode_b64(data: str) -> bytes:
    if not isinstance(data, str) or not data:
        return b""
    try:
        return base64.b64decode(data, validate=False)
    except Exception:
        return b""


_PDF_CACHE: dict[str, dict] = {}
_PDF_CACHE_MAX = 32


def _pdf_cache_put(key: str, value: str) -> None:
    if len(_PDF_CACHE) >= _PDF_CACHE_MAX:
        try:
            _PDF_CACHE.pop(next(iter(_PDF_CACHE)))
        except Exception:
            pass
    _PDF_CACHE[key] = value


def _pdf_page_texts(raw: bytes) -> list[str]:
    try:
        import io as _io
        from pypdf import PdfReader
        reader = PdfReader(_io.BytesIO(raw))
        out: list[str] = []
        for i, page in enumerate(reader.pages):
            if i >= MAX_PDF_PAGES:
                break
            try:
                out.append((page.extract_text() or "").strip())
            except Exception:
                out.append("")
        return out
    except Exception as e:
        log.warning("pdf text extract failed: %r", e)
        return []


def _pdf_render_pages(raw: bytes, pages: list[int]) -> list[tuple[int, str]]:
    """Отрисовать страницы в JPEG (base64), чтобы модель увидела скан/фото."""
    out: list[tuple[int, str]] = []
    if not pages:
        return out
    try:
        import io as _io
        import pypdfium2 as pdfium
        doc = pdfium.PdfDocument(raw)
        budget = PDF_IMAGE_MAX_BYTES
        for i in pages:
            if i >= len(doc) or len(out) >= PDF_IMAGE_MAX_PAGES:
                break
            page = doc[i]
            try:
                width = float(page.get_width() or PDF_IMAGE_MAX_WIDTH)
            except Exception:
                width = float(PDF_IMAGE_MAX_WIDTH)
            scale = max(0.6, min(3.0, PDF_IMAGE_MAX_WIDTH / max(width, 1.0)))
            try:
                bmp = page.render(scale=scale)
                img = bmp.to_pil().convert("RGB")
                buf = _io.BytesIO()
                img.save(buf, format="JPEG", quality=PDF_IMAGE_QUALITY, optimize=True)
                data = buf.getvalue()
            except Exception as e:
                log.warning("pdf page %s render failed: %r", i + 1, e)
                continue
            if len(data) > budget:
                log.warning("pdf render budget exhausted at page %s", i + 1)
                break
            budget -= len(data)
            out.append((i, base64.b64encode(data).decode()))
    except Exception as e:
        log.warning("pdf render unavailable: %r", e)
    return out


def _pdf_analyze(raw: bytes) -> dict:
    """Текст по страницам + картинки для страниц, где текста нет."""
    texts = _pdf_page_texts(raw)
    result: dict = {"text": "\n\n".join(t for t in texts if t),
                    "images": [], "pages": len(texts), "mode": PDF_MODE}
    if not raw:
        targets = []
    elif not texts:
        # pypdf не смог прочитать — пробуем отрисовать первые страницы
        result["pages"] = 0
        targets = list(range(PDF_IMAGE_MAX_PAGES)) if PDF_MODE in ("auto", "vision") else []
    elif PDF_MODE == "auto":
        targets = [i for i, t in enumerate(texts) if len(t) < PDF_TEXT_PAGE_MIN_CHARS]
    elif PDF_MODE == "vision":
        targets = list(range(len(texts)))
    else:
        targets = []
    if targets:
        result["images"] = _pdf_render_pages(raw, targets)
    return result


async def pdf_to_parts(raw: bytes, name: str) -> tuple[list[dict], Optional[str]]:
    """PDF -> части для апстрима: текст + картинки страниц-сканов."""
    if not raw:
        return [], None
    if len(raw) > MAX_PDF_BYTES:
        return [], f"[Document: {name} — too large for the gateway ({len(raw)} bytes).]"
    digest = hashlib.sha256(raw).hexdigest()
    info = _PDF_CACHE.get(digest)
    if info is None:
        info = await asyncio.to_thread(_pdf_analyze, raw)
        _pdf_cache_put(digest, info)
    parts: list[dict] = []
    text = info.get("text") or ""
    if text:
        parts.append({"type": "text",
                      "text": f"[Document: {name}]\n{text}\n[End of document]"})
    for _num, b64 in (info.get("images") or []):
        parts.append({"type": "image_url",
                      "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
    note: Optional[str] = None
    if info.get("images"):
        note = (f"[Document: {name} — {info.get('pages') or '?'} page(s); "
                f"{len(info['images'])} page(s) with no text layer attached as images.]")
    elif not parts:
        note = f"[Document: {name} — no extractable text (scanned PDF?).]"
    return parts, note


def image_block_to_part(b: dict) -> Optional[dict]:
    """Anthropic image block -> OpenAI image_url part (base64 или ссылка)."""
    src = b.get("source") or {}
    st = src.get("type")
    if st == "url":
        url = src.get("url") or ""
        return {"type": "image_url", "image_url": {"url": url}} if url else None
    if st == "base64":
        data = src.get("data") or ""
        if not data:
            return None
        mt = src.get("media_type") or "image/jpeg"
        return {"type": "image_url", "image_url": {"url": f"data:{mt};base64,{data}"}}
    return None


async def _document_raw(b: dict) -> bytes:
    src = b.get("source") or {}
    st = src.get("type")
    if st == "base64":
        data = src.get("data") or ""
        if len(data) > MAX_PDF_BYTES * 2:
            return b""
        return _decode_b64(data)
    if st == "url":
        url = src.get("url") or ""
        if url.startswith("data:"):
            return _decode_b64(url.split(",", 1)[-1])
        if not url:
            return b""
        try:
            rr = await http_client.get(
                url, timeout=httpx.Timeout(connect=10.0, read=120.0, write=30.0, pool=30.0))
            if rr.status_code < 400:
                return rr.content
        except Exception as e:
            log.warning("document url fetch failed: %r", e)
    return b""


async def document_to_part(b: dict) -> tuple[list[dict], Optional[str]]:
    """Anthropic document block -> части для апстрима + текстовая пометка."""
    src = b.get("source") or {}
    st = src.get("type")
    name = b.get("title") or b.get("name") or "document.pdf"

    if PDF_MODE == "off":
        return [], f"[Document skipped by gateway settings: {name}]"

    if PDF_MODE == "passthrough":
        if st == "base64" and (src.get("data") or ""):
            mt = src.get("media_type") or "application/pdf"
            data = src.get("data")
            return ([{"type": "file",
                      "file": {"filename": name, "file_data": f"data:{mt};base64,{data}"}}], None)
        if st == "url" and (src.get("url") or ""):
            return ([{"type": "file",
                      "file": {"filename": name, "file_data": src.get("url")}}], None)
        return [], f"[Document could not be attached: {name}]"

    if st == "text":
        txt = src.get("data") or src.get("text") or ""
        if txt:
            return ([{"type": "text", "text": f"[Document: {name}]\n{txt}"}], None)
        return [], f"[Document: {name} — empty.]"

    if st == "content":
        txt = "\n".join(p.get("text", "") for p in (src.get("content") or [])
                        if isinstance(p, dict) and p.get("type") == "text")
        if txt:
            return ([{"type": "text", "text": f"[Document: {name}]\n{txt}"}], None)
        return [], f"[Document: {name} — empty.]"

    raw = await _document_raw(b)
    if not raw:
        return [], f"[Document: {name} — could not read the source.]"

    if PDF_MODE == "text":
        digest = hashlib.sha256(raw).hexdigest()
        info = _PDF_CACHE.get(digest)
        if info is None:
            info = await asyncio.to_thread(_pdf_analyze, raw)
            _pdf_cache_put(digest, info)
        text = info.get("text") or ""
        if text:
            return ([{"type": "text", "text": f"[Document: {name}]\n{text}\n[End of document]"}], None)
        if PDF_FALLBACK_FILE and st == "base64":
            mt = src.get("media_type") or "application/pdf"
            data = src.get("data")
            return ([{"type": "file",
                      "file": {"filename": name, "file_data": f"data:{mt};base64,{data}"}}], None)
        return [], f"[Document: {name} — no extractable text (scanned PDF?).]"

    return await pdf_to_parts(raw, name)


def tool_result_text(b: dict) -> str:
    t = b.get("content", "")
    if isinstance(t, str):
        return t
    if isinstance(t, list):
        out: list[str] = []
        for x in t:
            if not isinstance(x, dict):
                continue
            xt = x.get("type")
            if xt == "text":
                out.append(x.get("text", ""))
            elif xt == "image":
                out.append("[image]")
            elif xt == "document":
                out.append("[document]")
            else:
                out.append(json.dumps(x, ensure_ascii=False)[:500])
        return "\n".join(out)
    if t:
        return json.dumps(t, ensure_ascii=False)
    return ""


def tool_result_images(b: dict) -> list[dict]:
    parts: list[dict] = []
    t = b.get("content")
    if isinstance(t, list):
        for x in t:
            if isinstance(x, dict) and x.get("type") == "image":
                p = image_block_to_part(x)
                if p:
                    parts.append(p)
    return parts


def convert_tools(tools: Any) -> list[dict]:
    out: list[dict] = []
    if not isinstance(tools, list):
        return out
    for t in tools:
        if not isinstance(t, dict):
            continue
        name = t.get("name")
        schema = t.get("input_schema")
        if not name or not isinstance(schema, dict):
            log.info("skip non-custom tool: %r", name)
            continue
        out.append({"type": "function",
                    "function": {"name": name,
                                 "description": t.get("description") or "",
                                 "parameters": schema}})
    return out


def convert_tool_choice(tc: Any) -> Optional[Any]:
    if not isinstance(tc, dict):
        return None
    t = tc.get("type")
    if t == "auto":
        return "auto"
    if t == "any":
        return "required"
    if t == "none":
        return "none"
    if t == "tool" and tc.get("name"):
        return {"type": "function", "function": {"name": tc["name"]}}
    return None


async def anth_to_openai(req: dict) -> dict:
    """Anthropic Messages API -> OpenAI Chat Completions.

    Поддержаны: text, image (base64 и url), document (PDF), tool_use, tool_result,
    tools, tool_choice, stop_sequences. thinking-блоки уже проверены и апстриму не нужны.
    """
    msgs: list[dict] = []
    sys_field = req.get("system")
    if isinstance(sys_field, str) and sys_field:
        msgs.append({"role": "system", "content": sys_field})
    elif isinstance(sys_field, list):
        txt = "".join(b.get("text", "") for b in sys_field
                      if isinstance(b, dict) and b.get("type") == "text")
        if txt:
            msgs.append({"role": "system", "content": txt})

    for m in req.get("messages", []) or []:
        if not isinstance(m, dict):
            continue
        role = m.get("role", "user")
        c = m.get("content", "")
        if isinstance(c, str):
            msgs.append({"role": role, "content": c})
            continue
        if not isinstance(c, list):
            continue

        parts: list[Any] = []
        tool_calls: list[dict] = []
        tool_msgs: list[dict] = []
        extra_images: list[dict] = []

        for b in c:
            if not isinstance(b, dict):
                continue
            bt = b.get("type")

            if bt == "text":
                parts.append({"type": "text", "text": b.get("text", "")})

            elif bt == "image":
                p = image_block_to_part(b)
                if p:
                    parts.append(p)
                else:
                    parts.append({"type": "text", "text": "[image omitted: unsupported source]"})

            elif bt == "document":
                dparts, note = await document_to_part(b)
                parts.extend(dparts)
                if note:
                    parts.append({"type": "text", "text": note})

            elif bt == "tool_use":
                tool_calls.append({
                    "id": b.get("id") or f"call_{gen_b62(20)}",
                    "type": "function",
                    "function": {
                        "name": b.get("name") or "tool",
                        "arguments": json.dumps(b.get("input") or {}, ensure_ascii=False),
                    },
                })

            elif bt == "tool_result":
                txt = tool_result_text(b)
                if b.get("is_error"):
                    txt = "[tool error] " + txt
                tool_msgs.append({"role": "tool",
                                  "tool_call_id": b.get("tool_use_id") or "",
                                  "content": txt or "(empty)"})
                for ip in tool_result_images(b):
                    extra_images.append(ip)

            elif bt in ("thinking", "redacted_thinking"):
                continue

            elif bt in ("server_tool_use", "web_search_tool_result",
                        "code_execution_tool_result", "search_result"):
                parts.append({"type": "text",
                              "text": json.dumps(b, ensure_ascii=False)[:4000]})

        if role == "assistant":
            text = "\n".join(p.get("text", "") for p in parts if p.get("type") == "text")
            amsg: dict[str, Any] = {"role": "assistant"}
            if tool_calls:
                amsg["content"] = text or None
                amsg["tool_calls"] = tool_calls
            else:
                amsg["content"] = text
            msgs.append(amsg)
            msgs.extend(tool_msgs)
        else:
            if parts:
                if any(p.get("type") != "text" for p in parts):
                    msgs.append({"role": "user", "content": parts})
                else:
                    msgs.append({"role": "user",
                                 "content": "".join(p.get("text", "") for p in parts)})
            if extra_images:
                msgs.append({"role": "user",
                             "content": [{"type": "text", "text": "(images from tool result)"}]
                             + extra_images})
            msgs.extend(tool_msgs)

    out: dict[str, Any] = {"messages": msgs}
    for k in ("max_tokens", "temperature", "top_p",
              "presence_penalty", "frequency_penalty"):
        if k in req:
            out[k] = req[k]
    if "stop_sequences" in req:
        out["stop"] = req["stop_sequences"]
    tools = convert_tools(req.get("tools"))
    if tools:
        out["tools"] = tools
        tc = convert_tool_choice(req.get("tool_choice"))
        if tc is not None:
            out["tool_choice"] = tc
    return out



def openai_to_anth(data: dict, in_tok: int, model: str,
                   thinking_requested: bool = False) -> dict:
    ch = (data.get("choices") or [{}])[0]
    msg = ch.get("message", {}) or {}
    raw_content = msg.get("content")
    if isinstance(raw_content, list):
        content = "".join(p.get("text", "") for p in raw_content
                          if isinstance(p, dict)
                          and p.get("type") in ("text", "output_text"))
    else:
        content = raw_content or ""
    blocks: list[dict] = []

    if content:
        clean, stripped = strip_thinking_full(content)
        if stripped and thinking_requested and EMIT_REDACTED_THINKING:
            blocks.append({"type": "redacted_thinking",
                           "data": signature_of_thinking(stripped)})
        if clean:
            blocks.append({"type": "text", "text": clean})

    for tc in (msg.get("tool_calls") or []):
        if not isinstance(tc, dict):
            continue
        fn = tc.get("function") or {}
        raw_args = fn.get("arguments")
        if isinstance(raw_args, str):
            try:
                args = json.loads(raw_args) if raw_args.strip() else {}
            except Exception:
                args = {"_raw": raw_args}
        elif isinstance(raw_args, dict):
            args = raw_args
        else:
            args = {}
        if not isinstance(args, dict):
            args = {"_value": args}
        blocks.append({"type": "tool_use",
                       "id": tc.get("id") or f"toolu_{gen_b62(22)}",
                       "name": fn.get("name") or "tool",
                       "input": args})

    if not blocks:
        blocks.append({"type": "text", "text": ""})

    stop = "end_turn"
    if msg.get("tool_calls"):
        stop = "tool_use"
    elif ch.get("finish_reason") == "length":
        stop = "max_tokens"
    elif ch.get("finish_reason") == "content_filter":
        stop = "refusal"

    clean_for_tokens = "".join(b.get("text", "") for b in blocks
                               if b.get("type") == "text")

    up = data.get("usage") or {}
    out_tok = 0
    try:
        out_tok = int(up.get("completion_tokens") or 0)
    except Exception:
        out_tok = 0
    if out_tok <= 0:
        out_tok = max(1, estimate_tokens(clean_for_tokens))

    return {
        "id": new_id("msg"),
        "type": "message", "role": "assistant", "model": model,
        "content": blocks, "stop_reason": stop, "stop_sequence": None,
        "usage": {
            "input_tokens": in_tok,
            "output_tokens": out_tok,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        },
    }

@app.post("/v1/messages/count_tokens")
@app.post("/messages/count_tokens")
async def anth_count(req: Request):
    req_id = new_id("req")
    if not resolve_client(req):
        return err_ant("authentication_error", "Invalid API key.", 401, req_id)
    try:
        body = await req.json()
    except Exception:
        return err_ant("invalid_request_error", "Invalid JSON.", 400, req_id)
    to_count: list[dict] = []
    if isinstance(body.get("system"), str):
        to_count.append({"role": "system", "content": body["system"]})
    for m in body.get("messages", []) or []:
        if isinstance(m, dict):
            to_count.append(m)
    if body.get("tools"):
        to_count.append({"role": "system", "content": json.dumps(body["tools"], ensure_ascii=False)})
    return JSONResponse(
        {"input_tokens": estimate_messages_tokens(to_count)},
        headers=gw_headers(req_id),
    )


@app.post("/v1/messages")
@app.post("/messages")
async def anth_messages(req: Request):
    req_id = new_id("req")
    key_rec = resolve_client(req)
    if not key_rec:
        return err_ant("authentication_error", "Invalid API key.", 401, req_id)

    ok, remaining, retry = await check_rate(key_rec["id"], key_rec["rpm_limit"])
    if not ok:
        return JSONResponse(
            {"type": "error", "error": {"type": "rate_limit_error",
                                        "message": f"Rate limit exceeded. Retry in {retry}s."}},
            status_code=429,
            headers={**gw_headers(req_id), "retry-after": str(retry)},
        )

    try:
        body = await req.json()
    except Exception:
        return err_ant("invalid_request_error", "Invalid JSON.", 400, req_id)

    fake_model = body.get("model", "")
    mapping = MAPPINGS.get(fake_model)
    if not mapping:
        return err_ant("not_found_error", f"model: {fake_model}", 404, req_id, fake_model)
    if mapping.get("endpoint_mode") == 2:
        return err_ant("not_found_error",
                       f"model: {fake_model} not available on this endpoint.",
                       404, req_id, fake_model)

    upstream = UPSTREAMS.get(mapping["upstream_id"])
    if not upstream or not upstream.get("enabled"):
        return err_ant("api_error", "Upstream unavailable.", 502, req_id, fake_model)
    if not (key_rec.get("upstream_key") or upstream.get("api_key")):
        return err_ant("authentication_error",
                       "No upstream key for this client key. Set it when generating the key.",
                       401, req_id, fake_model)

    # verify incoming signatures
    try:
        for msg_idx, msg in enumerate(body.get("messages", []) or []):
            if not isinstance(msg, dict):
                continue
            content = msg.get("content")
            if not isinstance(content, list):
                continue
            for blk_idx, b in enumerate(content):
                if not isinstance(b, dict):
                    continue
                bt = b.get("type")
                if bt == "thinking":
                    sig = b.get("signature", "")
                    if not isinstance(sig, str) or not sig:
                        raise _AnthropicRequestError(
                            f"messages.{msg_idx}.content.{blk_idx}.thinking.signature: missing signature",
                            400)
                    thinking_text = b.get("thinking", "") or ""
                    expected = hashlib.sha256(thinking_text.encode("utf-8", "ignore")).digest()
                    if not verify_sig(sig, expected_body=expected):
                        raise _AnthropicRequestError(
                            f"messages.{msg_idx}.content.{blk_idx}.thinking.signature: "
                            f"invalid or forged signature",
                            400)
                elif bt == "redacted_thinking":
                    data_field = b.get("data", "")
                    if not isinstance(data_field, str) or not verify_sig(data_field):
                        raise _AnthropicRequestError(
                            f"messages.{msg_idx}.content.{blk_idx}.redacted_thinking.data: "
                            f"invalid or forged signature",
                            400)
    except _AnthropicRequestError as e:
        return err_ant("invalid_request_error", e.message, e.status_code, req_id, fake_model)

    oai_req = await anth_to_openai(body)
    oai_req["messages"] = inject_reasoning(oai_req["messages"],
                                           mapping.get("is_reasoning", 0) or 0)
    oai_req["messages"] = maybe_reinject(oai_req["messages"],
                                         int(mapping.get("context_length") or 0))
    oai_req["tools"] = _add_search_tool(oai_req.get("tools"))
    oai_req["model"] = mapping["real_model"]
    stream = bool(body.get("stream"))
    oai_req["stream"] = stream
    in_tok = estimate_messages_tokens(oai_req["messages"])
    delay = float(mapping.get("delay_sec") or 0.0)
    thinking_requested = bool(body.get("thinking"))

    # ─── NON-STREAM ───────────────────────────────────────────────
    if not stream:
        if delay > 0:
            await asyncio.sleep(delay)
        rounds = 0
        while True:
            try:
                r = await open_upstream_with_retry(
                    upstream, oai_req, key_rec.get("upstream_key") or "", req_id)
            except httpx.TimeoutException:
                return err_ant("api_error", "Upstream timeout.", 504, req_id, fake_model)
            except Exception as e:
                log.warning("[%s] anth upstream error: %r", req_id, e)
                return err_ant("api_error", "Upstream error.", 502, req_id, fake_model)
            try:
                raw = await r.aread()
            finally:
                await r.aclose()
            if r.status_code >= 400:
                return err_ant(map_err_ant(r.status_code),
                               raw.decode("utf-8", "ignore")[:500],
                               r.status_code, req_id, fake_model)
            try:
                data = json.loads(raw)
            except Exception:
                return err_ant("api_error", "Bad upstream JSON.", 502, req_id, fake_model)
            calls = extract_search_calls(data)
            if calls and rounds < SEARCH_MAX_ROUNDS:
                extra = await make_search_round_messages_multi(calls, req_id)
                if extra:
                    oai_req["messages"] = list(oai_req["messages"]) + extra
                    in_tok = estimate_messages_tokens(oai_req["messages"])
                    rounds += 1
                    continue
            if calls:
                oai_req["tools"] = _strip_search_tool(oai_req.get("tools"))
                rounds += 1
                continue
            break

        result = openai_to_anth(data, in_tok, fake_model,
                                thinking_requested=thinking_requested)
        # scrub visible text
        try:
            for blk in result.get("content") or []:
                if isinstance(blk, dict) and blk.get("type") == "text":
                    blk["text"] = sanitize_text(blk.get("text") or "")
        except Exception:
            pass
        result = sanitize_anthropic_body(result, fake_model)
        await bump_usage(key_rec["id"], in_tok, result["usage"]["output_tokens"])
        return JSONResponse(result, headers=gw_headers(req_id, model=fake_model))

    # ─── STREAM ───────────────────────────────────────────────────
    try:
        r = await open_upstream_with_retry(
            upstream, oai_req, key_rec.get("upstream_key") or "", req_id)
    except httpx.TimeoutException:
        return err_ant("api_error", "Upstream timeout.", 504, req_id, fake_model)
    except Exception as e:
        log.warning("[%s] anth upstream stream error: %r", req_id, e)
        return err_ant("api_error", "Upstream error.", 502, req_id, fake_model)

    if r.status_code >= 400:
        try:
            raw = await r.aread()
        finally:
            await r.aclose()
        return err_ant(map_err_ant(r.status_code),
                       raw.decode("utf-8", "ignore")[:500],
                       r.status_code, req_id, fake_model)

    msg_id = new_id("msg")
    hdrs = gw_headers(req_id, is_stream=True, model=fake_model)

    def sse_ev(name: str, obj: dict) -> bytes:
        return f"event: {name}\ndata: {json.dumps(obj, ensure_ascii=False)}\n\n".encode()

    async def gen():
        nonlocal oai_req, in_tok
        stripper = ThinkStripper()
        idx = 0
        cur: Optional[str] = None
        tool_state: dict[int, dict] = {}
        stop_reason = "end_turn"
        saw_tool = False
        up_out = 0
        out_chars = 0
        cur_r = r
        rounds = 0

        if delay > 0:
            await asyncio.sleep(delay)

        def close_cur() -> list[bytes]:
            nonlocal cur, idx
            if cur is None:
                return []
            evs = [sse_ev("content_block_stop",
                          {"type": "content_block_stop", "index": idx})]
            if isinstance(cur, str) and cur.startswith("tool:"):
                try:
                    ti = int(cur.split(":", 1)[1])
                    if ti in tool_state:
                        tool_state[ti]["open"] = False
                except Exception:
                    pass
            idx += 1
            cur = None
            return evs

        def open_text() -> list[bytes]:
            nonlocal cur
            if cur == "text":
                return []
            evs = close_cur()
            evs.append(sse_ev("content_block_start", {
                "type": "content_block_start", "index": idx,
                "content_block": {"type": "text", "text": ""}}))
            cur = "text"
            return evs

        def open_tool(ti: int, tc: dict) -> list[bytes]:
            nonlocal cur, saw_tool
            if cur == f"tool:{ti}":
                return []
            evs = close_cur()
            fn = tc.get("function") or {}
            tool_state[ti] = {"idx": idx, "open": True}
            evs.append(sse_ev("content_block_start", {
                "type": "content_block_start", "index": idx,
                "content_block": {"type": "tool_use",
                                  "id": tc.get("id") or f"toolu_{gen_b62(22)}",
                                  "name": fn.get("name") or "tool",
                                  "input": {}}}))
            cur = f"tool:{ti}"
            saw_tool = True
            return evs

        yield sse_ev("message_start", {
            "type": "message_start",
            "message": {
                "id": msg_id, "type": "message", "role": "assistant",
                "model": fake_model, "content": [],
                "stop_reason": None, "stop_sequence": None,
                "usage": {"input_tokens": in_tok, "output_tokens": 1},
            },
        })

        if thinking_requested and EMIT_REDACTED_THINKING:
            yield sse_ev("content_block_start", {
                "type": "content_block_start", "index": 0,
                "content_block": {"type": "redacted_thinking", "data": ""},
            })
            yield sse_ev("content_block_delta", {
                "type": "content_block_delta", "index": 0,
                "delta": {"type": "signature_delta", "signature": sign_body(b"")},
            })
            yield sse_ev("content_block_stop", {"type": "content_block_stop", "index": 0})
            idx = 1

        try:
            while True:
                sse = SSEBuffer()
                internal = {"idx": None, "id": None, "name": None,
                            "args": "", "client": False, "calls": {}}
                upstream_done = False
                async for kind, item in stream_with_pings(
                    cur_r.aiter_bytes(),
                    sse_ev("ping", {"type": "ping"}),
                ):
                    if kind == "ping":
                        yield item
                        continue
                    for event in sse.feed(item):
                        line = event.strip()
                        if not line.startswith("data:"):
                            continue
                        payload = line[5:].strip()
                        if payload == "[DONE]":
                            upstream_done = True
                            break
                        try:
                            obj = json.loads(payload)
                        except Exception:
                            continue
                        if "error" in obj:
                            yield sse_ev("error", {"type": "error", "error": {
                                "type": map_err_ant(400),
                                "message": sanitize_text(str(obj["error"]))}})
                            return
                        try:
                            u = obj.get("usage") or {}
                            v = int(u.get("completion_tokens") or 0)
                            if v > 0:
                                up_out = v
                        except Exception:
                            pass
                        choices = obj.get("choices") or []
                        if not choices:
                            continue
                        ch = choices[0]
                        fr = ch.get("finish_reason")
                        if fr == "length":
                            stop_reason = "max_tokens"
                        elif fr == "content_filter":
                            stop_reason = "refusal"
                        delta = ch.get("delta") or {}

                        # наш поисковый вызов клиенту не показываем
                        take_internal_tool_deltas(obj, internal)

                        for tc in (delta.get("tool_calls") or []):
                            if not isinstance(tc, dict):
                                continue
                            try:
                                ti = int(tc.get("index", 0))
                            except Exception:
                                ti = 0
                            st = tool_state.get(ti)
                            if st is None or not st.get("open"):
                                for ev in open_tool(ti, tc):
                                    yield ev
                                st = tool_state.get(ti)
                            if st is None:
                                continue
                            if cur != f"tool:{ti}":
                                log.warning("[%s] tool_call %s пришёл после закрытия блока",
                                            req_id, ti)
                                continue
                            args = (tc.get("function") or {}).get("arguments")
                            if isinstance(args, str) and args:
                                yield sse_ev("content_block_delta", {
                                    "type": "content_block_delta", "index": st["idx"],
                                    "delta": {"type": "input_json_delta",
                                              "partial_json": args}})

                        content = delta.get("content")
                        if isinstance(content, str) and content:
                            visible = stripper.feed(content)
                            if visible:
                                visible = sanitize_text(visible)
                                for ev in open_text():
                                    yield ev
                                out_chars += len(visible)
                                yield sse_ev("content_block_delta", {
                                    "type": "content_block_delta", "index": idx,
                                    "delta": {"type": "text_delta", "text": visible}})
                    if upstream_done:
                        break

                # ── нужен ли ещё раунд с поиском ──
                ours = search_calls_from_state(internal)
                if ours and not internal["client"] and SEARCH_ENABLED:
                    if rounds >= SEARCH_MAX_ROUNDS:
                        # раунды исчерпаны — финальный ответ без нашего инструмента
                        oai_req["tools"] = _strip_search_tool(oai_req.get("tools"))
                    else:
                        yield sse_ev("ping", {"type": "ping"})
                        extra = await make_search_round_messages_multi(ours, req_id)
                        if extra:
                            oai_req["messages"] = list(oai_req["messages"]) + extra
                            in_tok = estimate_messages_tokens(oai_req["messages"])
                        else:
                            oai_req["tools"] = _strip_search_tool(oai_req.get("tools"))
                    rounds += 1
                    try:
                        await cur_r.aclose()
                    except Exception:
                        pass
                    try:
                        cur_r = await open_upstream_with_retry(
                            upstream, oai_req, key_rec.get("upstream_key") or "", req_id)
                    except Exception as e:
                        log.warning("[%s] search round upstream error: %r", req_id, e)
                        yield sse_ev("error", {"type": "error", "error": {
                            "type": "api_error",
                            "message": "Upstream error after search"}})
                        return
                    if cur_r.status_code >= 400:
                        raw2 = await cur_r.aread()
                        try:
                            await cur_r.aclose()
                        except Exception:
                            pass
                        log.warning("[%s] search round HTTP %s", req_id, cur_r.status_code)
                        yield sse_ev("error", {"type": "error", "error": {
                            "type": map_err_ant(cur_r.status_code),
                            "message": raw2.decode("utf-8", "ignore")[:300]}})
                        return
                    continue

                # ── финал ──
                tail = stripper.flush()
                if tail:
                    tail = sanitize_text(tail)
                    for ev in open_text():
                        yield ev
                    out_chars += len(tail)
                    yield sse_ev("content_block_delta", {
                        "type": "content_block_delta", "index": idx,
                        "delta": {"type": "text_delta", "text": tail}})

                if cur is None:
                    for ev in open_text():
                        yield ev
                for ev in close_cur():
                    yield ev

                if saw_tool:
                    stop_reason = "tool_use"
                out_tok = up_out or max(1, out_chars // 4)
                yield sse_ev("message_delta", {
                    "type": "message_delta",
                    "delta": {"stop_reason": stop_reason, "stop_sequence": None},
                    "usage": {"input_tokens": in_tok, "output_tokens": out_tok},
                })
                yield sse_ev("message_stop", {"type": "message_stop"})
                break
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("[%s] anth stream aborted: %r", req_id, e)
            try:
                yield sse_ev("error", {"type": "error", "error": {
                    "type": "api_error", "message": "Stream aborted"}})
            except Exception:
                pass
        finally:
            try:
                await cur_r.aclose()
            except Exception:
                pass
            await bump_usage(key_rec["id"], in_tok, up_out or max(1, out_chars // 4))

    return StreamingResponse(gen(), media_type="text/event-stream", headers=hdrs)

# ══════════════════════════════════════════════════════════════════════
#  MISC ENDPOINTS
# ══════════════════════════════════════════════════════════════════════

@app.get("/v1/models")
async def list_models(req: Request):
    req_id = new_id("req")
    if not resolve_client(req):
        return err_oai("authentication_error", "Invalid API key.", 401, req_id)
    data = [{
        "id": fm, "object": "model",
        "created": 1735689600,
        "owned_by": m.get("owned_by", "noetic-labs"),
        "context_window": m.get("context_length", 128000),
    } for fm, m in MAPPINGS.items()]
    return JSONResponse({"object": "list", "data": data}, headers=gw_headers(req_id))


_HEALTH_PROBE_TTL = float(os.getenv("HEALTH_PROBE_TTL", "300"))
_health_probe_cache: dict[str, Any] = {"at": 0.0, "data": {}}


async def probe_model_channels(force: bool = False) -> dict[str, dict]:
    """Реально дёргает каждую модель из mappings — минимальным запросом.

    /v1/models отвечает 200 даже когда все каналы моделей лежат, поэтому проверять
    здоровье по нему недостаточно. Результат кэшируется на HEALTH_PROBE_TTL секунд,
    чтобы мониторинг не жёг токены на каждом опросе.
    """
    now = time.time()
    cached = _health_probe_cache.get("data") or {}
    if not force and cached and now - float(_health_probe_cache.get("at") or 0) < _HEALTH_PROBE_TTL:
        return cached

    out: dict[str, dict] = {}
    for fake, m in sorted(MAPPINGS.items(), key=lambda kv: str(kv[0])):
        up = UPSTREAMS.get(m.get("upstream_id"))
        if not up or not up.get("enabled"):
            out[fake] = {"state": "no-upstream"}
            continue
        bearer = up.get("api_key") or next(
            (k.get("upstream_key") for k in API_KEYS.values() if k.get("upstream_key")), "")
        if not bearer:
            out[fake] = {"state": "no-key"}
            continue
        t0 = time.time()
        try:
            r = await http_client.post(
                up["url"].rstrip("/") + "/v1/chat/completions",
                headers={"Authorization": f"Bearer {bearer}"},
                json={"model": m.get("real_model"), "max_tokens": 1, "stream": False,
                      "messages": [{"role": "user", "content": "."}]},
                timeout=httpx.Timeout(connect=5.0, read=25.0, write=10.0, pool=5.0),
            )
            ms = int((time.time() - t0) * 1000)
            if r.status_code < 400:
                out[fake] = {"state": "ok", "ms": ms}
            else:
                out[fake] = {"state": "down", "http": r.status_code, "ms": ms,
                             "detail": r.text[:200].replace("\n", " ")}
        except Exception as e:                      # noqa: BLE001 — отдаём как unknown
            out[fake] = {"state": "unknown", "detail": repr(e)[:140]}
    _health_probe_cache["at"] = now
    _health_probe_cache["data"] = out
    return out


@app.get("/health/deep")
async def health_deep(force: int = 0):
    """Проверка здоровья по каналам: 503, если хоть одна модель недоступна."""
    channels = await probe_model_channels(force=bool(force))
    bad = sorted(k for k, v in channels.items()
                 if v.get("state") in ("down", "no-upstream", "no-key"))
    return JSONResponse(
        {"status": "ok" if not bad else "degraded",
         "reachable": not bad,
         "down": bad,
         "channels": channels,
         "probe_ttl_sec": _HEALTH_PROBE_TTL,
         "models": len(MAPPINGS),
         "fingerprint": SYSTEM_FINGERPRINT},
        status_code=200 if not bad else 503,
    )


@app.get("/health")
async def health():
    upstream_ok = False
    try:
        if UPSTREAMS and http_client:
            u = next(iter(UPSTREAMS.values()))
            bearer = u.get("api_key") or next(
                (k.get("upstream_key") for k in API_KEYS.values() if k.get("upstream_key")), "")
            if bearer:
                r = await http_client.get(
                    u["url"].rstrip("/") + "/v1/models",
                    headers={"Authorization": f"Bearer {bearer}"},
                    timeout=httpx.Timeout(connect=5.0, read=5.0, write=5.0, pool=5.0),
                )
                upstream_ok = r.status_code < 500
    except Exception:
        pass
    return {
        "status": "ok",
        "upstream": "ok" if upstream_ok else "degraded",
        "upstreams": len(UPSTREAMS),
        "models": len(MAPPINGS),
        "keys": len(API_KEYS),
        "fingerprint": SYSTEM_FINGERPRINT,
    }

# ══════════════════════════════════════════════════════════════════════
#  ADMIN
# ══════════════════════════════════════════════════════════════════════

adm_q = APIKeyQuery(name="key", auto_error=False)


def verify_admin(key: str = Depends(adm_q)):
    if not ADMIN_KEY or key != ADMIN_KEY:
        raise HTTPException(401, "Invalid admin key")
    return key


def _esc(s: Any) -> str:
    s = str(s or "")
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;").replace("'", "&#39;"))


def _redir(key: str) -> HTMLResponse:
    return HTMLResponse(f"<script>location.href='/admin?key={key}';</script>")


DASH_CSS = """
:root{
  --bg:#08080a;--bg2:#0c0c0f;--s1:#111114;--s2:#16161a;--s3:#1c1c21;
  --bd:#222228;--bd-hi:#2c2c34;--tx:#ededf0;--tx2:#a1a1aa;--tx3:#63636b;
  --ac:#6366f1;--ac-hi:#818cf8;--ac-glow:rgba(99,102,241,.22);
  --ok:#10b981;--warn:#f59e0b;--bad:#ef4444;--pink:#ec4899;--cyan:#06b6d4;
  --r:12px;--r2:8px;--r3:6px;--t:cubic-bezier(.4,0,.2,1);
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{
  background:radial-gradient(1200px 600px at 50% -10%,rgba(99,102,241,.06),transparent 60%),var(--bg);
  color:var(--tx);font:14px/1.55 ui-sans-serif,-apple-system,"Segoe UI",Roboto,sans-serif;
  -webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
  font-feature-settings:"cv02","cv03","cv04","cv11","ss01";min-height:100vh;
}
::selection{background:var(--ac);color:#fff}
::-webkit-scrollbar{width:10px;height:10px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--bd-hi);border-radius:10px}
::-webkit-scrollbar-thumb:hover{background:#3a3a44}
.wrap{max-width:1240px;margin:0 auto;padding:32px 24px 80px}
.hdr{display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding-bottom:24px;border-bottom:1px solid var(--bd);margin-bottom:32px}
.brand{display:flex;align-items:center;gap:12px}
.mark{width:32px;height:32px;border-radius:8px;
  background:linear-gradient(135deg,var(--ac) 0%,#a855f7 100%);
  box-shadow:0 0 24px var(--ac-glow);position:relative;flex-shrink:0}
.mark::after{content:"";position:absolute;inset:9px;border-radius:2px;
  background:rgba(0,0,0,.35);box-shadow:inset 0 0 8px rgba(0,0,0,.4)}
.brand h1{font-size:15px;font-weight:600;letter-spacing:-.01em}
.brand small{display:block;font-size:11px;color:var(--tx3);letter-spacing:.14em;
  text-transform:uppercase;margin-top:2px;font-weight:500}
.status{display:inline-flex;align-items:center;gap:8px;padding:7px 12px;
  border:1px solid var(--bd);border-radius:100px;font-size:12px;color:var(--tx2);
  background:rgba(255,255,255,.015)}
.dot{width:6px;height:6px;border-radius:50%;background:var(--ok);
  box-shadow:0 0 8px var(--ok);animation:pulse 2s var(--t) infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:32px}
.stat{padding:18px 20px;background:linear-gradient(180deg,var(--s1),var(--s2));
  border:1px solid var(--bd);border-radius:var(--r);position:relative;overflow:hidden}
.stat::before{content:"";position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,var(--ac-glow),transparent)}
.stat .v{font-size:24px;font-weight:600;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.stat .l{font-size:11px;color:var(--tx3);letter-spacing:.14em;text-transform:uppercase;
  margin-top:4px;font-weight:500}
.tabs{display:flex;gap:4px;margin-bottom:24px;padding:4px;background:var(--s1);
  border:1px solid var(--bd);border-radius:var(--r);width:fit-content}
.tab{padding:8px 16px;border-radius:var(--r2);font-size:13px;font-weight:500;
  color:var(--tx2);cursor:pointer;border:0;background:transparent;
  transition:all .18s var(--t);white-space:nowrap;font-family:inherit}
.tab:hover{color:var(--tx)}
.tab.on{background:var(--s3);color:var(--tx);box-shadow:0 1px 0 rgba(255,255,255,.03) inset,0 4px 12px rgba(0,0,0,.3)}
.panel{display:none;animation:fadeIn .22s var(--t)}
.panel.on{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.card{background:var(--s1);border:1px solid var(--bd);border-radius:var(--r);
  padding:22px;margin-bottom:16px}
.card-hd{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
.card-hd h2{font-size:13px;font-weight:600;color:var(--tx);letter-spacing:.02em}
.card-hd .sub{font-size:11px;color:var(--tx3);letter-spacing:.14em;text-transform:uppercase;
  font-weight:500;margin-top:2px}
.card-hd .sub::before{content:"// "}
.form{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
  gap:10px;margin-bottom:20px;padding:16px;background:var(--bg2);
  border:1px dashed var(--bd-hi);border-radius:var(--r2)}
.form .wide{grid-column:span 2}
@media(max-width:640px){.form .wide{grid-column:span 1}}
input,select,textarea{
  width:100%;background:var(--bg2);color:var(--tx);border:1px solid var(--bd);
  padding:9px 12px;border-radius:var(--r2);font-size:13px;font-family:inherit;
  outline:none;transition:border-color .15s var(--t),box-shadow .15s var(--t);
  -webkit-appearance:none;appearance:none;
}
select{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23a1a1aa' stroke-width='2' stroke-linecap='round'><polyline points='6 9 12 15 18 9'/></svg>");
  background-repeat:no-repeat;background-position:right 12px center;padding-right:32px}
input::placeholder{color:var(--tx3)}
input:focus,select:focus,textarea:focus{
  border-color:var(--ac);box-shadow:0 0 0 3px var(--ac-glow)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;
  border-radius:var(--r2);font-size:13px;font-weight:500;font-family:inherit;
  cursor:pointer;border:1px solid transparent;transition:all .15s var(--t);white-space:nowrap}
.btn.primary{background:var(--ac);color:#fff}
.btn.primary:hover{background:var(--ac-hi);box-shadow:0 0 0 3px var(--ac-glow)}
.btn.ghost{background:transparent;color:var(--tx2);border-color:var(--bd)}
.btn.ghost:hover{background:var(--s3);color:var(--tx);border-color:var(--bd-hi)}
.btn.danger{background:transparent;color:var(--bad);border-color:rgba(239,68,68,.25)}
.btn.danger:hover{background:rgba(239,68,68,.1);border-color:var(--bad)}
.btn.icon{padding:7px;width:30px;height:30px;justify-content:center}
.btn svg{width:13px;height:13px;flex-shrink:0}
.btn:active{transform:scale(.97)}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:10px 12px;font-size:10.5px;font-weight:600;
  letter-spacing:.14em;text-transform:uppercase;color:var(--tx3);
  border-bottom:1px solid var(--bd);background:transparent}
.tbl td{padding:12px;border-bottom:1px solid var(--bd);color:var(--tx);vertical-align:middle}
.tbl tr:last-child td{border-bottom:0}
.tbl tbody tr{transition:background .12s var(--t)}
.tbl tbody tr:hover{background:rgba(255,255,255,.012)}
code.k{font:12px/1.4 ui-monospace,"SF Mono",Menlo,monospace;
  background:var(--bg2);padding:3px 8px;border-radius:var(--r3);
  border:1px solid var(--bd);color:var(--tx2)}
code.k.em{color:var(--ac-hi);border-color:rgba(99,102,241,.3)}
.pill{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;
  border-radius:100px;font-size:11px;font-weight:500;letter-spacing:.02em;
  border:1px solid transparent;font-variant-numeric:tabular-nums}
.pill::before{content:"";width:5px;height:5px;border-radius:50%;background:currentColor}
.pill.on{color:var(--ok);background:rgba(16,185,129,.08);border-color:rgba(16,185,129,.2)}
.pill.off{color:var(--tx3);background:rgba(255,255,255,.02);border-color:var(--bd)}
.pill.tag{color:var(--tx2);background:var(--s3);border-color:var(--bd-hi)}
.pill.tag::before{display:none}
.pill.ac{color:var(--ac-hi);background:rgba(99,102,241,.1);border-color:rgba(99,102,241,.25)}
.pill.ac::before{display:none}
.pill.pink{color:var(--pink);background:rgba(236,72,153,.08);border-color:rgba(236,72,153,.2)}
.pill.pink::before{display:none}
.pill.cyan{color:var(--cyan);background:rgba(6,182,212,.08);border-color:rgba(6,182,212,.2)}
.pill.cyan::before{display:none}
.acts{display:flex;gap:6px;justify-content:flex-end}
.empty{padding:48px 20px;text-align:center;color:var(--tx3);font-size:13px}
.empty svg{width:28px;height:28px;opacity:.3;margin-bottom:12px;display:block;margin-inline:auto}
.overlay{position:fixed;inset:0;background:rgba(5,5,8,.72);
  backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  z-index:1000;display:none;align-items:center;justify-content:center;padding:20px;
  animation:fadeIn .15s var(--t)}
.overlay.on{display:flex}
.modal{background:var(--s1);border:1px solid var(--bd-hi);border-radius:16px;
  width:100%;max-width:560px;max-height:90vh;overflow-y:auto;
  box-shadow:0 32px 80px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.02) inset;
  animation:modalIn .22s var(--t)}
@keyframes modalIn{from{opacity:0;transform:scale(.97) translateY(8px)}to{opacity:1;transform:none}}
.modal-hd{display:flex;align-items:center;justify-content:space-between;
  padding:20px 22px;border-bottom:1px solid var(--bd)}
.modal-hd h3{font-size:14px;font-weight:600}
.modal-hd .x{background:transparent;border:0;color:var(--tx3);cursor:pointer;
  padding:4px;width:28px;height:28px;display:flex;align-items:center;justify-content:center;
  border-radius:var(--r3);transition:all .15s var(--t);font-family:inherit}
.modal-hd .x:hover{background:var(--s3);color:var(--tx)}
.modal-hd .x svg{width:14px;height:14px}
.modal-bd{padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px}
.modal-bd .full{grid-column:1 / -1}
.fg{display:flex;flex-direction:column;gap:6px}
.fg label{font-size:11px;color:var(--tx3);letter-spacing:.1em;text-transform:uppercase;font-weight:500}
.modal-ft{padding:16px 22px;border-top:1px solid var(--bd);
  display:flex;justify-content:flex-end;gap:10px}
.tbl-wrap{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;border-radius:var(--r2)}
.tbl-wrap::-webkit-scrollbar{height:8px}
@media(hover:none){
  .btn{min-height:40px}
  .btn.icon{width:40px;height:40px}
}
@media(max-width:900px){
  .wrap{padding:22px 14px 64px}
  .hdr{flex-wrap:wrap;gap:12px;padding-bottom:18px;margin-bottom:22px}
  .stats{grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:22px}
  .modal-bd{grid-template-columns:1fr}
  .card{padding:16px}
  .tabs{width:100%;overflow-x:auto;justify-content:flex-start}
  .tab{flex:0 0 auto}
}
@media(max-width:700px){
  .wrap{padding:16px 12px 56px}
  .stat{padding:14px 16px}
  .stat .v{font-size:20px}
  .brand h1{font-size:14px}
  .tab{font-size:12.5px;padding:10px 14px}
  .tbl{font-size:12.5px}
  .tbl-wrap .tbl{min-width:560px}
  .tbl th,.tbl td{white-space:nowrap}
  .tbl th{padding:8px 10px;font-size:10px}
  .tbl td{padding:10px}
  .form{grid-template-columns:1fr;padding:12px}
  .form .wide{grid-column:span 1}
  .form .btn{width:100%;justify-content:center}
  .modal{max-width:100%;border-radius:14px}
  .modal-bd{padding:16px}
  .modal-ft{padding:14px 16px}
  .modal-ft .btn{flex:1;justify-content:center}
}
"""

DASH_JS = """
function q(s,r){return (r||document).querySelector(s)}
function qa(s,r){return Array.from((r||document).querySelectorAll(s))}
function openTab(n){
  qa('.tab').forEach(t=>t.classList.toggle('on',t.dataset.t===n));
  qa('.panel').forEach(p=>p.classList.toggle('on',p.dataset.p===n));
  try{localStorage.setItem('ns_tab',n)}catch(e){}
}
function savedTab(){
  try{
    const v=localStorage.getItem('ns_tab');
    return (v&&q('.tab[data-t="'+v+'"]'))?v:null;
  }catch(e){return null}
}
function openM(id){q('#'+id).classList.add('on');document.body.style.overflow='hidden'}
function closeM(id){q('#'+id).classList.remove('on');document.body.style.overflow=''}
function copy(text,btn){
  const done=()=>{const o=btn.innerHTML;btn.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';setTimeout(()=>btn.innerHTML=o,1200)};
  if(navigator.clipboard){navigator.clipboard.writeText(text).then(done).catch(()=>fallback())}else{fallback()}
  function fallback(){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');done()}catch(e){}document.body.removeChild(ta)}
}
function fillModal(btn){
  const d=btn.dataset||{};
  q('#m_id').value=d.id||'';
  q('#m_fake').value=d.fake||'';
  q('#m_real').value=d.real||'';
  q('#m_up').value=d.up||'';
  q('#m_owner').value=d.owner||'noetic-labs';
  q('#m_ctx').value=d.ctx||'128000';
  q('#m_delay').value=d.delay||'0';
  q('#m_reason').value=d.reason||'0';
  q('#m_endpoint').value=d.endpoint||'3';
  q('#m_title').textContent=d.id?'Edit Model':'New Model';
  openM('modal_model');
}
function newModel(){
  q('#m_id').value='';q('#m_fake').value='';q('#m_real').value='';
  q('#m_owner').value='noetic-labs';q('#m_ctx').value='128000';
  q('#m_delay').value='0';q('#m_reason').value='0';q('#m_endpoint').value='3';
  q('#m_title').textContent='New Model';
  openM('modal_model');
}
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')qa('.overlay.on').forEach(o=>o.classList.remove('on'));
});
document.addEventListener('DOMContentLoaded',()=>{
  qa('.overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('on')}));
  qa('.tab').forEach(t=>t.addEventListener('click',()=>openTab(t.dataset.t)));
  let start=savedTab();
  if(!start){const first=q('.tab');start=first?first.dataset.t:'models'}
  openTab(start);
});
"""


# ══════════════════════════════════════════════════════════════════════
#  ADMIN CHAT — the console playground
#  Same pipeline as /v1/chat/completions: mapping → upstream → thinking strip,
#  web-search rounds, PDF text + page images, system-prompt restatement.
# ══════════════════════════════════════════════════════════════════════

ADMIN_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
if not os.path.isdir(ADMIN_FONT_DIR):
    ADMIN_FONT_DIR = "/opt/noesphere/fonts"

CHAT_MAX_FILES = int(os.getenv("ADMIN_CHAT_MAX_FILES", "24"))
CHAT_MAX_FILE_BYTES = int(os.getenv("ADMIN_CHAT_MAX_FILE_BYTES", str(24 * 1024 * 1024)))

_CHAT_IMAGE_MIME = {
    "image/png", "image/jpeg", "image/jpg", "image/webp",
    "image/gif", "image/avif", "image/bmp",
}
_CHAT_TEXT_EXT = {
    ".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".jsonl", ".log",
    ".yaml", ".yml", ".xml", ".html", ".htm", ".css", ".js", ".ts", ".tsx",
    ".jsx", ".py", ".sh", ".sql", ".toml", ".ini", ".env", ".conf", ".cfg",
    ".rb", ".go", ".rs", ".java", ".c", ".h", ".cpp", ".php", ".swift", ".kt",
}


@app.get("/fonts/{fname}")
async def admin_font(fname: str):
    """Self-hosted brand fonts for the console (Instrument Serif / Inter / Plex Mono)."""
    safe = os.path.basename(fname)
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,64}\.woff2", safe):
        raise HTTPException(status_code=404, detail="not found")
    path = os.path.join(ADMIN_FONT_DIR, safe)
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="not found")
    return FileResponse(path, media_type="font/woff2",
                        headers={"Cache-Control": "public, max-age=31536000, immutable"})


async def _admin_file_parts(f: Any) -> tuple[list[dict], dict]:
    """An uploaded console file → upstream content parts + a descriptor for the UI."""
    name = (getattr(f, "filename", "") or "file").strip() or "file"
    mt = (getattr(f, "content_type", "") or "").split(";")[0].strip().lower()
    try:
        raw = await f.read()
    except Exception:
        raw = b""
    low = name.lower()
    ext = os.path.splitext(low)[1]
    desc = {"name": name, "bytes": len(raw),
            "mime": mt or "application/octet-stream", "kind": "file"}
    if not raw:
        desc["error"] = "empty"
        return [], desc
    if len(raw) > CHAT_MAX_FILE_BYTES:
        desc["error"] = "too large"
        return ([{"type": "text",
                  "text": f"[File: {name} — too large for the console ({len(raw)} bytes).]"}], desc)

    is_pdf = (mt == "application/pdf" or ext == ".pdf" or raw[:5] == b"%PDF-")
    if is_pdf:
        parts, note = await pdf_to_parts(raw, name)
        desc["kind"] = "pdf"
        if note:
            parts = list(parts) + [{"type": "text", "text": note}]
        if not parts:
            desc["error"] = "no text"
        return parts, desc

    if mt in _CHAT_IMAGE_MIME or mt.startswith("image/"):
        b64 = base64.b64encode(raw).decode("ascii")
        desc["kind"] = "image"
        return ([{"type": "image_url",
                  "image_url": {"url": f"data:{mt or 'image/png'};base64,{b64}"}}], desc)

    if mt.startswith("text/") or ext in _CHAT_TEXT_EXT:
        try:
            txt = raw.decode("utf-8", "replace")
        except Exception:
            txt = ""
        if txt.strip():
            desc["kind"] = "text"
            return ([{"type": "text", "text": f"[File: {name}]\n{txt}\n[End of file]"}], desc)

    desc["kind"] = "binary"
    desc["error"] = "not decoded"
    return ([{"type": "text",
              "text": f"[File: {name} — {mt or 'binary'} · {len(raw)} bytes; content not decoded.]"}],
            desc)


def _admin_credential(cred_raw: str, upstream: dict) -> tuple[str, str]:
    """Resolve which upstream bearer token the console should send."""
    rec = KEYS_BY_ID.get(int(cred_raw)) if cred_raw.isdigit() else None
    if rec and rec.get("upstream_key"):
        label = f"key #{rec['id']} · {rec.get('note') or 'unnamed'}"
        return rec["upstream_key"], label
    if upstream.get("api_key"):
        return upstream["api_key"], "upstream default"
    for r in sorted(KEYS_BY_ID.values(), key=lambda x: x.get("id") or 0):
        if r.get("enabled") and r.get("upstream_key"):
            label = f"key #{r['id']} · {r.get('note') or 'unnamed'}"
            return r["upstream_key"], label
    return "", ""


@app.post("/admin/chat")
async def admin_chat(request: Request, key: str = Depends(verify_admin)):
    req_id = new_id("ui")

    def ev(obj: dict) -> bytes:
        return f"data: {json.dumps(obj, ensure_ascii=False)}\n\n".encode("utf-8")

    def only(*events: dict) -> StreamingResponse:
        return StreamingResponse(
            (ev(e) for e in events), media_type="text/event-stream",
            headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"})

    try:
        form = await request.form()
    except Exception:
        return only({"t": "error", "message": "Malformed form body."}, {"t": "done"})

    fake_model = str(form.get("model") or "").strip()
    system_text = str(form.get("system") or "").strip()
    search_on = str(form.get("search") or "1") == "1"
    cred_raw = str(form.get("cred") or "").strip()
    try:
        temperature = max(0.0, min(2.0, float(form.get("temp") or 0.7)))
    except Exception:
        temperature = 0.7
    try:
        history = json.loads(str(form.get("messages") or "[]"))
    except Exception:
        history = []
    if not isinstance(history, list):
        history = []

    mapping = MAPPINGS.get(fake_model)
    if not mapping:
        return only({"t": "error", "message": f"Unknown model: {fake_model or '(none)'} "
                                              f"— create the mapping first."}, {"t": "done"})
    upstream = UPSTREAMS.get(mapping["upstream_id"])
    if not upstream or not upstream.get("enabled"):
        return only({"t": "error", "message": "Upstream unavailable or disabled."}, {"t": "done"})

    auth_key, cred_label = _admin_credential(cred_raw, upstream)
    if not auth_key:
        return only({"t": "error", "message": "No upstream credential. Generate a client key "
                                              "with an original upstream key, or set the "
                                              "upstream's own key."}, {"t": "done"})

    # ── uploaded files land on the last user turn ────────────────────
    uploads = []
    try:
        uploads = list(form.getlist("files"))[:CHAT_MAX_FILES]
    except Exception:
        uploads = []
    file_parts: list[dict] = []
    file_descs: list[dict] = []
    for f in uploads:
        if not hasattr(f, "read"):
            continue
        parts, desc = await _admin_file_parts(f)
        file_parts += parts
        file_descs.append(desc)

    msgs: list[dict] = []
    if system_text:
        msgs.append({"role": "system", "content": system_text})
    for m in history:
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        if role not in ("user", "assistant"):
            continue
        content = m.get("content")
        if not isinstance(content, str) or not content.strip():
            continue
        msgs.append({"role": role, "content": content})
    if not msgs or msgs[-1]["role"] != "user":
        msgs.append({"role": "user", "content": "(no message)"})

    if file_parts:
        last = msgs[-1]
        text = last.get("content") or ""
        last["content"] = ([{"type": "text", "text": text}] if text else []) + file_parts

    payload: dict[str, Any] = {
        "model": mapping["real_model"],
        "messages": msgs,
        "temperature": temperature,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    if search_on:
        payload["tools"] = _add_search_tool(None)

    msgs = inject_reasoning(payload["messages"], mapping.get("is_reasoning", 0) or 0)
    msgs = maybe_reinject(msgs, int(mapping.get("context_length") or 0))
    payload["messages"] = msgs

    upstream_name = str(upstream.get("name") or "")
    log.info("[%s] console chat model=%s upstream=%s cred=%s files=%s",
             req_id, fake_model, upstream_name, cred_label, len(file_descs))

    async def gen() -> AsyncIterator[bytes]:
        yield ev({"t": "meta", "model": fake_model, "real": mapping["real_model"],
                  "upstream": upstream_name, "cred": cred_label, "files": file_descs})

        body = payload
        in_tok = estimate_messages_tokens(body["messages"])
        stripper = ThinkStripper()
        out_chars = 0
        rounds = 0
        cur_r: Optional[httpx.Response] = None

        try:
            delay = float(mapping.get("delay_sec") or 0.0)
            if delay > 0:
                await asyncio.sleep(delay)

            for attempt in range(UPSTREAM_RETRY_TOTAL):
                cur_r = await open_upstream_stream(upstream, body, auth_key)
                if (cur_r.status_code not in UPSTREAM_RETRY_STATUSES
                        or attempt >= UPSTREAM_RETRY_TOTAL - 1):
                    break
                raw_retry = await _drain_close(cur_r)
                log.warning("[%s] console upstream %s (attempt %d/%d): %s", req_id,
                            cur_r.status_code, attempt + 1, UPSTREAM_RETRY_TOTAL,
                            raw_retry.decode("utf-8", "ignore")[:200])
                yield ev({"t": "status", "message":
                          f"Upstream {cur_r.status_code} — retry "
                          f"{attempt + 1} of {UPSTREAM_RETRY_TOTAL - 1}"})
                await asyncio.sleep(upstream_retry_delay(attempt))
            if cur_r.status_code >= 400:
                raw_err = await cur_r.aread()
                hint = ""
                if cur_r.status_code in UPSTREAM_RETRY_STATUSES:
                    hint = ("\n\nThe upstream kept failing after "
                            f"{UPSTREAM_RETRY_TOTAL} attempts. That is a server-side error "
                            "at the provider, not a problem with this request — the channel "
                            "behind this model is probably down. Check the upstream dashboard "
                            "or try another model.")
                yield ev({"t": "error",
                          "message": f"Upstream HTTP {cur_r.status_code}: "
                                     + raw_err.decode("utf-8", "ignore")[:700] + hint})
                yield ev({"t": "done"})
                return

            while True:
                sse = SSEBuffer()
                internal = {"idx": None, "id": None, "name": None, "args": "",
                            "client": False, "calls": {}}
                upstream_done = False
                last_finish = ""

                async for kind, item in stream_with_pings(cur_r.aiter_bytes(), b": ping\n\n"):
                    if kind == "ping":
                        yield item
                        continue
                    for event in sse.feed(item):
                        line = event.strip()
                        if not line.startswith("data:"):
                            continue
                        chunk = line[5:].strip()
                        if chunk == "[DONE]":
                            upstream_done = True
                            break
                        try:
                            obj = json.loads(chunk)
                        except Exception:
                            continue
                        if isinstance(obj, dict) and obj.get("error"):
                            e = obj["error"]
                            if isinstance(e, dict):
                                e = e.get("message") or json.dumps(e, ensure_ascii=False)
                            yield ev({"t": "error", "message": sanitize_text(str(e))[:700]})
                            continue

                        take_internal_tool_deltas(obj, internal)

                        for ch in obj.get("choices") or []:
                            if not isinstance(ch, dict):
                                continue
                            d = ch.get("delta") or {}
                            rc = d.get("reasoning_content")
                            if isinstance(rc, str) and rc:
                                yield ev({"t": "reason", "text": sanitize_text(rc)})
                            c = d.get("content")
                            if isinstance(c, str) and c:
                                clean = stripper.feed(c)
                                if clean:
                                    clean = sanitize_text(clean)
                                    out_chars += len(clean)
                                    yield ev({"t": "text", "text": clean})
                            if ch.get("finish_reason"):
                                last_finish = str(ch["finish_reason"])
                                yield ev({"t": "finish", "reason": last_finish})
                    if upstream_done:
                        break

                # ── another round if the model asked for our search tool ──
                ours = search_calls_from_state(internal)
                if ours and not internal["client"] and search_on:
                    if rounds >= SEARCH_MAX_ROUNDS:
                        body["tools"] = _strip_search_tool(body.get("tools"))
                    else:
                        plan = [{"query": parse_search_query(c["args"]),
                                 "read": parse_search_read(c["args"])} for c in ours]
                        plan = [q for q in plan if q["query"]]
                        for q in plan:
                            yield ev({"t": "search", "query": q["query"], "read": q["read"]})
                        timings: list[dict] = []
                        extra = await make_search_round_messages_multi(ours, req_id, timings)
                        if extra:
                            body["messages"] = list(body["messages"]) + extra
                            in_tok = estimate_messages_tokens(body["messages"])
                        else:
                            body["tools"] = _strip_search_tool(body.get("tools"))
                        for q in timings:
                            yield ev({"t": "search_done", "query": q["query"],
                                      "read": q["read"], "ms": q["ms"]})
                        for q in plan[len(timings):]:
                            yield ev({"t": "search_done", "query": q["query"],
                                      "read": q["read"], "ms": 0})
                    rounds += 1
                    try:
                        await cur_r.aclose()
                    except Exception:
                        pass
                    for attempt in range(UPSTREAM_RETRY_TOTAL):
                        cur_r = await open_upstream_stream(upstream, body, auth_key)
                        if (cur_r.status_code not in UPSTREAM_RETRY_STATUSES
                                or attempt >= UPSTREAM_RETRY_TOTAL - 1):
                            break
                        raw_retry = await _drain_close(cur_r)
                        log.warning("[%s] console search-round upstream %s (attempt %d/%d)",
                                    req_id, cur_r.status_code, attempt + 1,
                                    UPSTREAM_RETRY_TOTAL)
                        yield ev({"t": "status", "message":
                                  f"Upstream {cur_r.status_code} — retry "
                                  f"{attempt + 1} of {UPSTREAM_RETRY_TOTAL - 1}"})
                        await asyncio.sleep(upstream_retry_delay(attempt))
                    if cur_r.status_code >= 400:
                        raw2 = await cur_r.aread()
                        yield ev({"t": "error",
                                  "message": f"Search round HTTP {cur_r.status_code}: "
                                             + raw2.decode("utf-8", "ignore")[:500]})
                        break
                    continue

                tail = stripper.flush()
                if tail:
                    tail = sanitize_text(tail)
                    out_chars += len(tail)
                    yield ev({"t": "text", "text": tail})
                if out_chars == 0:
                    yield ev({"t": "error", "message":
                              "Upstream returned an empty answer"
                              + (f" (finish_reason: {last_finish})" if last_finish else "")
                              + ". This usually means the model asked for a tool the "
                                "gateway does not run — try rephrasing or another model."})
                yield ev({"t": "usage", "in": in_tok, "out": max(0, out_chars // 4)})
                yield ev({"t": "done"})
                break

        except asyncio.CancelledError:
            raise
        except httpx.TimeoutException:
            yield ev({"t": "error", "message": "Upstream timeout."})
            yield ev({"t": "done"})
        except Exception as e:
            log.warning("[%s] console chat failed: %r", req_id, e)
            yield ev({"t": "error", "message": f"{type(e).__name__}: {e}"})
            yield ev({"t": "done"})
        finally:
            try:
                if cur_r is not None:
                    await cur_r.aclose()
            except Exception:
                pass

    return StreamingResponse(
        gen(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"})


def render_chat_panel() -> str:
    """Chat panel markup with live model + credential options from the DB."""
    map_opts = []
    for m in sorted(MAPPINGS.values(), key=lambda x: str(x.get("fake_model") or "")):
        ctx = int(m.get("context_length") or 0)
        ctx_lbl = f"{ctx // 1000}k" if ctx else ""
        label = str(m.get("fake_model") or "")
        if ctx_lbl:
            label += f" · {ctx_lbl}"
        map_opts.append(f'<option value="{_esc(m["fake_model"])}">{_esc(label)}</option>')
    chat_models = "".join(map_opts) or '<option value="">— no models yet —</option>'

    cred_opts = []
    for r in sorted(KEYS_BY_ID.values(), key=lambda x: x.get("id") or 0):
        uk = r.get("upstream_key") or ""
        if not uk:
            continue
        note = r.get("note") or "unnamed"
        cred_opts.append(f'<option value="{r["id"]}">#{r["id"]} · {_esc(note)} · '
                         f'{_esc(mask_key(uk))}</option>')
    chat_creds = "".join(cred_opts) or '<option value="">— no key with an upstream key —</option>'

    return CHAT_HTML.format(chat_models=chat_models, chat_creds=chat_creds)


CHAT_CSS = r"""

/* ══════════════════════════════════════════════════════════════════════
   CHAT — Noosphere console
   ══════════════════════════════════════════════════════════════════════ */
@font-face{font-family:'Instrument Serif';font-style:normal;font-weight:400;font-display:swap;
  src:url(/fonts/instrumentserif-400-normal-latin-ext.woff2) format('woff2');
  unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Instrument Serif';font-style:normal;font-weight:400;font-display:swap;
  src:url(/fonts/instrumentserif-400-normal-latin.woff2) format('woff2');
  unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Instrument Serif';font-style:italic;font-weight:400;font-display:swap;
  src:url(/fonts/instrumentserif-400-italic-latin-ext.woff2) format('woff2');
  unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Instrument Serif';font-style:italic;font-weight:400;font-display:swap;
  src:url(/fonts/instrumentserif-400-italic-latin.woff2) format('woff2');
  unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'Inter';font-style:normal;font-weight:300 700;font-display:swap;
  src:url(/fonts/inter-300-700-normal-latin-ext.woff2) format('woff2');
  unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'Inter';font-style:normal;font-weight:300 700;font-display:swap;
  src:url(/fonts/inter-300-700-normal-latin.woff2) format('woff2');
  unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'IBM Plex Mono';font-style:normal;font-weight:400;font-display:swap;
  src:url(/fonts/ibmplexmono-400-normal-latin-ext.woff2) format('woff2');
  unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'IBM Plex Mono';font-style:normal;font-weight:400;font-display:swap;
  src:url(/fonts/ibmplexmono-400-normal-latin.woff2) format('woff2');
  unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:'IBM Plex Mono';font-style:normal;font-weight:500;font-display:swap;
  src:url(/fonts/ibmplexmono-500-normal-latin-ext.woff2) format('woff2');
  unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:'IBM Plex Mono';font-style:normal;font-weight:500;font-display:swap;
  src:url(/fonts/ibmplexmono-500-normal-latin.woff2) format('woff2');
  unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}

.chat-scope{
  --c-ink:#08070600;--c-bg:#0a0908;--c-s1:#100e0c;--c-s2:#151311;--c-s3:#1b1815;
  --c-line:rgba(223,192,116,.12);--c-line2:rgba(223,192,116,.26);
  --c-gold:#dfc074;--c-gold-hi:#f2dda6;--c-gold-dim:#8b7439;
  --c-bone:#f6f2e9;--c-bone2:#c6bfb1;--c-bone3:#8a8478;
  --c-bad:#e0705d;--c-ok:#82b78d;
  --c-serif:'Instrument Serif',ui-serif,Georgia,'Times New Roman',serif;
  --c-sans:'Inter',ui-sans-serif,-apple-system,'Segoe UI',Roboto,sans-serif;
  --c-mono:'IBM Plex Mono',ui-monospace,'SF Mono',Menlo,monospace;
}
.chat{display:flex;height:calc(100vh - 330px);
  height:clamp(540px,calc(100dvh - 330px),1180px);min-height:540px;
  background:linear-gradient(180deg,#0b0a09 0%,#080706 62%,#060505 100%);
  border:1px solid var(--c-line);border-radius:18px;overflow:hidden;position:relative;
  box-shadow:0 60px 140px -70px rgba(223,192,116,.20),0 1px 0 rgba(255,255,255,.025) inset;
  font-family:var(--c-sans);color:var(--c-bone)}
.chat::after{content:"";position:absolute;inset:0;pointer-events:none;z-index:5;opacity:.028;
  mix-blend-mode:overlay;
  background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.82' numOctaves='3' stitchTiles='stitch'/></filter><rect width='160' height='160' filter='url(%23n)'/></svg>")}

/* ── sidebar ─────────────────────────────────────────────────────── */
.chat-side{flex:0 0 252px;width:252px;display:flex;flex-direction:column;min-height:0;
  border-right:1px solid var(--c-line);background:linear-gradient(180deg,rgba(223,192,116,.028),transparent 40%)}
.cs-hd{display:flex;align-items:center;justify-content:space-between;gap:8px;
  padding:16px 14px 12px 18px}
.cs-brand{display:flex;align-items:center;gap:9px;min-width:0}
.cs-brand i{width:7px;height:7px;border-radius:50%;flex:0 0 7px;
  background:radial-gradient(circle at 35% 35%,var(--c-gold-hi),var(--c-gold-dim));
  box-shadow:0 0 10px rgba(223,192,116,.55)}
.cs-brand span{font-family:var(--c-serif);font-size:17px;letter-spacing:.01em;color:var(--c-bone);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cs-new{display:flex;align-items:center;gap:7px;width:100%;margin:4px 0 10px;
  padding:9px 12px;border-radius:10px;cursor:pointer;font:500 12.5px/1 var(--c-sans);
  color:var(--c-gold);background:rgba(223,192,116,.055);
  border:1px solid var(--c-line2);transition:background .16s,border-color .16s,transform .12s}
.cs-new:hover{background:rgba(223,192,116,.11);border-color:rgba(223,192,116,.42)}
.cs-new:active{transform:scale(.985)}
.cs-new svg{width:13px;height:13px;stroke-width:2}
.cs-new-wrap{padding:0 14px}
.cs-list{flex:1;overflow-y:auto;padding:2px 8px 8px;min-height:0}
.cs-list::-webkit-scrollbar{width:8px}
.cs-list::-webkit-scrollbar-thumb{background:rgba(223,192,116,.14);border-radius:8px}
.cs-item{display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:9px;
  cursor:pointer;color:var(--c-bone2);font-size:12.5px;line-height:1.35;
  border:1px solid transparent;transition:background .14s,color .14s;position:relative}
.cs-item:hover{background:rgba(255,255,255,.032);color:var(--c-bone)}
.cs-item.on{background:rgba(223,192,116,.075);border-color:var(--c-line2);color:var(--c-bone)}
.cs-item.on::before{content:"";position:absolute;left:-1px;top:9px;bottom:9px;width:2px;
  border-radius:2px;background:linear-gradient(180deg,var(--c-gold-hi),var(--c-gold-dim))}
.cs-item .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cs-item .x{opacity:0;border:0;background:transparent;color:var(--c-bone3);cursor:pointer;
  padding:2px;border-radius:5px;display:flex;flex:0 0 auto;transition:opacity .14s,color .14s}
.cs-item:hover .x{opacity:1}
.cs-item .x:hover{color:var(--c-bad)}
.cs-item .x svg{width:12px;height:12px}
.cs-empty{padding:22px 14px;color:var(--c-bone3);font-size:12px;line-height:1.6;text-align:center}
.cs-foot{border-top:1px solid var(--c-line);padding:12px 14px 14px;
  display:flex;flex-direction:column;gap:9px;background:rgba(0,0,0,.22)}
.cs-field{display:flex;flex-direction:column;gap:5px}
.cs-field label{font:500 9.5px/1 var(--c-sans);letter-spacing:.16em;text-transform:uppercase;color:var(--c-bone3)}
.cs-field select,.cs-field input,.cs-field textarea{
  width:100%;background:rgba(0,0,0,.42);color:var(--c-bone);border:1px solid var(--c-line);
  border-radius:8px;padding:7px 9px;font:400 12px/1.4 var(--c-sans);outline:none;
  transition:border-color .15s,box-shadow .15s;appearance:none;-webkit-appearance:none;resize:vertical}
.cs-field select{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='11' height='11' viewBox='0 0 24 24' fill='none' stroke='%238b7439' stroke-width='2.4' stroke-linecap='round'><polyline points='6 9 12 15 18 9'/></svg>");
  background-repeat:no-repeat;background-position:right 9px center;padding-right:26px}
.cs-field textarea{min-height:58px;font:400 11.5px/1.5 var(--c-mono)}
.cs-field select:focus,.cs-field input:focus,.cs-field textarea:focus{
  border-color:rgba(223,192,116,.42);box-shadow:0 0 0 3px rgba(223,192,116,.08)}
.cs-row{display:flex;align-items:center;justify-content:space-between;gap:8px}
.cs-switch{display:flex;align-items:center;gap:7px;cursor:pointer;user-select:none}
.cs-switch b{font:500 11px/1 var(--c-sans);color:var(--c-bone2);letter-spacing:.02em}
.cs-switch i{width:30px;height:17px;border-radius:20px;background:rgba(255,255,255,.07);
  border:1px solid var(--c-line);position:relative;transition:background .18s,border-color .18s;flex:0 0 auto}
.cs-switch i::after{content:"";position:absolute;top:2px;left:2px;width:11px;height:11px;border-radius:50%;
  background:var(--c-bone3);transition:transform .18s,background .18s}
.cs-switch.on i{background:rgba(223,192,116,.22);border-color:var(--c-line2)}
.cs-switch.on i::after{transform:translateX(13px);background:var(--c-gold)}
.cs-range{-webkit-appearance:none;appearance:none;height:3px;border-radius:3px;padding:0;
  background:linear-gradient(90deg,var(--c-gold-dim) 0%,var(--c-gold-dim) var(--p,50%),rgba(255,255,255,.09) var(--p,50%));
  border:0;outline:none;cursor:pointer}
.cs-range::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;border-radius:50%;
  background:var(--c-gold);box-shadow:0 0 0 3px rgba(223,192,116,.16);cursor:grab}
.cs-range::-moz-range-thumb{width:13px;height:13px;border:0;border-radius:50%;background:var(--c-gold)}

/* ── main ────────────────────────────────────────────────────────── */
.chat-main{flex:1;min-width:0;display:flex;flex-direction:column;position:relative}
.chat-top{display:flex;align-items:center;gap:12px;padding:13px 18px;min-height:56px;
  border-bottom:1px solid var(--c-line);
  background:linear-gradient(180deg,rgba(223,192,116,.03),transparent)}
.ct-title{font-family:var(--c-serif);font-size:18px;letter-spacing:.005em;color:var(--c-bone);
  flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ct-title em{font-style:italic;color:var(--c-gold)}
.ct-meta{display:flex;align-items:center;gap:7px;flex-wrap:wrap;justify-content:flex-end}
.ct-tag{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:100px;
  font:500 10.5px/1 var(--c-sans);letter-spacing:.04em;color:var(--c-bone2);
  background:rgba(255,255,255,.03);border:1px solid var(--c-line);white-space:nowrap}
.ct-tag::before{content:"";width:5px;height:5px;border-radius:50%;background:var(--c-gold-dim)}
.ct-tag.live{color:var(--c-gold);border-color:var(--c-line2);background:rgba(223,192,116,.075)}
.ct-tag.live::before{background:var(--c-gold);box-shadow:0 0 8px var(--c-gold);animation:cpulse 1.4s infinite}
.ct-tag.err{color:var(--c-bad);border-color:rgba(224,112,93,.32);background:rgba(224,112,93,.07)}
.ct-tag.err::before{background:var(--c-bad)}
@keyframes cpulse{0%,100%{opacity:1}50%{opacity:.35}}
.ct-icon{display:flex;align-items:center;justify-content:center;width:30px;height:30px;
  border-radius:8px;border:1px solid transparent;background:transparent;color:var(--c-bone3);
  cursor:pointer;transition:all .15s}
.ct-icon:hover{background:rgba(255,255,255,.04);color:var(--c-bone);border-color:var(--c-line)}
.ct-icon svg{width:14px;height:14px}
.ct-drawer{display:none}

.chat-main::before{content:"";position:absolute;left:50%;top:-90px;transform:translateX(-50%);
  width:640px;height:300px;pointer-events:none;z-index:0;opacity:.5;
  background:radial-gradient(closest-side,rgba(223,192,116,.10),transparent 72%)}
.chat-stream,.chat-top,.chat-compose{position:relative;z-index:1}
/* ── stream ──────────────────────────────────────────────────────── */
.chat-stream{flex:1;overflow-y:auto;overflow-x:hidden;padding:26px 0 10px;min-height:0;
  scrollbar-gutter:stable}
.chat-stream::-webkit-scrollbar{width:9px}
.chat-stream::-webkit-scrollbar-thumb{background:rgba(223,192,116,.13);border-radius:9px;
  border:3px solid transparent;background-clip:content-box}
.chat-stream::-webkit-scrollbar-thumb:hover{background:rgba(223,192,116,.28);background-clip:content-box}
.msg{max-width:min(760px,calc(100% - 64px));margin:0 auto 26px;position:relative;
  animation:crise .34s cubic-bezier(.2,.7,.2,1)}
@keyframes crise{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}
.msg-hd{display:flex;align-items:baseline;gap:9px;margin-bottom:9px}
.msg-hd .who{font:500 12px/1 var(--c-sans);letter-spacing:.02em}
.msg-hd .t{font:400 10px/1 var(--c-mono);color:var(--c-bone3);letter-spacing:.04em}
.msg-hd .badge{font:500 9.5px/1 var(--c-mono);letter-spacing:.1em;text-transform:uppercase;
  color:var(--c-gold-dim);border:1px solid var(--c-line);border-radius:4px;padding:2px 6px}
.msg-u .msg-hd{justify-content:flex-end}
.msg-u .msg-body{margin-left:auto;max-width:min(620px,88%);
  background:linear-gradient(180deg,rgba(255,255,255,.052),rgba(255,255,255,.028));
  border:1px solid rgba(255,255,255,.07);border-radius:14px 14px 4px 14px;
  padding:12px 15px;color:var(--c-bone);font-size:14px;line-height:1.62;white-space:pre-wrap;
  word-break:break-word}
.msg-a{padding-left:18px}
.msg-a::before{content:"";position:absolute;left:0;top:26px;bottom:8px;width:1.5px;border-radius:2px;
  background:linear-gradient(180deg,var(--c-gold) 0%,rgba(223,192,116,.22) 55%,transparent 100%)}
.msg-a .msg-hd .who{color:var(--c-gold)}
.msg-a .msg-body{color:var(--c-bone);font-size:14.5px;line-height:1.72;word-break:break-word}
.msg-err .msg-body{border:1px solid rgba(224,112,93,.3);background:rgba(224,112,93,.055);
  border-radius:12px;padding:12px 15px;color:#f3c4bb;font:400 12.5px/1.6 var(--c-mono);
  white-space:pre-wrap;word-break:break-word}
.msg-files{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}
.msg-u .msg-files{justify-content:flex-end}
.mfile{display:inline-flex;align-items:center;gap:6px;padding:5px 9px;border-radius:8px;
  background:rgba(223,192,116,.06);border:1px solid var(--c-line);
  font:400 11px/1 var(--c-mono);color:var(--c-bone2);max-width:100%}
.mfile svg{width:11px;height:11px;flex:0 0 auto;color:var(--c-gold-dim)}
.mfile span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:230px}
.msg-thumb{width:96px;height:96px;border-radius:10px;object-fit:cover;border:1px solid var(--c-line2);
  background:#000;display:block}

/* reasoning strip */
.mreason{margin-bottom:10px}
.mreason>button{display:inline-flex;align-items:center;gap:7px;padding:4px 0;border:0;background:transparent;
  cursor:pointer;color:var(--c-bone3);font:500 10.5px/1 var(--c-sans);letter-spacing:.13em;
  text-transform:uppercase;transition:color .15s}
.mreason>button:hover{color:var(--c-bone2)}
.mreason>button svg{width:11px;height:11px;transition:transform .2s}
.mreason.open>button svg{transform:rotate(90deg)}
.mreason>div{display:none;margin-top:7px;padding:11px 14px;border-radius:10px;
  border:1px dashed var(--c-line);background:rgba(255,255,255,.014);
  font-family:var(--c-serif);font-style:italic;font-size:14px;line-height:1.65;color:var(--c-bone2);
  white-space:pre-wrap;word-break:break-word;max-height:340px;overflow-y:auto}
.mreason.open>div{display:block}

/* search activity */
.sline{display:flex;align-items:center;gap:10px;margin:0 auto 22px;max-width:min(760px,calc(100% - 64px));
  color:var(--c-bone3);font:400 11.5px/1 var(--c-sans);animation:crise .3s ease}
.sline .sd{width:6px;height:6px;border-radius:50%;flex:0 0 6px;background:var(--c-gold);
  box-shadow:0 0 9px var(--c-gold);animation:cpulse 1.1s infinite}
.sline.done .sd{background:var(--c-ok);box-shadow:none;animation:none}
.sline .lbl{letter-spacing:.1em;text-transform:uppercase;font-size:10px;font-weight:600;color:var(--c-gold-dim)}
.sline q{font-family:var(--c-serif);font-style:italic;font-size:15px;color:var(--c-bone2);
  quotes:"\201C" "\201D";overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.sline .ms{margin-left:auto;font:400 10px/1 var(--c-mono);color:var(--c-bone3);
  font-variant-numeric:tabular-nums;flex:0 0 auto}
.sline .bar{flex:1;height:1px;min-width:16px;
  background:linear-gradient(90deg,var(--c-line2),transparent)}

/* typing caret */
.caret{display:inline-block;width:7px;height:15px;margin-left:2px;vertical-align:-2px;
  background:var(--c-gold);animation:cblink 1s steps(2,start) infinite;border-radius:1px}
@keyframes cblink{0%,100%{opacity:1}50%{opacity:0}}
.think-dots{display:inline-flex;gap:4px;align-items:center;height:15px}
.think-dots i{width:5px;height:5px;border-radius:50%;background:var(--c-gold-dim);
  animation:cdot 1.15s infinite ease-in-out}
.think-dots i:nth-child(2){animation-delay:.14s}
.think-dots i:nth-child(3){animation-delay:.28s}
@keyframes cdot{0%,80%,100%{transform:translateY(0);opacity:.45}40%{transform:translateY(-4px);opacity:1}}

/* ── empty state ─────────────────────────────────────────────────── */
.chat-empty{max-width:660px;margin:0 auto;padding:min(7vh,58px) 24px 20px;text-align:center}
.ce-mark{margin:0 auto 20px;width:46px;height:46px;opacity:.9}
.ce-mark svg{width:100%;height:100%;color:var(--c-gold)}
.chat-empty h3{font-family:var(--c-serif);font-weight:400;font-size:clamp(30px,4.6vw,44px);
  line-height:1.08;letter-spacing:-.008em;color:var(--c-bone);margin-bottom:14px}
.chat-empty h3 em{font-style:italic;
  background:linear-gradient(100deg,var(--c-gold-hi),var(--c-gold) 45%,var(--c-gold-dim));
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.chat-empty p{color:var(--c-bone3);font-size:13px;line-height:1.75;max-width:430px;margin:0 auto}
.ce-chips{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:28px}
.ce-chip{text-align:left;padding:12px 14px;border-radius:11px;cursor:pointer;
  background:rgba(255,255,255,.022);border:1px solid var(--c-line);
  color:var(--c-bone2);font:400 12.5px/1.5 var(--c-sans);transition:all .18s var(--t)}
.ce-chip:hover{background:rgba(223,192,116,.07);border-color:var(--c-line2);color:var(--c-bone);
  transform:translateY(-1px)}
.ce-chip b{display:block;color:var(--c-gold);font-weight:500;font-size:10px;letter-spacing:.13em;
  text-transform:uppercase;margin-bottom:5px}

/* ── composer ────────────────────────────────────────────────────── */
.chat-compose{padding:12px 18px 16px;border-top:1px solid var(--c-line);
  background:linear-gradient(0deg,rgba(223,192,116,.028),transparent 70%)}
.compose-inner{max-width:min(760px,100%);margin:0 auto}
.cbox{position:relative;border:1px solid var(--c-line);border-radius:15px;
  background:rgba(0,0,0,.4);transition:border-color .18s,box-shadow .18s}
.cbox.focus{border-color:rgba(223,192,116,.4);box-shadow:0 0 0 4px rgba(223,192,116,.065)}
.cbox.drop{border-color:var(--c-gold);border-style:dashed;background:rgba(223,192,116,.05)}
.cbox textarea{display:block;width:100%;border:0;outline:none;background:transparent;resize:none;
  color:var(--c-bone);font:400 14px/1.6 var(--c-sans);padding:14px 16px 4px;max-height:220px;
  overflow-y:auto;box-sizing:border-box}
.cbox textarea::placeholder{color:var(--c-bone3)}
.crow{display:flex;align-items:center;gap:8px;padding:6px 8px 8px 10px}
.crow .sp{flex:1}
.cbtn{display:inline-flex;align-items:center;gap:6px;height:30px;padding:0 10px;border-radius:9px;
  border:1px solid transparent;background:transparent;color:var(--c-bone3);cursor:pointer;
  font:500 11.5px/1 var(--c-sans);transition:all .15s}
.cbtn:hover{background:rgba(255,255,255,.045);color:var(--c-bone);border-color:var(--c-line)}
.cbtn svg{width:14px;height:14px}
.cbtn.on{color:var(--c-gold);border-color:var(--c-line2);background:rgba(223,192,116,.08)}
.chint{font:400 10px/1 var(--c-mono);color:var(--c-bone3);letter-spacing:.03em;
  padding-right:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.csend{display:inline-flex;align-items:center;justify-content:center;gap:7px;height:32px;
  min-width:82px;padding:0 14px;border-radius:9px;border:1px solid transparent;cursor:pointer;
  font:500 12.5px/1 var(--c-sans);color:#100e08;
  background:linear-gradient(180deg,var(--c-gold-hi),var(--c-gold) 60%,#c9a95e);
  box-shadow:0 6px 18px -8px rgba(223,192,116,.7);transition:filter .15s,transform .12s}
.csend:hover:not(:disabled){filter:brightness(1.07)}
.csend:active:not(:disabled){transform:scale(.975)}
.csend:disabled{opacity:.4;cursor:not-allowed;box-shadow:none}
.csend svg{width:14px;height:14px}
.csend.stop{background:linear-gradient(180deg,#f4a08f,#e0705d);color:#1a0d09}
.cattach{display:flex;flex-wrap:wrap;gap:6px;padding:10px 10px 0}
.att{position:relative;display:flex;align-items:center;gap:8px;padding:6px 8px 7px 6px;
  border-radius:10px;background:rgba(255,255,255,.03);border:1px solid var(--c-line);
  width:238px;max-width:100%;transition:border-color .2s,background .2s}
.att.ready{border-color:rgba(223,192,116,.26);background:rgba(223,192,116,.035)}
.att img{width:30px;height:30px;border-radius:7px;object-fit:cover;flex:0 0 auto;background:#000}
.att .ic{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;
  background:rgba(223,192,116,.09);color:var(--c-gold);flex:0 0 auto;overflow:hidden;position:relative}
.att .ic svg{width:14px;height:14px}
.att .ic.ph::after{content:"";position:absolute;inset:0;
  background:linear-gradient(100deg,transparent 18%,rgba(223,192,116,.32) 50%,transparent 82%);
  animation:cshine 1.1s linear infinite}
@keyframes cshine{from{transform:translateX(-105%)}to{transform:translateX(105%)}}
.att .meta{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
.att .nm{font:400 11px/1.25 var(--c-mono);color:var(--c-bone2);overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.att .st{display:flex;align-items:center;gap:6px;min-width:0}
.att .pb{flex:1;height:2px;border-radius:2px;background:rgba(255,255,255,.1);
  overflow:hidden;min-width:24px}
.att .pb b{display:block;height:100%;width:0;border-radius:2px;
  background:linear-gradient(90deg,var(--c-gold-dim),var(--c-gold));transition:width .15s linear}
.att.ready .pb b{background:linear-gradient(90deg,var(--c-gold),var(--c-gold-hi))}
.att .lbl{font:400 9.5px/1 var(--c-mono);color:var(--c-bone3);white-space:nowrap;
  font-variant-numeric:tabular-nums;flex:0 0 auto}
.att.ready .lbl{color:var(--c-gold)}
.att .rm{width:17px;height:17px;border-radius:5px;border:0;background:rgba(0,0,0,.4);color:var(--c-bone2);
  cursor:pointer;display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.att .rm:hover{background:var(--c-bad);color:#1a0d09}
.att .rm svg{width:10px;height:10px}
.csend.wait{background:rgba(223,192,116,.13);color:var(--c-gold);
  border:1px solid var(--c-line2);box-shadow:none;cursor:progress}
.csend .spin{width:11px;height:11px;border-radius:50%;border:1.6px solid currentColor;
  border-top-color:transparent;animation:cspin .7s linear infinite;flex:0 0 auto}
@keyframes cspin{to{transform:rotate(360deg)}}
.cfoot{margin-top:8px;text-align:center;font:400 10px/1.5 var(--c-mono);color:#5c564c;letter-spacing:.03em}
.jump{position:absolute;left:50%;transform:translateX(-50%);bottom:96px;z-index:6;
  display:none;align-items:center;gap:6px;padding:6px 12px;border-radius:100px;
  background:rgba(16,14,12,.94);border:1px solid var(--c-line2);color:var(--c-bone2);
  cursor:pointer;font:500 11px/1 var(--c-sans);backdrop-filter:blur(8px)}
.jump.on{display:inline-flex}
.jump svg{width:12px;height:12px}

/* ── markdown ────────────────────────────────────────────────────── */
.md>*:first-child{margin-top:0}
.md>*:last-child{margin-bottom:0}
.md p{margin:0 0 12px}
.md h1,.md h2,.md h3,.md h4{font-family:var(--c-serif);font-weight:400;color:var(--c-bone);
  margin:22px 0 10px;line-height:1.2;letter-spacing:-.005em}
.md h1{font-size:26px}.md h2{font-size:22px}.md h3{font-size:18.5px}.md h4{font-size:16px}
.md h1:first-child,.md h2:first-child,.md h3:first-child{margin-top:0}
.md strong{color:#fff;font-weight:600}
.md em{font-style:italic;color:var(--c-bone)}
.md del{color:var(--c-bone3)}
.md a{color:var(--c-gold);text-decoration:none;border-bottom:1px solid rgba(223,192,116,.32);
  transition:border-color .15s,color .15s;word-break:break-word}
.md a:hover{color:var(--c-gold-hi);border-color:var(--c-gold-hi)}
.md ul,.md ol{margin:0 0 12px;padding-left:22px}
.md li{margin:5px 0;position:relative}
.md ul>li::marker{color:var(--c-gold-dim)}
.md ol>li::marker{color:var(--c-gold-dim);font-family:var(--c-mono);font-size:12px}
.md li>ul,.md li>ol{margin:5px 0 0}
.md blockquote{margin:14px 0;padding:2px 0 2px 15px;border-left:2px solid var(--c-line2);
  color:var(--c-bone2);font-family:var(--c-serif);font-style:italic;font-size:15.5px}
.md hr{border:0;height:1px;margin:20px 0;
  background:linear-gradient(90deg,transparent,var(--c-line2) 30%,var(--c-line2) 70%,transparent)}
.md code{font:400 12.5px/1.5 var(--c-mono);background:rgba(223,192,116,.075);
  border:1px solid var(--c-line);border-radius:5px;padding:1.5px 5px;color:var(--c-gold-hi);
  word-break:break-word}
.md-code{margin:14px 0;border:1px solid var(--c-line);border-radius:11px;overflow:hidden;
  background:#060505}
.md-code-hd{display:flex;align-items:center;justify-content:space-between;gap:10px;
  padding:7px 12px;border-bottom:1px solid var(--c-line);background:rgba(223,192,116,.035)}
.md-code-hd .lg{font:500 9.5px/1 var(--c-mono);letter-spacing:.14em;text-transform:uppercase;
  color:var(--c-gold-dim)}
.md-copy{display:inline-flex;align-items:center;gap:5px;border:0;background:transparent;
  color:var(--c-bone3);cursor:pointer;font:500 10px/1 var(--c-sans);letter-spacing:.08em;
  text-transform:uppercase;padding:3px 6px;border-radius:5px;transition:all .15s}
.md-copy:hover{color:var(--c-gold);background:rgba(223,192,116,.09)}
.md-copy svg{width:11px;height:11px}
.md-code pre{margin:0;padding:13px 15px;overflow-x:auto}
.md-code pre::-webkit-scrollbar{height:8px}
.md-code pre::-webkit-scrollbar-thumb{background:rgba(223,192,116,.16);border-radius:8px}
.md-code code{font:400 12.5px/1.65 var(--c-mono);background:none;border:0;padding:0;
  color:#ddd6c6;white-space:pre;display:block}
.md table{width:100%;border-collapse:collapse;margin:14px 0;font-size:13px}
.md th,.md td{border:1px solid var(--c-line);padding:8px 11px;text-align:left;vertical-align:top}
.md th{background:rgba(223,192,116,.05);color:var(--c-gold);font-weight:500;font-size:11.5px;
  letter-spacing:.05em;text-transform:uppercase}
.md td{color:var(--c-bone2)}
.md-tw{overflow-x:auto;margin:14px 0}
.md-tw::-webkit-scrollbar{height:8px}
.md-tw::-webkit-scrollbar-thumb{background:rgba(223,192,116,.16);border-radius:8px}
.md-tw table{margin:0;min-width:380px}

/* ── responsive ──────────────────────────────────────────────────── */
@media(max-width:960px){
  .chat{height:calc(100vh - 210px);height:calc(100dvh - 210px);min-height:500px;border-radius:14px}
  .chat-side{position:absolute;top:0;bottom:0;left:0;z-index:20;width:270px;flex-basis:270px;
    background:#0c0a09;transform:translateX(-101%);transition:transform .26s cubic-bezier(.3,.8,.3,1);
    box-shadow:26px 0 60px -20px rgba(0,0,0,.9)}
  .chat-side.open{transform:none}
  .ct-drawer{display:flex}
  .msg{max-width:calc(100% - 32px)}
  .msg-a{padding-left:15px}
  .sline{max-width:calc(100% - 32px)}
  .ce-chips{grid-template-columns:1fr}
  .chat-stream{padding:20px 0 8px}
  .chat-compose{padding:10px 12px 14px}
}
@media(max-width:640px){
  .chat{height:calc(100vh - 150px);height:calc(100dvh - 150px);min-height:440px}
  .cfoot{display:none}
  .cbox textarea{padding:12px 13px 2px}
  .crow{padding:5px 6px 6px 8px}
  .msg-a .msg-body{font-size:14px}
  .md h1{font-size:22px}.md h2{font-size:19px}.md h3{font-size:16.5px}
  .chat-top{padding:10px 12px;min-height:52px;gap:8px}
  .ct-title{font-size:15.5px}
  .ct-meta .hide-s{display:none}
  .ct-icon{width:34px;height:34px}
  .msg{max-width:calc(100% - 22px);margin-bottom:20px}
  .msg-a{padding-left:13px}
  .msg-a::before{top:22px}
  .chat-empty{padding:34px 16px 12px}
  .chat-empty h3{font-size:30px}
  .chint{display:none}
  .csend{min-width:64px;padding:0 12px}
  .msg-thumb{width:78px;height:78px}
}

/* when the chat tab is open the console becomes a chat — let it own the viewport */
.wrap:has(.panel[data-p="chat"].on){padding-bottom:30px}
"""

CHAT_JS = r"""
/* ══════════════════════════════════════════════════════════════════════
   CHAT — Noosphere console
   ══════════════════════════════════════════════════════════════════════ */
const CKEY = 'ns_chat_v2';
const CS = { convs: [], active: null, model: '', system: '', search: true, temp: 0.7, cred: '' };
let ctl = null, busy = false, pend = [];

function cNow(){ const d = new Date();
  return String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0'); }
function cUID(){ return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function cFmt(n){ return n < 1024 ? n + ' B'
  : n < 1048576 ? (n/1024).toFixed(n < 10240 ? 1 : 0) + ' KB'
  : (n/1048576).toFixed(1) + ' MB'; }

function cLoad(){
  try{
    const raw = localStorage.getItem(CKEY);
    if(!raw) return;
    const o = JSON.parse(raw);
    if(o && Array.isArray(o.convs)) CS.convs = o.convs;
    if(o){
      CS.active = o.active || null;
      CS.system = o.system || '';
      CS.temp = (typeof o.temp === 'number') ? o.temp : 0.7;
      CS.search = o.search !== false;
      CS.cred = o.cred || '';
    }
  }catch(e){}
}
function cSave(){
  try{
    localStorage.setItem(CKEY, JSON.stringify({
      convs: CS.convs.slice(0,60), active: CS.active, system: CS.system,
      temp: CS.temp, search: CS.search, cred: CS.cred }));
  }catch(e){}
}
function cConv(){
  let c = CS.convs.find(x => x.id === CS.active);
  if(!c){ c = { id:cUID(), title:'', msgs:[], at:Date.now(), model:CS.model };
    CS.convs.unshift(c); CS.active = c.id; }
  return c;
}
function cTitle(c){
  if(c.title) return c.title;
  const u = (c.msgs || []).find(m => m.role === 'user' && m.text);
  let t = u ? u.text.replace(/\s+/g,' ').trim() : '';
  if(t.length > 54) t = t.slice(0,54).replace(/[\s,;:.\-]+$/,'') + '…';
  return t || 'New conversation';
}
function cModelLabel(){
  const s = q('#c-model');
  if(!s) return 'Noosphere';
  const o = s.options[s.selectedIndex];
  return o ? o.textContent.trim() : 'Noosphere';
}

/* ── markdown ─────────────────────────────────────────────────────── */
function cEsc(s){
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function cInline(t){
  const codes = [];
  t = t.replace(/`([^`\n]+)`/g, (m,c) => { codes.push(c); return '\u0001' + (codes.length-1) + '\u0001'; });
  t = t.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)/g,
        '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  t = t.replace(/(^|[\s(>])(https?:\/\/[^\s<)]+)/g,
        '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');
  t = t.replace(/\*\*\*([^*\n]+)\*\*\*/g, '<strong><em>$1</em></strong>');
  t = t.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/(^|[^*\w])\*([^*\n]+?)\*(?!\*)/g, '$1<em>$2</em>');
  t = t.replace(/(^|[\s(])_([^_\n]+)_(?=[\s).,;:!?]|$)/g, '$1<em>$2</em>');
  t = t.replace(/~~([^~\n]+)~~/g, '<del>$1</del>');
  t = t.replace(/\u0001(\d+)\u0001/g, (m,i) => '<code>' + codes[+i] + '</code>');
  return t;
}
function cMd(src){
  if(!src) return '';
  const fences = [];
  let s = String(src).replace(/\r\n?/g, '\n');
  s = s.replace(/```([A-Za-z0-9_+.#\-]*)[ \t]*\n([\s\S]*?)(?:```|$)/g, (m,lang,code) => {
    fences.push({ lang:(lang || 'text').toLowerCase(), code:code.replace(/\n$/,'') });
    return '\u0002' + (fences.length-1) + '\u0002';
  });
  s = cEsc(s);
  const lines = s.split('\n');
  const out = [];
  let i = 0, para = [], list = null, quote = [];

  const flushP = () => { if(para.length){ out.push('<p>' + cInline(para.join('\n')).replace(/\n/g,'<br>') + '</p>'); para = []; } };
  const flushQ = () => { if(quote.length){ out.push('<blockquote>' + cInline(quote.join('\n')).replace(/\n/g,'<br>') + '</blockquote>'); quote = []; } };
  const flushL = () => { if(list){ out.push('<' + list.t + '>' + list.items.map(x => '<li>' + x + '</li>').join('') + '</' + list.t + '>'); list = null; } };
  const flushAll = () => { flushP(); flushQ(); flushL(); };

  while(i < lines.length){
    const ln = lines[i].trim();

    if(/^\u0002\d+\u0002$/.test(ln)){
      flushAll();
      const f = fences[+ln.replace(/\u0002/g,'')];
      out.push('<div class="md-code"><div class="md-code-hd"><span class="lg">' + cEsc(f.lang) +
        '</span><button type="button" class="md-copy" onclick="cCopyCode(this)">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copy</button></div>' +
        '<pre><code>' + cEsc(f.code) + '</code></pre></div>');
      i++; continue;
    }
    if(!ln){ flushAll(); i++; continue; }
    if(/^(\-{3,}|_{3,})$/.test(ln)){ flushAll(); out.push('<hr>'); i++; continue; }

    const h = ln.match(/^(#{1,4})\s+(.*)$/);
    if(h){ flushAll(); const n = h[1].length; out.push('<h' + n + '>' + cInline(h[2]) + '</h' + n + '>'); i++; continue; }

    if(/^&gt;\s?/.test(ln)){
      flushP(); flushL(); quote.push(ln.replace(/^&gt;\s?/,''));
      while(i+1 < lines.length && /^&gt;\s?/.test(lines[i+1].trim())){
        i++; quote.push(lines[i].trim().replace(/^&gt;\s?/,''));
      }
      flushQ(); i++; continue;
    }

    if(/^\|.*\|$/.test(ln) && i+1 < lines.length && /^\|?[\s:|\-]+\|[\s:|\-]*$/.test(lines[i+1].trim())){
      flushAll();
      const cells = r => r.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(x => x.trim());
      const head = cells(ln);
      i += 2;
      const rows = [];
      while(i < lines.length && lines[i].trim() && lines[i].indexOf('|') >= 0){ rows.push(cells(lines[i])); i++; }
      out.push('<div class="md-tw"><table><thead><tr>' + head.map(x => '<th>' + cInline(x) + '</th>').join('') +
        '</tr></thead><tbody>' + rows.map(r => '<tr>' + head.map((_,k) => '<td>' + cInline(r[k] || '') + '</td>').join('') + '</tr>').join('') +
        '</tbody></table></div>');
      continue;
    }

    const ul = ln.match(/^[\-*+]\s+(.*)$/), ol = ln.match(/^\d+[.)]\s+(.*)$/);
    if(ul || ol){
      flushP(); flushQ();
      const t = ol ? 'ol' : 'ul';
      if(!list || list.t !== t) flushL();
      if(!list) list = { t:t, items:[] };
      list.items.push(cInline(ul ? ul[1] : ol[1]));
      i++; continue;
    }

    flushL(); para.push(ln); i++;
  }
  flushAll();
  return out.join('');
}
function cCopyCode(btn){
  const box = btn.closest('.md-code');
  if(!box) return;
  const code = box.querySelector('code');
  cCopy(code ? code.textContent : '', btn);
}
function cCopy(text, btn){
  const done = () => { if(!btn) return; const o = btn.innerHTML;
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>Copied';
    setTimeout(() => { btn.innerHTML = o; }, 1300); };
  const fb = () => { const ta = document.createElement('textarea'); ta.value = text;
    ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); done(); }catch(e){} document.body.removeChild(ta); };
  if(navigator.clipboard && window.isSecureContext){ navigator.clipboard.writeText(text).then(done).catch(fb); } else fb();
}

/* ── sidebar ──────────────────────────────────────────────────────── */
function cRenderList(){
  const box = q('#c-list');
  if(!box) return;
  if(!CS.convs.length){
    box.innerHTML = '<div class="cs-empty">No conversations yet.<br>Ask something below.</div>';
    return;
  }
  box.innerHTML = CS.convs.map(c =>
    '<div class="cs-item' + (c.id === CS.active ? ' on' : '') + '" data-id="' + c.id + '">' +
      '<span class="t">' + cEsc(cTitle(c)) + '</span>' +
      '<button type="button" class="x" title="Delete" data-del="' + c.id + '">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
      '</button></div>').join('');
  qa('.cs-item', box).forEach(el => el.addEventListener('click', e => {
    if(e.target.closest('[data-del]') || busy) return;
    CS.active = el.dataset.id; cSave(); cRenderList(); cRenderMsgs(); cSide(false);
  }));
  qa('[data-del]', box).forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    if(busy) return;
    const id = b.dataset.del;
    CS.convs = CS.convs.filter(c => c.id !== id);
    if(CS.active === id) CS.active = CS.convs.length ? CS.convs[0].id : null;
    cSave(); cRenderList(); cRenderMsgs();
  }));
}
function cSide(open){
  const s = q('#c-aside');
  if(!s) return;
  if(typeof open === 'boolean') s.classList.toggle('open', open);
  else s.classList.toggle('open');
}

/* ── messages ─────────────────────────────────────────────────────── */
function cFileChip(f){
  const ic = f.kind === 'image'
    ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>'
    : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
  return '<span class="mfile">' + ic + '<span>' + cEsc(f.name) + '</span>' +
    (f.parts > 1 ? '<span style="color:var(--c-gold)">\u00d7' + f.parts + '</span>' : '') +
    (f.bytes ? '<span style="color:var(--c-bone3)">' + cFmt(f.bytes) + '</span>' : '') + '</span>';
}
function cMs(v){
  v = Math.round(v || 0);
  return v < 10 ? "<10 ms" : v + " ms";
}
function cSearchLine(s, done){
  const el = document.createElement('div');
  const retry = s.kind === 'retry';
  el.className = 'sline' + (done ? ' done' : '');
  el.innerHTML = '<span class="sd"></span><span class="lbl">' +
    (retry ? 'Retry' : (s.read ? 'Read' : 'Search')) + '</span>' +
    '<q>' + cEsc(s.query || '') + '</q><span class="bar"></span>' +
    (retry ? '' : '<span class="ms">' + (done ? cMs(s.ms) : '…') + '</span>');
  return el;
}
function cMsgEl(m){
  const el = document.createElement('article');
  const isU = m.role === 'user';
  el.className = 'msg ' + (isU ? 'msg-u' : 'msg-a') + (m.error ? ' msg-err' : '');
  el.dataset.mid = m.mid || '';

  let h = '<div class="msg-hd">' + (isU
    ? '<span class="t">' + cEsc(m.at || '') + '</span><span class="who">You</span>'
    : '<span class="who">' + cEsc(m.label || 'Noosphere') + '</span>' +
      (m.at ? '<span class="t">' + cEsc(m.at) + '</span>' : '') +
      (m.model ? '<span class="badge">' + cEsc(m.model) + '</span>' : '')) + '</div>';

  if(isU){
    if(m.thumbs && m.thumbs.length)
      h += '<div class="msg-body" style="background:none;border:0;padding:0;display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;max-width:100%">' +
        m.thumbs.map(u => '<img class="msg-thumb" src="' + u + '" alt="">').join('') + '</div>';
    if(m.text) h += '<div class="msg-body">' + cEsc(m.text) + '</div>';
    if(m.files && m.files.length) h += '<div class="msg-files">' + m.files.map(cFileChip).join('') + '</div>';
    el.innerHTML = h;
    return el;
  }

  if(m.reason && !m.streaming)
    h += '<div class="mreason"><button type="button">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>Reasoning</button>' +
      '<div>' + cEsc(m.reason) + '</div></div>';
  else if(m.reason)
    h += '<div class="mreason open"><button type="button">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>Reasoning…</button>' +
      '<div>' + cEsc(m.reason) + '</div></div>';

  h += '<div class="msg-body"><div class="md"></div></div>';
  el.innerHTML = h;

  const body = el.querySelector('.md');
  if(m.error){
    body.innerHTML = '<div style="white-space:pre-wrap">' + cEsc(m.error) + '</div>';
    if(m.text){
      const d = document.createElement('div');
      d.className = 'md';
      d.style.marginTop = '12px';
      d.innerHTML = cMd(m.text);
      el.querySelector('.msg-body').appendChild(d);
    }
  } else {
    body.innerHTML = cMd(m.text || '');
  }

  const files = el.querySelector('.msg-files');
  if(files && m.files && m.files.length) files.innerHTML = m.files.map(cFileChip).join('');
  else if(files) files.remove();

  const rb = el.querySelector('.mreason > button');
  if(rb) rb.addEventListener('click', () => el.querySelector('.mreason').classList.toggle('open'));

  if(!isU && !m.streaming){
    const acts = document.createElement('div');
    acts.style.cssText = 'display:flex;gap:6px;margin-top:12px;opacity:.5;transition:opacity .15s';
    acts.innerHTML = '<button type="button" class="md-copy" data-copy="1">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copy</button>' +
      '<button type="button" class="md-copy" data-retry="1">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>Retry</button>';
    el.querySelector('.msg-body').appendChild(acts);
    acts.addEventListener('mouseenter', () => acts.style.opacity = '1');
    acts.addEventListener('mouseleave', () => acts.style.opacity = '.5');
    acts.querySelector('[data-copy]').addEventListener('click', e => cCopy(m.error || m.text || '', e.currentTarget));
    acts.querySelector('[data-retry]').addEventListener('click', () => { if(!busy) cRetry(m.mid); });
  }
  return el;
}
function cRenderMsgs(){
  const st = q('#c-stream');
  if(!st) return;
  qa('.msg, .sline', st).forEach(x => x.remove());
  const c = CS.convs.find(x => x.id === CS.active);
  if(!c || !c.msgs.length){ cEmpty(true); return; }
  cEmpty(false);
  const frag = document.createDocumentFragment();
  c.msgs.forEach(m => {
    if(m.search && m.search.length) m.search.forEach(s => frag.appendChild(cSearchLine(s, true)));
    frag.appendChild(cMsgEl(m));
  });
  st.appendChild(frag);
  cJump(false);
  cToEnd(true);
}
function cEmpty(on){ const e = q('#c-empty'); if(e) e.style.display = on ? '' : 'none'; }
function cToEnd(force){
  const st = q('#c-stream');
  if(!st) return;
  const near = st.scrollHeight - st.scrollTop - st.clientHeight < 180;
  if(force || near) st.scrollTop = st.scrollHeight;
  else cJump(true);
}
function cJump(on){ const j = q('#c-jump'); if(j) j.classList.toggle('on', !!on); }

/* ── attachments ──────────────────────────────────────────────────── */
const CMAX_SIDE = 1568;       // longest side of any single part handed to the model
const CMAX_TILES = 6;         // hard cap on parts per attached image
const CTILE_TRIGGER = 2.2;    // slice once the long side exceeds this multiple
const CMAX_KEEP = 1500000;    // below this a lossless file goes through untouched
const CQUALITY = 0.92;
const MAX_TOTAL_PARTS = 24;   // must stay within ADMIN_CHAT_MAX_FILES on the server
let pid = 0;

function cPushFiles(list){
  for(const f of list){
    if(pend.length >= 8) break;
    if(f.size > 24*1024*1024){ cToast('Too large (max 24 MB): ' + f.name); continue; }
    if(pend.some(x => x.file.name === f.name && x.file.size === f.size)) continue;
    const e = { id:'p' + (++pid), file:f, name:f.name,
                kind:/^image\//.test(f.type) ? 'image' : 'file',
                in:f.size, parts:null, outSize:0, url:null, note:'', dims:null,
                plan:1, state:'working', stage:'queued', p:0, _p:-1, _s:'' };
    pend.push(e);
    cPrep(e);
  }
  cRenderAtt();
  cSendBtn();
}
function cReadWithProgress(file, onProgress){
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onprogress = ev => { if(ev.lengthComputable) onProgress(ev.loaded, ev.total || file.size); };
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error || new Error('read failed'));
    r.readAsArrayBuffer(file);
  });
}
function cToBlob(canvas, type, quality){
  return new Promise(res => {
    try{ canvas.toBlob(b => res(b || null), type, quality); }catch(err){ res(null); }
  });
}
function cCanEncode(type){
  try{
    const cv = document.createElement('canvas');
    cv.width = cv.height = 1;
    return cv.toDataURL(type).indexOf('data:' + type) === 0;
  }catch(err){ return false; }
}
function cDraw(bmp, sx, sy, sw, sh, dw, dh){
  const cv = document.createElement('canvas');
  cv.width = dw; cv.height = dh;
  const ctx = cv.getContext('2d');
  if(ctx){
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bmp, sx, sy, sw, sh, 0, 0, dw, dh);
  }
  return cv;
}
function cPartBudget(e){
  // leave room for the other attachments so the whole message keeps its parts
  const used = pend.reduce((n, x) => n + (x === e ? 0 : (x.plan || 1)), 0);
  return Math.max(1, MAX_TOTAL_PARTS - used);
}
function cPrepDone(e){
  e.state = 'ready';
  e.stage = 'ready';
  e.p = 100;
  if(e.kind === 'image' && !e.url){
    try{ e.url = URL.createObjectURL(e.parts[0].blob); }catch(err){}
  }
  // full repaint: the name, the byte counts and the thumbnail all change on finish
  cRenderAtt();
  cSendBtn();
}
async function cPrep(e){
  try{
    const raw = await cReadWithProgress(e.file, (n, t) => {
      e.stage = 'reading';
      e.p = Math.round(30 * Math.min(1, n / Math.max(1, t)));
      cPaintAtt(e);
    });
    e.stage = 'reading'; e.p = 32; cPaintAtt(e);

    if(e.kind !== 'image'){
      e.parts = [{ blob:e.file, name:e.file.name }];
      e.outSize = e.file.size;
      cPrepDone(e);
      return;
    }

    e.stage = 'decoding'; e.p = 42; cPaintAtt(e);
    let bmp = null;
    try{ bmp = await createImageBitmap(new Blob([raw], { type:e.file.type || 'image/png' })); }
    catch(err){ bmp = null; }
    if(!bmp){
      e.parts = [{ blob:e.file, name:e.file.name }];
      e.outSize = e.file.size;
      e.note = 'sent as-is';
      cPrepDone(e);
      return;
    }

    const w0 = bmp.width, h0 = bmp.height;
    const vertical = h0 >= w0;
    const long = vertical ? h0 : w0;
    const short = vertical ? w0 : h0;

    const plan = [];
    if(long > CMAX_SIDE * CTILE_TRIGGER){
      const scale = Math.min(1, CMAX_SIDE / short);
      // a tile may be taller than CMAX_SIDE in source pixels: what has to fit under
      // CMAX_SIDE is its *rendered* height, so all the content survives the cut
      const tileSrc = Math.max(1, Math.floor(CMAX_SIDE / scale));
      const n = Math.min(CMAX_TILES, cPartBudget(e), Math.ceil(long / tileSrc));
      for(let i = 0; i < n; i++){
        const off = i * tileSrc;
        if(off >= long) break;
        plan.push({ off:off, len:Math.min(tileSrc, long - off), scale:scale });
      }
      e.cut = plan.length * tileSrc < long;
    } else {
      plan.push({ off:0, len:long, scale:Math.min(1, CMAX_SIDE / long) });
    }
    if(!plan.length) plan.push({ off:0, len:long, scale:Math.min(1, CMAX_SIDE / long) });
    e.plan = plan.length;

    const type = cCanEncode('image/webp') ? 'image/webp' : 'image/jpeg';
    const outs = [], dims = [];
    for(let i = 0; i < plan.length; i++){
      const q = plan[i];
      const sw = vertical ? w0 : q.len;
      const sh = vertical ? q.len : h0;
      const dw = Math.max(1, Math.round(sw * q.scale));
      const dh = Math.max(1, Math.round(sh * q.scale));
      e.stage = plan.length > 1
        ? ('part ' + (i + 1) + '/' + plan.length + ' \u00b7 ' + dw + '\u00d7' + dh)
        : (q.scale < 1 ? ('resizing ' + w0 + '\u00d7' + h0 + ' \u2192 ' + dw + '\u00d7' + dh)
                       : 'encoding');
      e.p = 55 + Math.round(35 * i / plan.length);
      cPaintAtt(e);
      const cv = cDraw(bmp, vertical ? 0 : q.off, vertical ? q.off : 0, sw, sh, dw, dh);
      let blob = await cToBlob(cv, type, CQUALITY);
      if(!blob) blob = await cToBlob(cv, 'image/jpeg', 0.9);
      if(blob){ outs.push(blob); dims.push([dw, dh]); }
    }
    if(bmp.close) try{ bmp.close(); }catch(err){}
    e.p = 95; cPaintAtt(e);

    const total = outs.reduce((n, b) => n + b.size, 0);
    const single = plan.length === 1;
    if(!outs.length || (single && total >= e.in)){
      e.parts = [{ blob:e.file, name:e.file.name }];
      e.outSize = e.file.size;
      e.note = 'sent as-is';
    } else {
      const ext = outs[0].type === 'image/webp' ? '.webp' : '.jpg';
      const base = e.file.name.replace(/\.[^.]+$/, '');
      e.parts = outs.map((blob, i) => ({
        blob: blob,
        name: single ? (base + ext)
                     : (base + '-part' + (i + 1) + 'of' + outs.length + ext)
      }));
      e.outSize = total;
      e.dims = dims[0];
      e.note = single
        ? (plan[0].scale < 1 ? (dims[0][0] + '\u00d7' + dims[0][1]) : '')
        : ((e.cut ? 'first ' : '') + outs.length + ' parts');
    }
    cPrepDone(e);
  }catch(err){
    e.parts = [{ blob:e.file, name:e.file.name }];
    e.outSize = e.file.size;
    e.note = 'sent as-is';
    cPrepDone(e);
  }
}
function cPaintAtt(e){
  if(e.state === e._s && e.p === e._p) return;
  e._s = e.state; e._p = e.p;
  const el = q('#c-attach .att[data-id="' + e.id + '"]');
  if(!el) return;
  const bar = el.querySelector('.pb b');
  const lbl = el.querySelector('.lbl');
  if(bar) bar.style.width = e.p + '%';
  el.classList.toggle('ready', e.state === 'ready');
  if(lbl) lbl.textContent = e.state === 'ready'
    ? (e.note ? e.note + ' \u00b7 ' : '') + cFmt(e.in) +
      (e.outSize && e.outSize !== e.in ? ' \u2192 ' + cFmt(e.outSize) : '')
    : e.stage + ' \u00b7 ' + e.p + '%';
}
function cRenderAtt(){
  const box = q('#c-attach');
  if(!box) return;
  if(!pend.length){ box.innerHTML = ''; box.style.display = 'none'; cSendBtn(); return; }
  box.style.display = '';
  const fileIcon = '<span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span>';
  box.innerHTML = pend.map(e => {
    const thumb = e.kind === 'image'
      ? (e.url ? '<img src="' + e.url + '" alt="">' : '<span class="ic ph"></span>')
      : fileIcon;
    return '<span class="att' + (e.state === 'ready' ? ' ready' : '') + '" data-id="' + e.id +
      '" data-in="' + e.in + '" data-out="' + (e.outSize || e.in) + '"' +
      '" data-parts="' + (e.parts ? e.parts.length : 1) + '"' +
      ' title="' + cEsc(e.file.name) + '">' + thumb +
      '<span class="meta"><span class="nm">' + cEsc(e.name) + '</span>' +
      '<span class="st"><i class="pb"><b style="width:' + e.p + '%"></b></i>' +
      '<span class="lbl"></span></span></span>' +
      '<button type="button" class="rm" data-id="' + e.id + '">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
      '</button></span>';
  }).join('');
  qa('.att .rm', box).forEach(b => b.addEventListener('click', () => {
    pend = pend.filter(x => x.id !== b.dataset.id);
    cRenderAtt();
    cSendBtn();
  }));
  pend.forEach(e => { e._p = -1; e._s = ''; cPaintAtt(e); });
}
function cToast(msg){
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:3000;' +
    'padding:10px 16px;border-radius:10px;background:#181513;border:1px solid rgba(223,192,116,.3);' +
    'color:#f6f2e9;font:500 12px/1.45 Inter,sans-serif;box-shadow:0 18px 40px -12px rgba(0,0,0,.9);max-width:80vw';
  document.body.appendChild(el);
  setTimeout(() => { el.style.transition = 'opacity .3s'; el.style.opacity = '0';
    setTimeout(() => el.remove(), 320); }, 2800);
}

/* ── send / stream ────────────────────────────────────────────────── */
function cAutoGrow(){
  const t = q('#c-in');
  if(!t) return;
  t.style.height = 'auto';
  t.style.height = Math.min(t.scrollHeight, 220) + 'px';
}
const C_ICON_SEND = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>Send';
const C_ICON_STOP = '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>Stop';
function cSendBtn(){
  const b = q('#c-send');
  const tag = q('#c-live');
  if(tag) tag.style.display = busy ? '' : 'none';
  if(!b) return;
  if(busy){
    b.disabled = false;
    b.classList.add('stop');
    b.classList.remove('wait');
    b.innerHTML = C_ICON_STOP;
    return;
  }
  const working = pend.some(x => x.state === 'working');
  b.classList.remove('stop');
  b.classList.toggle('wait', working);
  b.disabled = working;
  b.innerHTML = working ? '<span class="spin"></span>Preparing' : C_ICON_SEND;
}
function cBusy(on){ busy = on; cSendBtn(); }
async function cSend(retryText){
  if(busy) return;
  if(pend.some(x => x.state === 'working')){ cToast('Still preparing the attachment…'); return; }
  const input = q('#c-in');
  const isRetry = (typeof retryText === 'string');
  const text = isRetry ? retryText : ((input && input.value) || '').trim();
  if(!text && !pend.length) return;

  const conv = cConv();
  const files = pend.slice();

  if(!isRetry){
    conv.msgs.push({ role:'user', mid:'u' + Date.now().toString(36), text:text, at:cNow(),
      files: files.map(e => ({ name:e.name, bytes:e.outSize || e.file.size,
                              kind:e.kind, parts:(e.parts || []).length })),
      thumbs: files.filter(e => e.kind === 'image').map(e => e.url).filter(Boolean) });
    if(input){ input.value = ''; cAutoGrow(); }
    pend = []; cRenderAtt();
  }

  const aMsg = { role:'assistant', mid:'a' + Date.now().toString(36), text:'', reason:'',
                 search:[], at:cNow(), model:CS.model, label:cModelLabel(), streaming:true };
  conv.msgs.push(aMsg);
  conv.at = Date.now();
  CS.convs = [conv, ...CS.convs.filter(x => x.id !== conv.id)];
  cSave(); cRenderList(); cRenderMsgs();

  const el = q('[data-mid="' + aMsg.mid + '"]');
  const bodyEl = el ? el.querySelector('.md') : null;
  const reasonWrap = el ? el.querySelector('.mreason') : null;
  const reasonEl = reasonWrap ? reasonWrap.querySelector('div') : null;

  let raw = '', rsn = '', rafId = 0;
  const paintLive = () => { rafId = 0; if(bodyEl) bodyEl.innerHTML = cMd(raw) + '<span class="caret"></span>'; cToEnd(false); };
  const schedule = () => { if(!rafId) rafId = requestAnimationFrame(paintLive); };

  if(bodyEl) bodyEl.innerHTML = '<span class="think-dots"><i></i><i></i><i></i></span>';

  const history = [];
  for(const m of conv.msgs){
    if(m === aMsg || m.error || m.streaming) continue;
    let c = m.text || '';
    if(m.files && m.files.length && m.role === 'user')
      c = (c ? c + '\n\n' : '') + m.files.map(f => '[' + (f.kind === 'image' ? 'image' : 'file') + ': ' + f.name + ']').join('\n');
    if(c) history.push({ role:m.role, content:c });
  }

  const fd = new FormData();
  fd.append('model', CS.model);
  fd.append('system', CS.system || '');
  fd.append('search', CS.search ? '1' : '0');
  fd.append('temp', String(CS.temp));
  fd.append('cred', CS.cred || '');
  fd.append('messages', JSON.stringify(history));
  files.forEach(e => (e.parts || [{ blob:e.file, name:e.name }])
    .forEach(p => fd.append('files', p.blob, p.name)));

  ctl = new AbortController();
  cBusy(true);
  let failed = '';

  try{
    const res = await fetch('/admin/chat?key=' + encodeURIComponent(ADMIN_KEY),
      { method:'POST', body:fd, signal:ctl.signal, headers:{ 'Accept':'text/event-stream' } });
    if(!res.ok || !res.body){
      let t = '';
      try{ t = await res.text(); }catch(e){}
      throw new Error('HTTP ' + res.status + ' ' + String(t || '').slice(0,300));
    }
    const rd = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    while(true){
      const r = await rd.read();
      if(r.done) break;
      buf += dec.decode(r.value, { stream:true });
      let idx;
      while((idx = buf.indexOf('\n\n')) >= 0){
        const chunk = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        for(const line of chunk.split('\n')){
          if(line.slice(0,5) !== 'data:') continue;
          let ev;
          try{ ev = JSON.parse(line.slice(5).trim()); }catch(e){ continue; }
          if(ev.t === 'text'){ raw += ev.text; schedule(); }
          else if(ev.t === 'reason'){
            rsn += ev.text;
            if(!reasonWrap && el){
              const w = document.createElement('div');
              w.className = 'mreason open';
              w.innerHTML = '<button type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>Reasoning…</button><div></div>';
              const hd = el.querySelector('.msg-hd');
              if(hd){ hd.insertAdjacentElement('afterend', w); w.querySelector('button').addEventListener('click', () => w.classList.toggle('open')); }
            }
            const rEl = el ? el.querySelector('.mreason > div') : null;
            if(rEl) rEl.textContent = rsn;
          }
          else if(ev.t === 'search'){
            const s = { kind: 'search', query: ev.query || '', read: !!ev.read, ms: 0 };
            aMsg.search.push(s);
            const st = q('#c-stream');
            if(st && el && el.parentNode === st) st.insertBefore(cSearchLine(s, false), el);
            else if(st) st.appendChild(cSearchLine(s, false));
            cToEnd(false);
          }
          else if(ev.t === 'search_done'){
            // several parallel searches finish together — match by query, not by position
            const items = aMsg.search || [];
            let target = null;
            for(const x of items){ if(x.kind === 'search' && !x.closed && x.query === (ev.query || '')){ target = x; break; } }
            if(!target) for(const x of items){ if(x.kind === 'search' && !x.closed){ target = x; break; } }
            if(target){ target.ms = ev.ms || 0; target.read = !!ev.read; target.closed = true; }
            const st = q('#c-stream');
            if(st){
              const open = qa('.sline:not(.done)', st);
              let live = null;
              for(const el of open){
                const qe = el.querySelector('q');
                if(qe && qe.textContent === (ev.query || '')){ live = el; break; }
              }
              if(!live) live = open[0] || null;
              if(live){
                live.classList.add('done');
                const mEl = live.querySelector('.ms');
                if(mEl) mEl.textContent = cMs(ev.ms);
              }
            }
          }
          else if(ev.t === 'status'){
            // the gateway is retrying a transient upstream 5xx — say so, and keep
            // the note in the message state so it survives the final re-render
            const note = { kind: 'retry', query: ev.message || '', ms: 0 };
            aMsg.search.push(note);
            const st = q('#c-stream');
            if(st){
              const line = cSearchLine(note, true);
              if(el && el.parentNode === st) st.insertBefore(line, el);
              else st.appendChild(line);
            }
            cToEnd(false);
          }
          else if(ev.t === 'error'){ failed = ev.message || 'Upstream error'; }
          else if(ev.t === 'usage'){ aMsg.usage = { in: ev.in, out: ev.out }; }
        }
      }
    }
  }catch(e){
    if(e && e.name === 'AbortError'){ if(raw) raw += '\n\n[stopped]'; }
    else failed = String((e && e.message) || e);
  }finally{
    if(rafId) cancelAnimationFrame(rafId);
    ctl = null;
    cBusy(false);
    aMsg.text = raw;
    if(rsn) aMsg.reason = rsn;
    delete aMsg.streaming;
    if(failed){
      aMsg.error = failed;
      cToast(failed.slice(0,140));
    }
    cSave(); cRenderList(); cRenderMsgs();
    cToEnd(false);
  }
}
function cRetry(mid){
  const conv = CS.convs.find(x => x.id === CS.active);
  if(!conv) return;
  const i = conv.msgs.findIndex(m => m.mid === mid);
  if(i < 0) return;
  conv.msgs = conv.msgs.slice(0, i);
  cSave(); cRenderMsgs();
  cSend('');
}
function cNew(){
  if(busy) return;
  CS.active = null;
  CS.convs = CS.convs.filter(c => c.msgs && c.msgs.length);
  cConv(); cSave(); cRenderList(); cRenderMsgs();
  const t = q('#c-in'); if(t){ t.value = ''; cAutoGrow(); t.focus(); }
  cSide(false);
}
function cTempPaint(){
  const t = q('#c-temp'), v = q('#c-tempv');
  if(!t) return;
  const val = parseFloat(t.value) || 0;
  t.style.setProperty('--p', (val/2*100).toFixed(1) + '%');
  if(v) v.textContent = val.toFixed(2);
}

function cFit(){
  const el = q('#c-app');
  if(!el) return;
  const p = el.closest('.panel');
  if(!p || !p.classList.contains('on')) return;
  if(window.scrollY > 8) return;
  const top = el.getBoundingClientRect().top;
  const h = Math.max(440, Math.round(window.innerHeight - top - 30));
  el.style.height = h + 'px';
}

/* ── init ─────────────────────────────────────────────────────────── */
function cInit(){
  if(!q('#c-app')) return;
  cLoad();

  const mSel = q('#c-model'), cSel = q('#c-cred');
  const want = CS.model;
  if(mSel){
    const opts = qa('option', mSel);
    if(want && opts.some(o => o.value === want)) mSel.value = want;
    CS.model = mSel.value || '';
  }
  if(cSel){
    const opts = qa('option', cSel);
    if(CS.cred && opts.some(o => o.value === CS.cred)) cSel.value = CS.cred;
    CS.cred = cSel.value || '';
  }
  const sys = q('#c-sys'); if(sys) sys.value = CS.system || '';
  const tmp = q('#c-temp'); if(tmp){ tmp.value = String(CS.temp); cTempPaint(); }
  const sw = q('#c-search-sw'); if(sw) sw.classList.toggle('on', CS.search !== false);

  if(!CS.active && CS.convs.length) CS.active = CS.convs[0].id;
  cRenderList(); cRenderMsgs();

  if(mSel) mSel.addEventListener('change', () => { CS.model = mSel.value; cSave(); });
  if(cSel) cSel.addEventListener('change', () => { CS.cred = cSel.value; cSave(); });
  if(sys) sys.addEventListener('input', () => { CS.system = sys.value; cSave(); });
  if(tmp) tmp.addEventListener('input', () => { CS.temp = parseFloat(tmp.value) || 0; cSave(); cTempPaint(); });
  if(sw) sw.addEventListener('click', () => { CS.search = !(CS.search !== false); sw.classList.toggle('on', CS.search); cSave(); });

  const nb = q('#c-new'); if(nb) nb.addEventListener('click', cNew);
  const dr = q('#c-drawer'); if(dr) dr.addEventListener('click', () => cSide());
  const sx = q('#c-side-x'); if(sx) sx.addEventListener('click', () => cSide(false));
  const st = q('#c-stream'); if(st) st.addEventListener('click', () => cSide(false));
  const cp = q('.chat-compose'); if(cp) cp.addEventListener('click', () => cSide(false));
  document.addEventListener('keydown', e => {
    if(e.key === 'Escape') cSide(false);
  });
  const ju = q('#c-jump'); if(ju) ju.addEventListener('click', () => { cJump(false); cToEnd(true); });

  qa('.ce-chip').forEach(ch => ch.addEventListener('click', () => {
    const t = q('#c-in');
    if(!t) return;
    t.value = ch.dataset.p || '';
    cAutoGrow(); t.focus(); cSend();
  }));

  const input = q('#c-in');
  if(input){
    input.addEventListener('input', cAutoGrow);
    input.addEventListener('focus', () => { const b = q('#c-box'); if(b) b.classList.add('focus'); });
    input.addEventListener('blur', () => { const b = q('#c-box'); if(b) b.classList.remove('focus'); });
    input.addEventListener('keydown', e => {
      if(e.key === 'Enter' && !e.shiftKey && !e.isComposing){ e.preventDefault(); if(!busy) cSend(); }
    });
    input.addEventListener('paste', e => {
      const items = (e.clipboardData && e.clipboardData.items) || [];
      const got = [];
      for(const it of items){ if(it.kind === 'file'){ const f = it.getAsFile(); if(f) got.push(f); } }
      if(got.length){ e.preventDefault(); cPushFiles(got); }
    });
  }
  const sb = q('#c-send');
  if(sb) sb.addEventListener('click', () => { if(busy){ if(ctl) ctl.abort(); } else cSend(); });
  const fb = q('#c-file');
  if(fb) fb.addEventListener('change', () => { cPushFiles(Array.from(fb.files || [])); fb.value = ''; });
  const clip = q('#c-clip');
  if(clip && fb) clip.addEventListener('click', () => fb.click());

  const box = q('#c-box');
  if(box){
    ['dragenter','dragover'].forEach(ev => box.addEventListener(ev, e => { e.preventDefault(); box.classList.add('drop'); }));
    ['dragleave','drop'].forEach(ev => box.addEventListener(ev, e => { e.preventDefault(); box.classList.remove('drop'); }));
    box.addEventListener('drop', e => { const dt = e.dataTransfer; if(dt) cPushFiles(Array.from(dt.files || [])); });
  }
  document.addEventListener('keydown', e => {
    const p = q('.panel[data-p="chat"]');
    if(!p || !p.classList.contains('on')) return;
    if((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k'){ e.preventDefault(); cNew(); }
  });
  cAutoGrow();
  requestAnimationFrame(cFit);
}
/* recompute the fit whenever the Chat tab is opened */
const _cOpenTab = window.openTab;
if(typeof _cOpenTab === 'function'){
  window.openTab = function(n){ _cOpenTab(n); if(n === 'chat') requestAnimationFrame(cFit); };
}
window.addEventListener('resize', function(){ if(!busy) requestAnimationFrame(cFit); }, { passive:true });
document.addEventListener('DOMContentLoaded', cInit);
"""

CHAT_HTML = r"""
  <div class="panel" data-p="chat">
  <div class="chat-scope">
  <div class="chat" id="c-app">

    <aside class="chat-side" id="c-aside">
      <div class="cs-hd">
        <div class="cs-brand"><i></i><span>Noosphere</span></div>
        <button type="button" class="ct-icon ct-drawer" id="c-side-x" title="Close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="cs-new-wrap">
        <button type="button" class="cs-new" id="c-new">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          New conversation
        </button>
      </div>
      <div class="cs-list" id="c-list"></div>
      <div class="cs-foot">
        <div class="cs-field">
          <label>Model</label>
          <select id="c-model">{chat_models}</select>
        </div>
        <div class="cs-field">
          <label>Upstream credential</label>
          <select id="c-cred">{chat_creds}</select>
        </div>
        <div class="cs-field">
          <label>System instruction</label>
          <textarea id="c-sys" spellcheck="false" placeholder="Optional. Sent as the system message on every turn."></textarea>
        </div>
        <div class="cs-row">
          <div class="cs-switch" id="c-search-sw"><i></i><b>Live web search</b></div>
        </div>
        <div class="cs-field">
          <label>Temperature <b id="c-tempv" style="color:var(--c-gold);font-weight:500">0.70</b></label>
          <input type="range" class="cs-range" id="c-temp" min="0" max="2" step="0.05" value="0.7">
        </div>
      </div>
    </aside>

    <section class="chat-main">
      <header class="chat-top">
        <button type="button" class="ct-icon ct-drawer" id="c-drawer" title="Conversations">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
        <h2 class="ct-title">Ask <em>Noosphere</em></h2>
        <div class="ct-meta">
          <span class="ct-tag live" id="c-live" style="display:none">streaming</span>
          <span class="ct-tag hide-s">same pipeline as /v1</span>
        </div>
      </header>

      <div class="chat-stream" id="c-stream">
        <div class="chat-empty" id="c-empty">
          <div class="ce-mark">
            <svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round">
              <path d="M24 8.5c8.6 0 15.5 6.9 15.5 15.5S32.6 39.5 24 39.5 8.5 32.6 8.5 24 15.4 8.5 24 8.5Z"/>
              <circle cx="24" cy="24" r="7.4" stroke-width="1.4"/>
              <circle cx="24" cy="24" r="2.5" fill="currentColor" stroke="none"/>
              <path d="M24 2.5v4M24 41.5v4M2.5 24h4M41.5 24h4M8.8 8.8l2.8 2.8M36.4 36.4l2.8 2.8M39.2 8.8l-2.8 2.8M11.6 36.4l-2.8 2.8" opacity=".45"/>
            </svg>
          </div>
          <h3>A million tokens<br><em>of thought.</em></h3>
          <p>Ask a question, drop in a document or a screenshot, or let it search the web and read the pages it finds.</p>
          <div class="ce-chips">
            <button type="button" class="ce-chip" data-p="Summarise this document and list every number in it. Flag anything ambiguous."><b>Read</b>Summarise an attached PDF and list every number in it.</button>
            <button type="button" class="ce-chip" data-p="Search the web for the latest news on this topic, open the most reliable source and summarise it with dates."><b>Search</b>Search the web, open the best source, summarise it.</button>
            <button type="button" class="ce-chip" data-p="Look at this screenshot and tell me exactly what is wrong with it, step by step."><b>See</b>Tell me what is wrong with this screenshot.</button>
            <button type="button" class="ce-chip" data-p="Write a Python function that streams an SSE response and reassembles it, with error handling."><b>Build</b>Write a Python SSE client with error handling.</button>
          </div>
        </div>
      </div>

      <button type="button" class="jump" id="c-jump">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="6 13 12 19 18 13"/></svg>
        Latest
      </button>

      <footer class="chat-compose">
        <div class="compose-inner">
          <div class="cbox" id="c-box">
            <div class="cattach" id="c-attach" style="display:none"></div>
            <textarea id="c-in" rows="1" spellcheck="false" placeholder="Message Noosphere…"></textarea>
            <div class="crow">
              <button type="button" class="cbtn" id="c-clip" title="Attach images, PDFs or text files">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                Attach
              </button>
              <input type="file" id="c-file" multiple hidden accept="image/*,application/pdf,text/*,.txt,.md,.markdown,.csv,.tsv,.json,.jsonl,.log,.yaml,.yml,.xml,.html,.css,.js,.ts,.py,.sh,.sql,.toml,.ini">
              <span class="sp"></span>
              <span class="chint">Enter to send · Shift+Enter for a new line</span>
              <button type="button" class="csend" id="c-send">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                Send
              </button>
            </div>
          </div>
          <div class="cfoot">Runs through the same gateway as /v1/chat/completions — search, PDF text, page images and the system-prompt restatement all apply.</div>
        </div>
      </footer>
    </section>

  </div>
  </div>
  </div>
"""


def _svg(name: str) -> str:
    icons = {
        "plus": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        "edit": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
        "trash": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
        "copy": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
        "close": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
        "layers": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
        "box": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>',
        "key": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>',
        "check": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    }
    return icons.get(name, "")


def render_dashboard(key: str) -> str:
    with sqlite3.connect(DB_FILE) as c:
        c.row_factory = sqlite3.Row
        ups = [dict(r) for r in c.execute("SELECT * FROM upstreams ORDER BY id")]
        maps = [dict(r) for r in c.execute("SELECT * FROM mappings ORDER BY id")]
        keys = [dict(r) for r in c.execute("SELECT * FROM api_keys ORDER BY id")]
        usage = {r["key_id"]: dict(r) for r in c.execute("SELECT * FROM key_usage")}

    total_req = sum(u.get("requests", 0) for u in usage.values())

    up_options = "".join(
        f'<option value="{u["id"]}">{_esc(u["name"])} · #{u["id"]}</option>' for u in ups
    ) or '<option value="">— create upstream first —</option>'

    if ups:
        up_rows = "".join(
            f'<tr>'
            f'<td><span class="pill tag">#{u["id"]}</span></td>'
            f'<td><strong>{_esc(u["name"])}</strong></td>'
            f'<td><code class="k">{_esc(u["url"])}</code>'
            f'<div style="font-size:11px;color:var(--tx3);margin-top:4px">'
            f'{_esc(u["url"])}/v1/chat/completions</div></td>'
            f'<td><span class="pill {"on" if u["enabled"] else "off"}">'
            f'{"enabled" if u["enabled"] else "disabled"}</span></td>'
            f'<td><div class="acts">'
            f'<form method="post" action="/admin/upstreams/toggle?key={key}" style="margin:0">'
            f'<input type="hidden" name="id" value="{u["id"]}">'
            f'<button class="btn ghost icon" title="Toggle">{_svg("check")}</button></form>'
            f'<form method="post" action="/admin/upstreams/delete?key={key}" style="margin:0">'
            f'<input type="hidden" name="id" value="{u["id"]}">'
            f'<button class="btn danger icon" title="Delete">{_svg("trash")}</button></form>'
            f'</div></td></tr>'
            for u in ups
        )
    else:
        up_rows = f'<tr><td colspan="5"><div class="empty">{_svg("layers")}No upstreams yet</div></td></tr>'

    if maps:
        map_rows = ""
        for m in maps:
            ep = {1: "anthropic", 2: "openai", 3: "both"}.get(m["endpoint_mode"], "both")
            reas = f'{m["is_reasoning"]}x' if m["is_reasoning"] else "off"
            map_rows += (
                f'<tr>'
                f'<td><code class="k em">{_esc(m["fake_model"])}</code></td>'
                f'<td><code class="k">{_esc(m["real_model"])}</code></td>'
                f'<td><span class="pill tag">up#{m["upstream_id"]}</span></td>'
                f'<td><span class="pill cyan">{ep}</span></td>'
                f'<td><span class="pill pink">{reas}</span></td>'
                f'<td><span class="pill tag">{m["context_length"]//1000}k</span></td>'
                f'<td>{m["delay_sec"]}s</td>'
                f'<td><span class="pill {"on" if m["enabled"] else "off"}">'
                f'{"on" if m["enabled"] else "off"}</span></td>'
                f'<td><div class="acts">'
                f'<button type="button" class="btn ghost icon" title="Edit" '
                f'data-id="{m["id"]}" data-fake="{_esc(m["fake_model"])}" '
                f'data-real="{_esc(m["real_model"])}" data-up="{m["upstream_id"]}" '
                f'data-owner="{_esc(m["owned_by"])}" data-ctx="{m["context_length"]}" '
                f'data-delay="{m["delay_sec"]}" data-reason="{m["is_reasoning"]}" '
                f'data-endpoint="{m["endpoint_mode"]}" '
                f'onclick="fillModal(this)">{_svg("edit")}</button>'
                f'<form method="post" action="/admin/mappings/toggle?key={key}" style="margin:0">'
                f'<input type="hidden" name="id" value="{m["id"]}">'
                f'<button class="btn ghost icon" title="Toggle">{_svg("check")}</button></form>'
                f'<form method="post" action="/admin/mappings/delete?key={key}" style="margin:0">'
                f'<input type="hidden" name="id" value="{m["id"]}">'
                f'<button class="btn danger icon" title="Delete">{_svg("trash")}</button></form>'
                f'</div></td></tr>'
            )
    else:
        map_rows = f'<tr><td colspan="9"><div class="empty">{_svg("box")}No model mappings yet</div></td></tr>'

    if keys:
        key_rows = ""
        for k in keys:
            u = usage.get(k["id"], {})
            req = u.get("requests", 0)
            ink = u.get("input_tokens", 0)
            outk = u.get("output_tokens", 0)
            key_rows += (
                f'<tr>'
                f'<td><span class="pill tag">#{k["id"]}</span></td>'
                f'<td style="max-width:280px">'
                f'<div style="display:flex;align-items:center;gap:8px">'
                f'<code class="k" style="flex:1;overflow:hidden;text-overflow:ellipsis;'
                f'white-space:nowrap;display:block" title="{_esc(k["public_key"])}">'
                f'{_esc(k["public_key"][:38])}…</code>'
                f'<button type="button" class="btn ghost icon" '
                f'onclick="copy(\'{_esc(k["public_key"])}\',this)" title="Copy">'
                f'{_svg("copy")}</button>'
                f'</div></td>'
                f'<td>{_esc(k["note"])}</td>'
                f'<td><code class="k" title="{_esc(k.get("upstream_key") or "")}">'
                f'{_esc(mask_key(k.get("upstream_key") or "")) or "—"}</code></td>'
                f'<td><span class="pill tag">{k["rpm_limit"]} rpm</span></td>'
                f'<td><div style="font-size:12px;color:var(--tx2);font-variant-numeric:tabular-nums">'
                f'{req} req · {ink//1000}k in · {outk//1000}k out</div></td>'
                f'<td><span class="pill {"on" if k["enabled"] else "off"}">'
                f'{"on" if k["enabled"] else "off"}</span></td>'
                f'<td><div class="acts">'
                f'<form method="post" action="/admin/keys/toggle?key={key}" style="margin:0">'
                f'<input type="hidden" name="id" value="{k["id"]}">'
                f'<button class="btn ghost icon" title="Toggle">{_svg("check")}</button></form>'
                f'<form method="post" action="/admin/keys/delete?key={key}" style="margin:0">'
                f'<input type="hidden" name="id" value="{k["id"]}">'
                f'<button class="btn danger icon" title="Delete">{_svg("trash")}</button></form>'
                f'</div></td></tr>'
            )
    else:
        key_rows = f'<tr><td colspan="7"><div class="empty">{_svg("key")}No API keys yet</div></td></tr>'

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Noesphere · Console</title>
<style>{DASH_CSS}
{CHAT_CSS}</style>
</head>
<body>
<div class="wrap">
  <div class="hdr">
    <div class="brand">
      <div class="mark"></div>
      <div>
        <h1>Noesphere</h1>
        <small>Noetic Labs · Gateway</small>
      </div>
    </div>
    <div class="status"><span class="dot"></span>operational · v{SPHERE_VERSION}</div>
  </div>

  <div class="stats">
    <div class="stat"><div class="v">{len(ups)}</div><div class="l">Upstreams</div></div>
    <div class="stat"><div class="v">{len(maps)}</div><div class="l">Models</div></div>
    <div class="stat"><div class="v">{len(keys)}</div><div class="l">API Keys</div></div>
    <div class="stat"><div class="v">{total_req:,}</div><div class="l">Total Requests</div></div>
  </div>

  <div class="tabs">
    <button class="tab" data-t="chat">Chat</button>
    <button class="tab" data-t="models">Models</button>
    <button class="tab" data-t="upstreams">Upstreams</button>
    <button class="tab" data-t="keys">API Keys</button>
  </div>

  <div class="panel" data-p="models">
    <div class="card">
      <div class="card-hd">
        <div><h2>Model Mappings</h2><div class="sub">public id → upstream model</div></div>
      </div>
      <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>Public</th><th>Real</th><th>Upstream</th><th>Endpoint</th>
          <th>Reasoning</th><th>Context</th><th>Delay</th><th>State</th><th></th>
        </tr></thead>
        <tbody>{map_rows}</tbody>
      </table>
      </div>
      <div style="margin-top:16px">
        <button class="btn primary" onclick="newModel()">{_svg("plus")} Add Model</button>
      </div>
    </div>
  </div>

  <div class="panel" data-p="upstreams">
    <div class="card">
      <div class="card-hd">
        <div><h2>Upstreams</h2><div class="sub">backend providers</div></div>
      </div>
      <form class="form" method="post" action="/admin/upstreams/add?key={key}">
        <input name="name" placeholder="Name (e.g. newapi-prod)" required>
        <input name="url" class="wide" placeholder="https://api.example.com — с /v1 или без, определим сами" required>
        <button class="btn primary" type="submit">{_svg("plus")} Add</button>
      </form>
      <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Name</th><th>URL</th><th>State</th><th></th></tr></thead>
        <tbody>{up_rows}</tbody>
      </table>
      </div>
    </div>
  </div>

  <div class="panel" data-p="keys">
    <div class="card">
      <div class="card-hd">
        <div><h2>Client API Keys</h2><div class="sub">sk-noe-v1 · per-client upstream key</div></div>
      </div>
      <form class="form" method="post" action="/admin/keys/add?key={key}">
        <input name="note" placeholder="Name (client name)" required>
        <input name="rpm_limit" type="number" value="60" min="1" placeholder="RPM limit">
        <input name="upstream_key" class="wide" placeholder="Original upstream key (sk-...) — этим ключом пойдут запросы клиента">
        <button class="btn primary" type="submit">{_svg("plus")} Generate</button>
      </form>
      <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Key</th><th>Note</th><th>Upstream key</th><th>Limit</th><th>Usage</th><th>State</th><th></th></tr></thead>
        <tbody>{key_rows}</tbody>
      </table>
      </div>
    </div>
  </div>

{render_chat_panel()}
</div>

<div class="overlay" id="modal_model">
  <div class="modal">
    <div class="modal-hd">
      <h3 id="m_title">New Model</h3>
      <button class="x" onclick="closeM('modal_model')">{_svg("close")}</button>
    </div>
    <form method="post" action="/admin/mappings/save?key={key}">
      <div class="modal-bd">
        <input type="hidden" name="row_id" id="m_id">
        <div class="fg full">
          <label>Public model ID (shown to clients)</label>
          <input name="fake_model" id="m_fake" placeholder="noosphere-1" required>
        </div>
        <div class="fg full">
          <label>Real upstream model</label>
          <input name="real_model" id="m_real" placeholder="glm-4.6" required>
        </div>
        <div class="fg full">
          <label>Upstream</label>
          <select name="upstream_id" id="m_up" required>{up_options}</select>
        </div>
        <div class="fg">
          <label>Owned by</label>
          <input name="owned_by" id="m_owner" value="noetic-labs">
        </div>
        <div class="fg">
          <label>Context length</label>
          <input name="context_length" id="m_ctx" type="number" value="128000">
        </div>
        <div class="fg">
          <label>Delay (s)</label>
          <input name="delay_sec" id="m_delay" type="number" step="0.1" value="0">
        </div>
        <div class="fg">
          <label>Reasoning depth</label>
          <select name="is_reasoning" id="m_reason">
            <option value="0">Off</option>
            <option value="1">1x — direct</option>
            <option value="2">2x — verify</option>
            <option value="3">3x — double</option>
            <option value="4">4x — audit</option>
            <option value="5">5x — exhaustive</option>
          </select>
        </div>
        <div class="fg full">
          <label>Endpoint availability</label>
          <select name="endpoint_mode" id="m_endpoint">
            <option value="3">Both — /v1/chat/completions + /v1/messages</option>
            <option value="1">Anthropic only — /v1/messages</option>
            <option value="2">OpenAI only — /v1/chat/completions</option>
          </select>
        </div>
      </div>
      <div class="modal-ft">
        <button type="button" class="btn ghost" onclick="closeM('modal_model')">Cancel</button>
        <button type="submit" class="btn primary">Save Model</button>
      </div>
    </form>
  </div>
</div>

<script>
const ADMIN_KEY="{key}";
{DASH_JS}
{CHAT_JS}
</script>
</body>
</html>"""


@app.get("/admin", response_class=HTMLResponse)
def admin_page(key: str = Depends(verify_admin)):
    return HTMLResponse(render_dashboard(key))


@app.get("/")
async def root():
    return RedirectResponse("/admin", status_code=302)


@app.post("/admin/upstreams/add")
async def up_add(name: str = Form(...), url: str = Form(...),
                 key: str = Depends(verify_admin)):
    norm_url = normalize_upstream_url(url)
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("""INSERT OR REPLACE INTO upstreams
                         (name,url,api_key,enabled,created_at) VALUES (?,?,?,1,?)""",
                      (name.strip(), norm_url, "",
                       datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/upstreams/toggle")
async def up_toggle(id: int = Form(...), key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("UPDATE upstreams SET enabled = 1 - enabled WHERE id=?", (id,))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/upstreams/delete")
async def up_del(id: int = Form(...), key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("DELETE FROM upstreams WHERE id=?", (id,))
            c.execute("DELETE FROM mappings WHERE upstream_id=?", (id,))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/mappings/save")
async def map_save(row_id: str = Form(""), fake_model: str = Form(...),
                   real_model: str = Form(...), upstream_id: int = Form(...),
                   owned_by: str = Form("noetic-labs"),
                   context_length: int = Form(128000), delay_sec: float = Form(0.0),
                   is_reasoning: int = Form(0), endpoint_mode: int = Form(3),
                   key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            if row_id and row_id.isdigit():
                c.execute("""UPDATE mappings SET
                    fake_model=?, real_model=?, upstream_id=?, owned_by=?,
                    context_length=?, delay_sec=?, is_reasoning=?, endpoint_mode=?
                    WHERE id=?""",
                    (fake_model.strip(), real_model.strip(), upstream_id, owned_by.strip(),
                     int(context_length), float(delay_sec), int(is_reasoning),
                     int(endpoint_mode), int(row_id)))
            else:
                c.execute("""INSERT OR REPLACE INTO mappings
                    (fake_model, real_model, upstream_id, owned_by, context_length,
                     delay_sec, is_reasoning, endpoint_mode, enabled)
                    VALUES (?,?,?,?,?,?,?,?,1)""",
                    (fake_model.strip(), real_model.strip(), upstream_id, owned_by.strip(),
                     int(context_length), float(delay_sec), int(is_reasoning),
                     int(endpoint_mode)))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/mappings/toggle")
async def map_toggle(id: int = Form(...), key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("UPDATE mappings SET enabled = 1 - enabled WHERE id=?", (id,))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/mappings/delete")
async def map_del(id: int = Form(...), key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("DELETE FROM mappings WHERE id=?", (id,))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/keys/add")
async def k_add(note: str = Form(""), rpm_limit: int = Form(60),
                upstream_key: str = Form(""), key: str = Depends(verify_admin)):
    new_k = gen_ant_key()
    created = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("""INSERT INTO api_keys
                         (public_key, note, rpm_limit, enabled, created_at, upstream_key)
                         VALUES (?,?,?,1,?,?)""",
                      (new_k, note.strip(), int(rpm_limit), created, upstream_key.strip()))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return HTMLResponse(
        f"<script>alert('API key created:\\n\\n{new_k}\\n\\nCopy it now.');"
        f"location.href='/admin?key={key}';</script>"
    )


@app.post("/admin/keys/toggle")
async def k_toggle(id: int = Form(...), key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("UPDATE api_keys SET enabled = 1 - enabled WHERE id=?", (id,))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


@app.post("/admin/keys/delete")
async def k_del(id: int = Form(...), key: str = Depends(verify_admin)):
    def _w() -> None:
        with sqlite3.connect(DB_FILE) as c:
            c.execute("DELETE FROM api_keys WHERE id=?", (id,))
            c.execute("DELETE FROM key_usage WHERE key_id=?", (id,))
            c.commit()
    await asyncio.to_thread(_w)
    load_data()
    return _redir(key)


# ══════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=PORT, workers=WORKERS, log_level="info",
                timeout_keep_alive=75, backlog=2048)